import https from "https";

const PUBLIC_KEY = process.env.MUBISYS_PUBLIC_KEY;
const ACCESS_TOKEN = process.env.MUBISYS_ACCESS_TOKEN;
const BASE = `https://api.mubisys.com/api/${PUBLIC_KEY}`;

function get(path) {
  return new Promise((resolve) => {
    const url = `${BASE}${path}`;
    const req = https.get(url, {
      headers: { "Access-Token": ACCESS_TOKEN, "Accept": "application/json" }
    }, (res) => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => resolve({ status: res.statusCode, body }));
    });
    req.on("error", e => resolve({ status: 0, body: e.message }));
    req.setTimeout(10000, () => { req.destroy(); resolve({ status: 0, body: "timeout" }); });
  });
}

// Get a recent OS to understand the full structure
const { status, body } = await get("/ordem-servico/numero/6500");
const os = JSON.parse(body);
console.log("=== OS 6500 KEYS ===");
console.log(Object.keys(os));
console.log("\n=== PRODUTO INFO ===");
console.log(JSON.stringify(os.produto ?? os.produtos ?? os.itens ?? "N/A", null, 2).substring(0, 800));
console.log("\n=== CLIENTE INFO ===");
console.log(JSON.stringify({ cliente: os.cliente, cliente_id: os.cliente_id }, null, 2));
console.log("\n=== VALOR/FATURAMENTO ===");
console.log(JSON.stringify({
  valor_total: os.valor_total,
  valor: os.valor,
  faturamento: os.faturamento,
  total: os.total,
  valor_os: os.valor_os,
  preco: os.preco,
  data_finalizacao: os.data_finalizacao,
  data_expedicao: os.data_expedicao,
  data_entrega: os.data_entrega,
  status: os.status,
  tipo: os.tipo,
}, null, 2));

// Try to find OS list endpoint with correct params
console.log("\n=== Trying OS list endpoints ===");
const endpoints = [
  "/ordem-servico/lista",
  "/ordem-servico/busca",
  "/ordem-servico/filtro",
  "/os",
  "/os/lista",
  "/pedido",
  "/pedido?page=1&per_page=5",
  "/ordem-servico?tipo=Normal&page=1&per_page=3",
  "/ordem-servico/numero?inicio=6490&fim=6500",
];

for (const ep of endpoints) {
  const r = await get(ep);
  const preview = r.body.substring(0, 200);
  console.log(`[${r.status}] ${ep}: ${preview}`);
}
