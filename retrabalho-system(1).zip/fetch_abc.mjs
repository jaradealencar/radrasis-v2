import https from "https";

const pk = process.env.MUBISYS_PUBLIC_KEY;
const at = process.env.MUBISYS_ACCESS_TOKEN;

function get(path) {
  return new Promise((resolve) => {
    const url = `https://api.mubisys.com/api/${pk}${path}`;
    const req = https.get(url, {
      headers: { "Access-Token": at, "Accept": "application/json" }
    }, (res) => {
      let b = "";
      res.on("data", c => b += c);
      res.on("end", () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(b) }); }
        catch { resolve({ status: res.statusCode, data: { raw: b.substring(0, 200) } }); }
      });
    });
    req.on("error", e => resolve({ status: 0, data: { error: e.message } }));
    req.setTimeout(15000, () => { req.destroy(); resolve({ status: 0, data: { error: "timeout" } }); });
  });
}

async function fetchOsForMonth(ano, mes) {
  const start = `${ano}-${String(mes).padStart(2, "0")}-01`;
  const lastDay = new Date(ano, mes, 0).getDate();
  const end = `${ano}-${String(mes).padStart(2, "0")}-${lastDay}`;
  
  let allItems = [];
  let page = 1;
  
  while (true) {
    const path = `/ordem-servico?status=TODOS&filtrodata=CADASTRO&datainicial=${start}&datafinal=${end}&page=${page}&per_page=500`;
    const { status, data } = await get(path);
    
    if (status !== 201) {
      console.error(`Error fetching ${start} to ${end} page ${page}:`, JSON.stringify(data).substring(0, 200));
      break;
    }
    
    const items = data.data ?? [];
    allItems = allItems.concat(items);
    
    const pagination = data.pagination;
    if (!pagination || page >= pagination.last_page) break;
    page++;
  }
  
  return allItems;
}

// Fetch March and April 2026
console.log("Fetching March 2026...");
const march = await fetchOsForMonth(2026, 3);
console.log(`March: ${march.length} OS`);

console.log("Fetching April 2026...");
const april = await fetchOsForMonth(2026, 4);
console.log(`April: ${april.length} OS`);

console.log("Fetching January 2026...");
const jan = await fetchOsForMonth(2026, 1);
console.log(`January: ${jan.length} OS`);

console.log("Fetching February 2026...");
const feb = await fetchOsForMonth(2026, 2);
console.log(`February: ${feb.length} OS`);

// Show sample structure
if (march.length > 0) {
  console.log("\nSample OS keys:", Object.keys(march[0]));
  console.log("Sample OS:", JSON.stringify(march[0], null, 2).substring(0, 600));
}

// Build ABC for March
function buildABC(osArray, label) {
  // Group by client
  const clientMap = {};
  for (const os of osArray) {
    if (os.tipo === "Retrabalho") continue; // skip retrabalhos
    const client = os.cliente ?? "Desconhecido";
    const valor = parseFloat(os.valor_total ?? 0);
    if (!clientMap[client]) clientMap[client] = { total: 0, count: 0 };
    clientMap[client].total += valor;
    clientMap[client].count++;
  }
  
  const sorted = Object.entries(clientMap)
    .map(([nome, d]) => ({ nome, total: d.total, count: d.count }))
    .sort((a, b) => b.total - a.total);
  
  const totalGeral = sorted.reduce((s, r) => s + r.total, 0);
  let acum = 0;
  const result = sorted.slice(0, 20).map(r => {
    acum += r.total;
    const pct = totalGeral > 0 ? (r.total / totalGeral * 100) : 0;
    const pctAcum = totalGeral > 0 ? (acum / totalGeral * 100) : 0;
    const classe = pctAcum <= 80 ? "A" : pctAcum <= 95 ? "B" : "C";
    return { ...r, pct: pct.toFixed(1), pctAcum: pctAcum.toFixed(1), classe };
  });
  
  console.log(`\n=== ABC CLIENTES ${label} (top 10) ===`);
  result.slice(0, 10).forEach((r, i) => {
    console.log(`${i+1}. [${r.classe}] ${r.nome} - R$${r.total.toFixed(2)} (${r.pct}%) - ${r.count} OS`);
  });
  
  // Group by product
  const prodMap = {};
  for (const os of osArray) {
    if (os.tipo === "Retrabalho") continue;
    const itens = os.itens ?? [];
    for (const item of itens) {
      const prod = item.item ?? "Desconhecido";
      const valor = parseFloat(item.valor_final ?? item.sub_total ?? 0);
      if (!prodMap[prod]) prodMap[prod] = { total: 0, count: 0 };
      prodMap[prod].total += valor;
      prodMap[prod].count++;
    }
  }
  
  const sortedProd = Object.entries(prodMap)
    .map(([nome, d]) => ({ nome, total: d.total, count: d.count }))
    .sort((a, b) => b.total - a.total);
  
  const totalProd = sortedProd.reduce((s, r) => s + r.total, 0);
  let acumProd = 0;
  const resultProd = sortedProd.slice(0, 20).map(r => {
    acumProd += r.total;
    const pct = totalProd > 0 ? (r.total / totalProd * 100) : 0;
    const pctAcum = totalProd > 0 ? (acumProd / totalProd * 100) : 0;
    const classe = pctAcum <= 80 ? "A" : pctAcum <= 95 ? "B" : "C";
    return { ...r, pct: pct.toFixed(1), pctAcum: pctAcum.toFixed(1), classe };
  });
  
  console.log(`\n=== ABC PRODUTOS ${label} (top 10) ===`);
  resultProd.slice(0, 10).forEach((r, i) => {
    console.log(`${i+1}. [${r.classe}] ${r.nome} - R$${r.total.toFixed(2)} (${r.pct}%) - ${r.count} itens`);
  });
}

buildABC(jan, "JANEIRO 2026");
buildABC(feb, "FEVEREIRO 2026");
buildABC(march, "MARÇO 2026");
buildABC(april, "ABRIL 2026");
