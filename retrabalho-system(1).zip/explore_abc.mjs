import https from "https";

const pk = process.env.MUBISYS_PUBLIC_KEY;
const at = process.env.MUBISYS_ACCESS_TOKEN;

function getOS(num) {
  return new Promise((resolve) => {
    const req = https.get(`https://api.mubisys.com/api/${pk}/ordem-servico/numero/${num}`, {
      headers: { "Access-Token": at, "Accept": "application/json" }
    }, (res) => {
      let b = "";
      res.on("data", c => b += c);
      res.on("end", () => {
        try { resolve(JSON.parse(b)); }
        catch { resolve({ error: "parse_error" }); }
      });
    });
    req.on("error", e => resolve({ error: e.message }));
    req.setTimeout(8000, () => { req.destroy(); resolve({ error: "timeout" }); });
  });
}

// Sample OS from different months to understand the range
// OS 6412 = May 8, 2026 (recent)
// OS 6400 = March 5, 2026
// Let's find the range for Jan/Feb/Mar/Apr 2026

const testNums = [6000, 6050, 6100, 6150, 6200, 6250, 6300, 6350, 6400, 6412];
console.log("Sampling OS numbers to find date ranges...");
for (const num of testNums) {
  const os = await getOS(num);
  if (os.error) {
    console.log(`OS ${num}: ${os.error}`);
  } else {
    console.log(`OS ${num}: ${os.data_cadastro} | Cliente: ${os.cliente} | Valor: ${os.valor_total} | Tipo: ${os.tipo}`);
  }
}
