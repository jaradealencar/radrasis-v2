import dotenv from "dotenv";
dotenv.config();

const BASE = process.env.MUBISYS_PUBLIC_KEY
  ? `https://api.mubisys.com.br`
  : null;

const TOKEN = process.env.MUBISYS_ACCESS_TOKEN;
const PUBLIC_KEY = process.env.MUBISYS_PUBLIC_KEY;

if (!TOKEN || !PUBLIC_KEY) {
  console.error("MUBISYS_ACCESS_TOKEN ou MUBISYS_PUBLIC_KEY não definidos");
  process.exit(1);
}

const headers = {
  "Authorization": `Bearer ${TOKEN}`,
  "X-Public-Key": PUBLIC_KEY,
  "Content-Type": "application/json",
};

async function fetchPage(endpoint, page = 1, perPage = 100) {
  const url = `https://api.mubisys.com.br/${endpoint}?page=${page}&per_page=${perPage}&data_inicio=2026-05-01&data_fim=2026-05-31`;
  const res = await fetch(url, { headers });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText} - ${url}`);
  return res.json();
}

async function fetchAll(endpoint) {
  const first = await fetchPage(endpoint, 1, 100);
  const items = [...(first.data || [])];
  const lastPage = first.pagination?.last_page || 1;
  console.log(`  → ${endpoint}: página 1/${lastPage}, ${items.length} itens`);
  for (let p = 2; p <= lastPage; p++) {
    const page = await fetchPage(endpoint, p, 100);
    items.push(...(page.data || []));
    console.log(`  → ${endpoint}: página ${p}/${lastPage}, total acumulado: ${items.length}`);
  }
  return items;
}

async function main() {
  console.log("=== Diagnóstico Performance Comercial — Maio 2026 ===\n");

  // 1. Orçamentos
  console.log("1. Buscando orçamentos...");
  const orcamentos = await fetchAll("orcamento");
  const versaoAtual = orcamentos.filter(o => {
    const versao = o.versao ?? o.version ?? null;
    const versaoAtualField = o.versao_atual ?? o.current_version ?? null;
    if (versao !== null && versaoAtualField !== null) return versao == versaoAtualField;
    return true; // se não tem campo de versão, conta todos
  });
  const valorTotal = versaoAtual.reduce((sum, o) => {
    const vt = parseFloat(o.valor_total) || 0;
    const vc = parseFloat(o.valor_custo) || 0;
    const vm = parseFloat(o.valor_margem) || 0;
    return sum + (vt > 0 ? vt : vc + vm);
  }, 0);
  console.log(`  Total orçamentos brutos: ${orcamentos.length}`);
  console.log(`  Versão atual: ${versaoAtual.length}`);
  console.log(`  Valor orçado total: R$ ${valorTotal.toFixed(2)}`);
  if (orcamentos.length > 0) {
    const sample = orcamentos[0];
    console.log(`  Sample keys: ${Object.keys(sample).join(", ")}`);
    console.log(`  Sample versao: ${sample.versao}, versao_atual: ${sample.versao_atual}`);
    console.log(`  Sample valor_total: ${sample.valor_total}, valor_custo: ${sample.valor_custo}, valor_margem: ${sample.valor_margem}`);
  }

  // 2. OS
  console.log("\n2. Buscando OS...");
  const os = await fetchAll("ordem-servico");
  const tiposExcluidos = ["retrabalho", "amostra", "cortesia", "Retrabalho", "Amostra", "Cortesia"];
  const statusExcluidos = ["cancelado", "cancelada", "Cancelado", "Cancelada"];
  const osNormais = os.filter(o => {
    const tipo = (o.tipo || o.type || "").toLowerCase();
    const status = (o.status || "").toLowerCase();
    return !tiposExcluidos.map(t => t.toLowerCase()).includes(tipo)
      && !statusExcluidos.map(s => s.toLowerCase()).includes(status);
  });
  console.log(`  Total OS brutas: ${os.length}`);
  console.log(`  OS normais (sem retrabalho/amostra/cortesia/canceladas): ${osNormais.length}`);
  if (os.length > 0) {
    const tipos = [...new Set(os.map(o => o.tipo || o.type || "?"))];
    const statusList = [...new Set(os.map(o => o.status || "?"))];
    console.log(`  Tipos encontrados: ${tipos.join(", ")}`);
    console.log(`  Status encontrados: ${statusList.join(", ")}`);
  }

  // 3. Taxas
  console.log("\n3. Calculando taxas...");
  const cotacoes = versaoAtual.length;
  const osGeradas = osNormais.length;
  const taxaConversao = cotacoes > 0 ? (osGeradas / cotacoes * 100).toFixed(1) : 0;
  const faturamento = osNormais.reduce((sum, o) => sum + (parseFloat(o.valor_total) || 0), 0);
  const taxaFaturamento = valorTotal > 0 ? (faturamento / valorTotal * 100).toFixed(1) : 0;
  console.log(`  Cotações: ${cotacoes}`);
  console.log(`  OS Geradas: ${osGeradas}`);
  console.log(`  Taxa de Conversão: ${taxaConversao}%`);
  console.log(`  Valor Orçado: R$ ${valorTotal.toFixed(2)}`);
  console.log(`  Faturamento: R$ ${faturamento.toFixed(2)}`);
  console.log(`  Taxa de Faturamento: ${taxaFaturamento}%`);

  console.log("\n=== FIM DO DIAGNÓSTICO ===");
}

main().catch(console.error);
