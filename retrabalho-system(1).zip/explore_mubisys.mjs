const PUBLIC_KEY = process.env.MUBISYS_PUBLIC_KEY;
const ACCESS_TOKEN = process.env.MUBISYS_ACCESS_TOKEN;

console.log("PUBLIC_KEY:", PUBLIC_KEY ? PUBLIC_KEY.substring(0, 12) + "..." : "NOT SET");
console.log("ACCESS_TOKEN:", ACCESS_TOKEN ? ACCESS_TOKEN.substring(0, 12) + "..." : "NOT SET");

const BASE = `https://api.mubisys.com/api/${PUBLIC_KEY}`;

async function tryEndpoint(path, label) {
  try {
    const res = await fetch(`${BASE}${path}`, {
      headers: {
        Authorization: `Bearer ${ACCESS_TOKEN}`,
        Accept: "application/json",
      },
    });
    const text = await res.text();
    let preview = text.substring(0, 300);
    console.log(`\n[${res.status}] ${label} (${path})`);
    console.log(preview);
  } catch (e) {
    console.log(`\n[ERR] ${label}: ${e.message}`);
  }
}

// Explore possible endpoints
await tryEndpoint("/relatorio/vendas", "Relatório de Vendas");
await tryEndpoint("/relatorio/produtos", "Relatório de Produtos");
await tryEndpoint("/relatorio/clientes", "Relatório de Clientes");
await tryEndpoint("/produto", "Produtos");
await tryEndpoint("/cliente", "Clientes");
await tryEndpoint("/ordem-servico", "Ordens de Serviço");
await tryEndpoint("/ordem-servico?page=1&per_page=5", "OS paginadas");
await tryEndpoint("/relatorio", "Relatório raiz");
await tryEndpoint("/dashboard", "Dashboard");
await tryEndpoint("/venda", "Vendas");
await tryEndpoint("/faturamento", "Faturamento");
