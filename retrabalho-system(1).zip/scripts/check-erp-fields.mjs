import https from "https";

const publicKey = process.env.MUBISYS_PUBLIC_KEY;
const accessToken = process.env.MUBISYS_ACCESS_TOKEN;

function fetchApi(path) {
  return new Promise((resolve) => {
    const url = `https://api.mubisys.com/api/${publicKey}${path}`;
    const req = https.get(url, { headers: { "Access-Token": accessToken, Accept: "application/json" } }, (res) => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => { try { resolve(JSON.parse(body)); } catch { resolve({}); } });
    });
    req.on("error", () => resolve({}));
    req.setTimeout(15000, () => { req.destroy(); resolve({}); });
  });
}

const SKIP = ["itens", "processos_previstos", "processos_realizados", "comissoes", "custos_diversos", "hora_homem"];

const [os, orc] = await Promise.all([
  fetchApi("/ordem-servico?status=TODOS&filtrodata=APROVACAO&tipo=Normal&datainicial=2026-05-01&datafinal=2026-05-12&page=1&per_page=1"),
  fetchApi("/orcamento?status=TODOS&filtrodata=CADASTRO&datainicial=2026-05-01&datafinal=2026-05-12&page=1&per_page=1"),
]);

const osItem = os?.data?.[0];
const orcItem = orc?.data?.[0];

if (osItem) {
  const keys = Object.keys(osItem).filter(k => !SKIP.includes(k));
  console.log("=== OS CAMPOS ===");
  console.log(keys.join(", "));
  console.log("\nVALORES CHAVE:");
  console.log("  numero:", osItem.numero);
  console.log("  vendedor:", osItem.vendedor);
  console.log("  valor_total:", osItem.valor_total);
  console.log("  valor_custo:", osItem.valor_custo);
  console.log("  valor_margem:", osItem.valor_margem);
  console.log("  status:", osItem.status);
  console.log("  data_aprovacao:", osItem.data_aprovacao);
  console.log("  tipo:", osItem.tipo);
}

if (orcItem) {
  const keys = Object.keys(orcItem).filter(k => !SKIP.includes(k));
  console.log("\n=== ORÇAMENTO CAMPOS ===");
  console.log(keys.join(", "));
  console.log("\nVALORES CHAVE:");
  console.log("  numero:", orcItem.numero);
  console.log("  vendedor:", orcItem.vendedor);
  console.log("  valor_total:", orcItem.valor_total);
  console.log("  valor_custo:", orcItem.valor_custo);
  console.log("  valor_margem:", orcItem.valor_margem);
  console.log("  status:", orcItem.status);
  console.log("  data_cadastro:", orcItem.data_cadastro);
}
