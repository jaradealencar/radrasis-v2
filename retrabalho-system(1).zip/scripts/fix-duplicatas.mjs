import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

console.log('=== Removendo duplicatas de cidades ===\n');

// Buscar todos os grupos duplicados (manter o de menor id, que tem melhor qualidade de dados)
const [dupes] = await conn.execute(`
  SELECT transportadoraId, UPPER(cidade) as cidadeUpper, UPPER(estado) as estadoUpper, 
         COUNT(*) as total, MIN(id) as keepId
  FROM transportadora_cidades
  GROUP BY transportadoraId, UPPER(cidade), UPPER(estado)
  HAVING COUNT(*) > 1
`);

console.log(`Grupos com duplicatas: ${dupes.length}`);

let deleted = 0;
for (const d of dupes) {
  // Deletar todos exceto o de menor id (que geralmente tem dados mais completos - observacao, etc)
  // Mas preferir o que tem observacao preenchida
  const [rows] = await conn.execute(
    `SELECT id, cidade, observacao FROM transportadora_cidades 
     WHERE transportadoraId = ? AND UPPER(cidade) = ? AND UPPER(estado) = ?
     ORDER BY CASE WHEN observacao IS NOT NULL AND observacao != '' THEN 0 ELSE 1 END, id ASC`,
    [d.transportadoraId, d.cidadeUpper, d.estadoUpper]
  );
  
  // Manter o primeiro (com observacao ou menor id), deletar os demais
  const toDelete = rows.slice(1).map(r => r.id);
  if (toDelete.length > 0) {
    await conn.execute(
      `DELETE FROM transportadora_cidades WHERE id IN (${toDelete.map(() => '?').join(',')})`,
      toDelete
    );
    deleted += toDelete.length;
  }
}

console.log(`✅ Registros removidos: ${deleted}`);

// Verificar se ainda há duplicatas
const [remaining] = await conn.execute(`
  SELECT COUNT(*) as total FROM (
    SELECT transportadoraId, UPPER(cidade), UPPER(estado), COUNT(*) as cnt
    FROM transportadora_cidades
    GROUP BY transportadoraId, UPPER(cidade), UPPER(estado)
    HAVING COUNT(*) > 1
  ) t
`);
console.log(`Duplicatas restantes: ${remaining[0].total}`);

// Adicionar constraint UNIQUE para prevenir duplicatas futuras
// Primeiro verificar se já existe
const [indexes] = await conn.execute(`
  SHOW INDEX FROM transportadora_cidades WHERE Key_name = 'unique_transp_cidade_estado'
`);

if (indexes.length === 0) {
  console.log('\nAdicionando constraint UNIQUE...');
  try {
    await conn.execute(`
      ALTER TABLE transportadora_cidades 
      ADD CONSTRAINT unique_transp_cidade_estado 
      UNIQUE (transportadoraId, cidade(100), estado(5))
    `);
    console.log('✅ Constraint UNIQUE adicionada com sucesso!');
  } catch (err) {
    console.error('Erro ao adicionar constraint:', err.message);
  }
} else {
  console.log('Constraint UNIQUE já existe.');
}

// Contar total por transportadora
const [totais] = await conn.execute(`
  SELECT t.nome, COUNT(tc.id) as total
  FROM transportadoras t
  LEFT JOIN transportadora_cidades tc ON tc.transportadoraId = t.id
  GROUP BY t.id, t.nome
  ORDER BY total DESC
  LIMIT 10
`);
console.log('\nTop 10 transportadoras por número de cidades:');
totais.forEach(r => console.log(`  ${r.nome}: ${r.total}`));

await conn.end();
