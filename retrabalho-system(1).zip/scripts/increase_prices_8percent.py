#!/usr/bin/env python3
"""
Script para aumentar 8% os preços nas tabelas de preço (clientes tradicionais e novos)
"""

import mysql.connector
import json
import re
from datetime import datetime
from decimal import Decimal

# Configurações do banco de dados
DB_CONFIG = {
    'host': 'gateway05.us-east-1.prod.aws.tidbcloud.com',
    'port': 4000,
    'user': 'w9E6B1CFVfikCKB.cee5432df873',
    'password': 'WR6W2CnU8s1KSjQ2hWm0',
    'database': 'PzdanzaCSk4JPsdTBVnd3F',
    'ssl_disabled': False,
    'ssl_verify_cert': False,
    'ssl_verify_identity': False,
}

def connect_db():
    """Conecta ao banco de dados"""
    return mysql.connector.connect(**DB_CONFIG)

def extract_percentage(value_str):
    """Extrai percentual de uma string como '25,5%' ou '25.5%'"""
    if not value_str or value_str == 'NÃO DISPONÍVEL':
        return None
    
    # Remove 'R$' se existir
    value_str = value_str.replace('R$', '').strip()
    
    # Extrai o número (pode ter . ou , como separador decimal)
    match = re.search(r'[\d.,]+', value_str)
    if not match:
        return None
    
    num_str = match.group()
    # Converte para formato padrão (ponto como separador decimal)
    num_str = num_str.replace(',', '.')
    
    try:
        return float(num_str)
    except ValueError:
        return None

def format_percentage(value):
    """Formata um valor numérico como percentual"""
    if value is None:
        return 'NÃO DISPONÍVEL'
    
    # Arredonda para 1 casa decimal
    rounded = round(value, 1)
    
    # Formata com vírgula como separador decimal
    if rounded == int(rounded):
        return f"{int(rounded)}%"
    else:
        return f"{rounded}%".replace('.', ',')

def increase_percentage(value, percent_increase=8):
    """Aumenta um percentual em X%"""
    if value is None:
        return None
    
    # Aumenta 8% do valor
    return value * (1 + percent_increase / 100)

def process_json_prices(json_str, increase_percent=8):
    """Processa JSON de preços e aumenta todos os percentuais"""
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError:
        print(f"Erro ao decodificar JSON: {json_str[:100]}")
        return json_str
    
    # Processa diferentes tipos de estrutura JSON
    
    # Tipo: margin_table (simples)
    if data.get('type') == 'margin_table' and 'rows' in data:
        for row in data['rows']:
            if 'values' in row:
                new_values = []
                for val in row['values']:
                    percent = extract_percentage(val)
                    if percent is not None:
                        new_percent = increase_percentage(percent, increase_percent)
                        new_values.append(format_percentage(new_percent))
                    else:
                        new_values.append(val)
                row['values'] = new_values
    
    # Tipo: margin_table_multi (com múltiplas colunas)
    elif data.get('type') == 'margin_table_multi' and 'rows' in data:
        for row in data['rows']:
            if 'values' in row:
                new_values = []
                for val in row['values']:
                    percent = extract_percentage(val)
                    if percent is not None:
                        new_percent = increase_percentage(percent, increase_percent)
                        new_values.append(format_percentage(new_percent))
                    else:
                        new_values.append(val)
                row['values'] = new_values
    
    # Tipo: config (valores em R$)
    elif data.get('type') == 'config' and 'items' in data:
        for item in data['items']:
            if 'value' in item and item['value'].startswith('R$'):
                value_str = item['value'].replace('R$', '').strip()
                value_str = value_str.replace(',', '.')
                try:
                    value = float(value_str)
                    new_value = value * (1 + increase_percent / 100)
                    # Formata com 2 casas decimais e vírgula
                    item['value'] = f"R${new_value:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
                except ValueError:
                    pass
    
    return json.dumps(data, ensure_ascii=False)

def backup_tables(cursor):
    """Faz backup das tabelas antes de alterar (via mysqldump)"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    print(f"Criando backup das tabelas...")
    
    import subprocess
    
    # Backup price_table_sections
    backup_file_1 = f'/tmp/price_table_sections_backup_{timestamp}.sql'
    subprocess.run([
        'mysqldump',
        '--host=gateway05.us-east-1.prod.aws.tidbcloud.com',
        '--port=4000',
        '--user=w9E6B1CFVfikCKB.cee5432df873',
        f'--password=WR6W2CnU8s1KSjQ2hWm0',
        '--ssl-mode=REQUIRED',
        'PzdanzaCSk4JPsdTBVnd3F',
        'price_table_sections'
    ], stdout=open(backup_file_1, 'w'), stderr=subprocess.DEVNULL)
    print(f"✓ Backup criado: {backup_file_1}")
    
    # Backup price_table_meta
    backup_file_2 = f'/tmp/price_table_meta_backup_{timestamp}.sql'
    subprocess.run([
        'mysqldump',
        '--host=gateway05.us-east-1.prod.aws.tidbcloud.com',
        '--port=4000',
        '--user=w9E6B1CFVfikCKB.cee5432df873',
        f'--password=WR6W2CnU8s1KSjQ2hWm0',
        '--ssl-mode=REQUIRED',
        'PzdanzaCSk4JPsdTBVnd3F',
        'price_table_meta'
    ], stdout=open(backup_file_2, 'w'), stderr=subprocess.DEVNULL)
    print(f"✓ Backup criado: {backup_file_2}")
    
    return backup_file_1, backup_file_2

def update_price_table_sections(cursor, increase_percent=8):
    """Atualiza price_table_sections com aumento de 8%"""
    print(f"\nProcessando price_table_sections (Clientes Tradicionais)...")
    
    # Busca todos os registros
    cursor.execute("SELECT id, contentJson FROM price_table_sections")
    rows = cursor.fetchall()
    
    updated_count = 0
    for row_id, content_json in rows:
        new_json = process_json_prices(content_json, increase_percent)
        if new_json != content_json:
            cursor.execute(
                "UPDATE price_table_sections SET contentJson = %s, updatedAt = NOW() WHERE id = %s",
                (new_json, row_id)
            )
            updated_count += 1
    
    print(f"✓ {updated_count} registros atualizados em price_table_sections")
    return updated_count

def update_price_table_meta(cursor, increase_percent=8):
    """Atualiza price_table_meta com registro de alteração"""
    print(f"\nProcessando price_table_meta (Clientes Novos)...")
    
    timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
    note = f"Ajuste de +{increase_percent}% em {timestamp}"
    
    cursor.execute(
        "UPDATE price_table_meta SET descricao = CONCAT(COALESCE(descricao, ''), ' | ', %s), dataModificacao = NOW() WHERE id = 1",
        (note,)
    )
    
    print(f"✓ Registro de alteração adicionado em price_table_meta")
    return 1

def main():
    """Função principal"""
    print("=" * 60)
    print("AUMENTO DE 8% NOS PREÇOS")
    print("=" * 60)
    print(f"Timestamp: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    try:
        conn = connect_db()
        cursor = conn.cursor()
        
        # Faz backup
        backup_1, backup_2 = backup_tables(cursor)
        conn.commit()
        
        # Atualiza preços
        count_1 = update_price_table_sections(cursor, 8)
        count_2 = update_price_table_meta(cursor, 8)
        
        conn.commit()
        
        print()
        print("=" * 60)
        print("RESUMO DAS ALTERAÇÕES")
        print("=" * 60)
        print(f"✓ price_table_sections: {count_1} registros atualizados")
        print(f"✓ price_table_meta: {count_2} registros atualizados")
        print(f"✓ Backups criados: {backup_1}, {backup_2}")
        print()
        print("Aumento de 8% aplicado com sucesso!")
        print("=" * 60)
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main())
