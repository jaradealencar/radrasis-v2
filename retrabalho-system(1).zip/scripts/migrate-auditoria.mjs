import { createConnection } from "mysql2/promise";
import * as dotenv from "dotenv";

dotenv.config();

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

const conn = await createConnection(DATABASE_URL);

const sqls = [
  `CREATE TABLE IF NOT EXISTS \`auditoria_retrabalhos\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`retrabalhoId\` int,
    \`osRetrabalhada\` varchar(32),
    \`osOriginal\` varchar(64),
    \`acao\` enum('CRIACAO','EDICAO','EXCLUSAO') NOT NULL,
    \`usuarioId\` int,
    \`usuarioNome\` varchar(128),
    \`usuarioRole\` varchar(32),
    \`detalhes\` text,
    \`createdAt\` timestamp NOT NULL DEFAULT (now()),
    CONSTRAINT \`auditoria_retrabalhos_id\` PRIMARY KEY(\`id\`)
  )`,
  `ALTER TABLE \`transportadoras\` ADD COLUMN IF NOT EXISTS \`portalSenha\` varchar(256)`,
  `ALTER TABLE \`transportadoras\` ADD COLUMN IF NOT EXISTS \`ultAtualizCidades\` varchar(16)`,
  `ALTER TABLE \`transportadoras\` ADD COLUMN IF NOT EXISTS \`contatoRastreio\` text`,
];

for (const sql of sqls) {
  try {
    await conn.execute(sql);
    console.log("OK:", sql.slice(0, 60).replace(/\n/g, " ").trim() + "...");
  } catch (err) {
    if (err.code === "ER_DUP_FIELDNAME" || err.code === "ER_TABLE_EXISTS_ERROR") {
      console.log("SKIP (already exists):", sql.slice(0, 60).replace(/\n/g, " ").trim() + "...");
    } else {
      console.error("ERROR:", err.message, "\nSQL:", sql.slice(0, 80));
    }
  }
}

await conn.end();
console.log("Migration complete.");
