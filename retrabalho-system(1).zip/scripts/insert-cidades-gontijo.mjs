import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
dotenv.config({ path: resolve(process.cwd(), ".env") });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Encontrar a Gontijo
const [transportadoras] = await conn.execute(
  "SELECT id, nome FROM transportadoras WHERE nome LIKE '%ontijo%'"
);

if (transportadoras.length === 0) {
  const [todas] = await conn.execute("SELECT id, nome FROM transportadoras ORDER BY nome");
  console.log("Transportadoras disponíveis:", todas.map(t => `${t.nome} (ID:${t.id})`).join(", "));
  await conn.end();
  process.exit(1);
}

const gontijo = transportadoras[0];
console.log(`Transportadora: ${gontijo.nome} (ID: ${gontijo.id})`);

// Todas as cidades extraídas do PDF por estado
const cidades = [
  // ALAGOAS
  ["AL","ARAPIRACA"],["AL","BRANQUINHA"],["AL","MACEIÓ"],["AL","MARECHAL DEODORO"],
  ["AL","MESSIAS"],["AL","MURICI"],["AL","PILAR"],["AL","RIO LARGO"],
  ["AL","SÃO MIGUEL DOS CAMPOS"],["AL","SATUBA"],["AL","UNIÃO DOS PALMARES"],
  // BAHIA
  ["BA","ALAGOINHAS"],["BA","ALCOBAÇA"],["BA","BOM JESUS DA LAPA"],["BA","BRUMADO"],
  ["BA","CAETITÉ"],["BA","CALDAS DO JORRO"],["BA","CAMAÇARI"],["BA","CANDEIAS"],
  ["BA","DIAS D'ÁVILA"],["BA","EUCLIDES DA CUNHA"],["BA","EUNÁPOLIS"],
  ["BA","FEIRA DE SANTANA"],["BA","GUANAMBI"],["BA","ILHÉUS"],["BA","ITABUNA"],
  ["BA","ITAMARAJU"],["BA","IPIAÚ"],["BA","JACOBINA"],["BA","JEQUIÉ"],
  ["BA","JEREMOABO"],["BA","JUAZEIRO"],["BA","LAURO DE FREITAS"],["BA","MIGUEL CALMON"],
  ["BA","MILAGRES"],["BA","MONTE SANTO"],["BA","MUCURI"],["BA","PAULO AFONSO"],
  ["BA","PILÃO ARCADO"],["BA","PINDAÍ"],["BA","POÇÕES"],["BA","PORTO SEGURO"],
  ["BA","PRADO"],["BA","REMANSO"],["BA","RIACHO DE SANTANA"],["BA","RIBEIRA DO POMBAL"],
  ["BA","SALVADOR"],["BA","SANTA MARIA DA VITÓRIA"],["BA","SANTANA"],
  ["BA","SENHOR DO BONFIM"],["BA","SERRINHA"],["BA","SIMÕES FILHO"],
  ["BA","TEIXEIRA DE FREITAS"],["BA","TUCANO"],["BA","VALENÇA"],
  ["BA","VITÓRIA DA CONQUISTA"],
  // CEARÁ
  ["CE","CRATEÚS"],["CE","CRATO"],["CE","FORTALEZA"],["CE","IGUATU"],
  ["CE","JUAZEIRO DO NORTE"],["CE","NOVA RUSSAS"],["CE","SOBRAL"],
  ["CE","GUARACIABA DO NORTE"],["CE","TIANGUÁ"],
  // ESPÍRITO SANTO
  ["ES","ANCHIETA"],["ES","CACHOEIRO DE ITAPEMIRIM"],["ES","CARAPINA"],
  ["ES","CARIACICA"],["ES","CONCEIÇÃO DA BARRA"],["ES","GUARAPARI"],
  ["ES","LINHARES"],["ES","MARATAÍZES"],["ES","PEDRO CANÁRIO"],["ES","PIÚMA"],
  ["ES","SÃO MATEUS"],["ES","SERRA"],["ES","VIANA"],["ES","VILA VELHA"],["ES","VITÓRIA"],
  // GOIÁS
  ["GO","GOIÂNIA"],["GO","MINEIROS"],["GO","SÃO SIMÃO"],
  // MINAS GERAIS
  ["MG","ÁGUA BOA"],["MG","ÁGUAS FORMOSAS"],["MG","AIMORÉS"],["MG","ALMENARA"],
  ["MG","ARAÇUAÍ"],["MG","ARAXÁ"],["MG","BARBACENA"],["MG","BELO HORIZONTE"],
  ["MG","BETIM"],["MG","BOCAIÚVA"],["MG","BONFIM"],["MG","BRUMADINHO"],
  ["MG","BUENÓPOLIS"],["MG","BURITIZEIRO"],["MG","CAMPO BELO"],["MG","CAPELINHA"],
  ["MG","CAPIM BRANCO"],["MG","CARATINGA"],["MG","CARMO DO PARANAÍBA"],
  ["MG","CARMÓPOLIS DE MINAS"],["MG","CAXIMBU"],["MG","CAPITÓLIO"],["MG","CONFINS"],
  ["MG","CONSELHEIRO PENA"],["MG","CONTAGEM"],["MG","CORINTO"],
  ["MG","CORONEL FABRICIANO"],["MG","CURVELO"],["MG","DIAMANTINA"],
  ["MG","DIVINÓPOLIS"],["MG","ESMERALDAS"],["MG","ESPERA FELIZ"],["MG","ESPINOSA"],
  ["MG","FORMIGA"],["MG","FRUTAL"],["MG","GOVERNADOR VALADARES"],["MG","GUANHÃES"],
  ["MG","IBIRITÉ"],["MG","IGARAPÉ"],["MG","IPATINGA"],["MG","ITAGUARA"],
  ["MG","ITAMBACURI"],["MG","ITAOBIM"],["MG","ITATIAIUÇU"],["MG","ITUIUTABA"],
  ["MG","ITURAMA"],["MG","JANUÁRIA"],["MG","JEQUITINHONHA"],["MG","JOÃO MONLEVADE"],
  ["MG","JOÃO PINHEIRO"],["MG","JUATUBA"],["MG","JUIZ DE FORA"],["MG","LAGOA SANTA"],
  ["MG","LAVRAS"],["MG","LEOPOLDINA"],["MG","LUZ"],["MG","MALACACHETA"],
  ["MG","MANGA"],["MG","MANHUAÇU"],["MG","MANTENA"],["MG","MARIO CAMPOS"],
  ["MG","MATEUS LEME"],["MG","MATO VERDE"],["MG","MATOZINHOS"],["MG","MINAS NOVAS"],
  ["MG","MONTALVÂNIA"],["MG","MONTE AZUL"],["MG","MONTES CLAROS"],["MG","NANUQUE"],
  ["MG","NOVA LIMA"],["MG","NOVA SERRANA"],["MG","PARA DE MINAS"],["MG","PASSOS"],
  ["MG","PATOS DE MINAS"],["MG","PATROCÍNIO"],["MG","PEDRA AZUL"],
  ["MG","PEDRO LEOPOLDO"],["MG","PERDÕES"],["MG","PIRAPORA"],
  ["MG","PRUDENTE DE MORAIS"],["MG","RAPOSOS"],["MG","REALEZA"],
  ["MG","RIBEIRÃO DAS NEVES"],["MG","RIO ACIMA"],["MG","RIO MANSO"],["MG","SABARÃ"],
  ["MG","SACRAMENTO"],["MG","SALINAS"],["MG","SALTO DA DIVISA"],["MG","SANTA LUZIA"],
  ["MG","SÃO FRANCISCO"],["MG","SÃO GOTARDO"],["MG","SÃO JOÃO DEL REI"],
  ["MG","SÃO JOÃO DO PARAÍSO"],["MG","SÃO JOÃO EVANGELISTA"],
  ["MG","SÃO JOAQUIM DE BICAS"],["MG","SÃO JOSÉ DA LAPA"],["MG","SÃO LOURENÇO"],
  ["MG","SARZEDO"],["MG","SETE LAGOAS"],["MG","TAIOBEIRAS"],["MG","TEÓFILO OTONI"],
  ["MG","TIMÓTEO"],["MG","TURMALINA"],["MG","UBERABA"],["MG","UBERLÂNDIA"],
  ["MG","VARGINHA"],["MG","VÁRZEA DA PALMA"],["MG","VESPASIANO"],
  // MATO GROSSO
  ["MT","CUIABÁ"],["MT","RONDONÓPOLIS"],["MT","VÁRZEA GRANDE"],
  // MATO GROSSO DO SUL
  ["MS","CAMPO GRANDE"],["MS","TRÊS LAGOAS"],
  // PARAÍBA
  ["PB","BAYEUX"],["PB","CABEDELO"],["PB","CAJAZEIRAS"],["PB","CAMPINA GRANDE"],
  ["PB","JOÃO PESSOA"],["PB","PATOS"],["PB","SOUSA"],
  // PARANÁ
  ["PR","ARAUCÁRIA"],["PR","CASCAVEL"],["PR","COLOMBO"],["PR","CURITIBA"],
  ["PR","FOZ DO IGUAÇU"],["PR","LONDRINA"],["PR","MARINGÁ"],["PR","PINHAIS"],
  ["PR","SÃO JOSÉ DOS PINHAIS"],["PR","TOLEDO"],
  // PERNAMBUCO
  ["PE","ABREU E LIMA"],["PE","CAMARAJIBE"],["PE","GARANHUNS"],
  ["PE","JABOATÃO DOS GUARARAPES"],["PE","OLINDA"],["PE","PAULISTA"],
  ["PE","PETROLINA"],["PE","RECIFE"],["PE","SALGUEIRO"],
  ["PE","SÃO LOURENÇO DA MATA"],["PE","SERRA TALHADA"],
  // PIAUÍ
  ["PI","PICOS"],["PI","SÃO RAIMUNDO NONATO"],["PI","TERESINA"],
  // RIO DE JANEIRO
  ["RJ","BELFORD ROXO"],["RJ","CAMPOS DOS GOYTACAZES"],["RJ","DUQUE DE CAXIAS"],
  ["RJ","MESQUITA"],["RJ","NILÓPOLIS"],["RJ","NITERÓI"],["RJ","NOVA IGUAÇU"],
  ["RJ","PARAÍBA DO SUL"],["RJ","RIO DE JANEIRO"],["RJ","SÃO GONÇALO"],
  ["RJ","SÃO JOÃO DE MERITI"],["RJ","VOLTA REDONDA"],
  // RIO GRANDE DO NORTE
  ["RN","CURRAIS NOVOS"],["RN","MACAÍBA"],["RN","MOSSORÓ"],["RN","NATAL"],
  ["RN","PARNAMIRIM"],["RN","PAU DOS FERROS"],
  // RONDÔNIA
  ["RO","ARIQUEMES"],["RO","JI-PARANÁ"],["RO","PORTO VELHO"],["RO","VILHENA"],
  ["RO","OURO PRETO DO OESTE"],
  // DISTRITO FEDERAL
  ["DF","BRASÍLIA"],
  // SÃO PAULO
  ["SP","APARECIDA DO NORTE"],["SP","ARAÇATUBA"],["SP","ARARAQUARA"],["SP","BAURU"],
  ["SP","BARUERI"],["SP","CAMPINAS"],["SP","CUBATÃO"],["SP","DIADEMA"],
  ["SP","FRANCA"],["SP","GUARULHOS"],["SP","ITAQUAQUECETUBA"],["SP","JAÚ"],
  ["SP","MARÍLIA"],["SP","MAUÁ"],["SP","OSASCO"],["SP","PAULÍNIA"],
  ["SP","PRESIDENTE PRUDENTE"],["SP","RIBEIRÃO PRETO"],["SP","RIO CLARO"],
  ["SP","ROSEIRA"],["SP","SANTO AMARO"],["SP","SANTO ANDRÉ"],["SP","SANTOS"],
  ["SP","SÃO BERNARDO DO CAMPO"],["SP","SÃO CAETANO DO SUL"],
  ["SP","SÃO JOSÉ DO RIO PRETO"],["SP","SÃO JOSÉ DOS CAMPOS"],["SP","SÃO PAULO"],
  ["SP","TABOÃO DA SERRA"],["SP","TAUBATÉ"],
  // SERGIPE
  ["SE","ARACAJU"],["SE","CARMÓPOLIS"],["SE","ESTÂNCIA"],["SE","ITABAIANA"],
  ["SE","LAGARTO"],["SE","LARANJEIRAS"],["SE","NOSSA SENHORA DAS DORES"],
  ["SE","NOSSA SENHORA DO SOCORRO"],["SE","PRÓPRIA"],["SE","ROSÁRIO DO CATETE"],
  ["SE","SÃO CRISTÓVÃO"],["SE","SIMÃO DIAS"],["SE","TOBIAS BARRETO"],
];

console.log(`Total de cidades a inserir: ${cidades.length}`);

// Verificar existentes
const [existentes] = await conn.execute(
  "SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?",
  [gontijo.id]
);
const existSet = new Set(existentes.map(c => `${c.estado}|${c.cidade}`));
console.log(`Cidades já cadastradas: ${existSet.size}`);

const novas = cidades.filter(([uf, cidade]) => !existSet.has(`${uf}|${cidade}`));
console.log(`Cidades novas a inserir: ${novas.length}`);
console.log(`Já existentes (puladas): ${cidades.length - novas.length}`);

if (novas.length === 0) {
  console.log("Todas as cidades já estão cadastradas!");
  await conn.end();
  process.exit(0);
}

// Inserir em lotes
const BATCH = 50;
let inseridas = 0;
for (let i = 0; i < novas.length; i += BATCH) {
  const lote = novas.slice(i, i + BATCH);
  const placeholders = lote.map(() => "(?, ?, ?, ?, ?)").join(", ");
  const valores = lote.flatMap(([uf, cidade]) => [gontijo.id, cidade, uf, null, null]);
  await conn.execute(
    `INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, telefone, observacao) VALUES ${placeholders}`,
    valores
  );
  inseridas += lote.length;
  process.stdout.write(`\r  Inserindo... ${inseridas}/${novas.length}`);
}

// Atualizar data
const hoje = new Date().toISOString().slice(0, 10);
await conn.execute("UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = ?", [hoje, gontijo.id]);

console.log(`\n\n✅ Concluído! ${inseridas} cidades inseridas para a ${gontijo.nome}.`);
console.log(`📅 Data de atualização: ${hoje}`);

// Resumo por estado
const estados = {};
for (const [uf] of novas) {
  estados[uf] = (estados[uf] || 0) + 1;
}
console.log("\nResumo por estado:");
for (const [uf, qtd] of Object.entries(estados).sort()) {
  console.log(`  ${uf}: ${qtd} cidades`);
}

await conn.end();
