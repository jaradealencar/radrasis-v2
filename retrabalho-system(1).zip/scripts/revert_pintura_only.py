#!/usr/bin/env python3
"""
Script para reverter apenas os valores de pintura aos originais,
mantendo o aumento de 8% em todos os outros itens
"""

import mysql.connector
import json
from datetime import datetime

# Configurações do banco de dados
DB_CONFIG = {
    'host': 'gateway05.us-east-1.prod.aws.tidbcloud.com',
    'port': 4000,
    'user': 'w9E6B1CFVfikCKB.cee5432df873',
    'password': 'WR6W2CnU8s1KSjQ2hWm0',
    'database': 'PzdanzaCSk4JPsdTBVnd3F',
    'ssl_disabled': False,
    'ssl_verify_cert': False,
    'ssl_verify_identity': False,
}

def connect_db():
    """Conecta ao banco de dados"""
    return mysql.connector.connect(**DB_CONFIG)

def revert_pintura_values(cursor):
    """Reverte apenas os valores de pintura aos originais"""
    print("Revertendo valores de pintura aos originais...")
    
    # Mapeamento de IDs de pintura para seus valores originais
    # Baseado no backup
    pintura_mappings = {
        18: {  # Configurações Gerais — Pintura
            'type': 'config',
            'items': [
                {'label': 'Valor Mínimo Pintura Galvanizado', 'value': 'R$200,00', 'highlight': 'yellow'},
                {'label': 'Valor Mínimo Verniz Dourado Inox', 'value': 'R$340,00', 'highlight': 'yellow'},
                {'label': 'Pintura Mínima Objeto Pequeno', 'value': 'Complementar R$95,00', 'highlight': 'blue'}
            ]
        },
        19: {  # Serviço de Pintura Galvanizado - PU (Poliuretano)
            'type': 'margin_table_multi',
            'columns': ['Área', '1 cor', '2 cores', '3/4 cores', 'Cores Metalizadas'],
            'rows': [
                {'label': 'Faixa 1 — Menor que 0,34m²', 'values': ['27,8%', '29,9%', 'NÃO DISPONÍVEL', '20,6%']},
                {'label': 'Faixa 2 — Entre 0,35 e 0,60m²', 'values': ['27,8%', '29,9%', 'NÃO DISPONÍVEL', '20,6%']},
                {'label': 'Faixa 3 — Entre 0,62 e 1m²', 'values': ['39%', '44,1%', 'NÃO DISPONÍVEL', '23,5%']},
                {'label': 'Faixa 4 — Entre 1,1 e 1,5m²', 'values': ['34,9%', '40%', '43,1%', '23,5%']},
                {'label': 'Faixa 5 — Entre 1,51m² e 4m²', 'values': ['32,8%', '38%', '41,1%', '20,5%']},
                {'label': 'Faixa 6 — Entre 4,1m² e 8m²', 'values': ['30,8%', '35,9%', '39%', '20,5%']},
                {'label': 'Faixa 7 — Entre 8,1m² e 12m²', 'values': ['23,7%', '28,8%', '31,9%', '13,4%']},
                {'label': 'Faixa 8 — Acima de 12,1m²', 'values': ['21,6%', '26,8%', '29,9%', '13,4%']}
            ]
        },
        20: {  # Serviço de Pintura PVC - PU (Poliuretano)
            'type': 'margin_table_multi',
            'columns': ['Área', '1 cor', '2 cores', '3/4 cores', 'Cores Metalizadas'],
            'rows': [
                {'label': 'Faixa 1 — Menor que 0,34m²', 'values': ['31%', '33%', 'NÃO DISPONÍVEL', '25%']},
                {'label': 'Faixa 2 — Entre 0,35 e 0,60m²', 'values': ['31%', '33%', 'NÃO DISPONÍVEL', '25%']},
                {'label': 'Faixa 3 — Entre 0,62 e 1m²', 'values': ['38%', '43%', 'NÃO DISPONÍVEL', '23%']},
                {'label': 'Faixa 4 — Entre 1,1 e 1,5m²', 'values': ['34%', '39%', '42%', '23%']},
                {'label': 'Faixa 5 — Entre 1,51m² e 4m²', 'values': ['32%', '37%', '40%', '20%']},
                {'label': 'Faixa 6 — Entre 4,1m² e 8m²', 'values': ['30%', '35%', '38%', '20%']},
                {'label': 'Faixa 7 — Entre 8,1m² e 12m²', 'values': ['28%', '33%', '36%', '18%']},
                {'label': 'Faixa 8 — Acima de 12,1m²', 'values': ['26%', '31%', '34%', '18%']}
            ]
        },
        21: {  # Verniz Dourado Inox — Somente áreas internas
            'type': 'margin_table_multi',
            'columns': ['Área', 'Margem'],
            'rows': [
                {'label': 'Faixa 1 — Menor que 0,34m²', 'values': ['33%']},
                {'label': 'Faixa 2 — Entre 0,35 e 0,75m²', 'values': ['33%']},
                {'label': 'Faixa 3 — Entre 0,75 e 1m²', 'values': ['27%']},
                {'label': 'Faixa 4 — Entre 1m² e 1,5m²', 'values': ['27%']},
                {'label': 'Faixa 5 — Entre 1,6m² e 4m²', 'values': ['22%']},
                {'label': 'Faixa 6 — Entre 4,1m² e 8m²', 'values': ['22%']},
                {'label': 'Faixa 7 — Entre 8,1m² e 12m²', 'values': ['24%']},
                {'label': 'Faixa 8 — Acima de 12,1m²', 'values': ['24%']}
            ]
        }
    }
    
    updated_count = 0
    
    # Reverte cada tabela de pintura
    for row_id, original_data in pintura_mappings.items():
        json_str = json.dumps(original_data, ensure_ascii=False)
        cursor.execute(
            "UPDATE price_table_sections SET contentJson = %s, updatedAt = NOW() WHERE id = %s",
            (json_str, row_id)
        )
        updated_count += 1
        print(f"  ✓ ID {row_id} revertido")
    
    return updated_count

def main():
    """Função principal"""
    print("=" * 60)
    print("REVERTER VALORES DE PINTURA AOS ORIGINAIS")
    print("=" * 60)
    print(f"Timestamp: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    try:
        conn = connect_db()
        cursor = conn.cursor()
        
        # Reverte apenas pintura
        count = revert_pintura_values(cursor)
        
        conn.commit()
        
        print()
        print("=" * 60)
        print("RESUMO")
        print("=" * 60)
        print(f"✓ {count} tabelas de pintura revertidas aos valores originais")
        print(f"✓ Todos os outros itens mantêm o aumento de 8%")
        print()
        print("Reversão concluída com sucesso!")
        print("=" * 60)
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main())
