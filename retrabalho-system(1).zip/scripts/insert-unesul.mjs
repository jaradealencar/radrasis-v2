import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Buscar ID da Unesul
const [rows] = await conn.execute("SELECT id FROM transportadoras WHERE nome LIKE '%nesul%'");
if (!rows.length) { console.error('Unesul não encontrada!'); process.exit(1); }
const transportadoraId = rows[0].id;
console.log('Unesul ID:', transportadoraId);

const today = new Date().toISOString().slice(0, 10);
const now = new Date().toISOString().slice(0, 19).replace('T', ' ');

// Carregar dados extraídos
const cidades = JSON.parse(readFileSync('/tmp/unesul_cidades.json', 'utf-8'));
const filiaisBrutas = JSON.parse(readFileSync('/tmp/unesul_filiais.json', 'utf-8'));

// Filtrar filiais inválidas
const invalidos = new Set(['Mg', 'Apenas Com Nota Fiscal', 'Todos', 'Cif', 'Rodoviaria']);
const filiais = filiaisBrutas.filter(f => !invalidos.has(f.cidade) && f.cidade.length > 2);

// Limpar cidades existentes da Unesul para reinserir com dados atualizados
await conn.execute('DELETE FROM transportadora_cidades WHERE transportadoraId = ?', [transportadoraId]);
await conn.execute('DELETE FROM transportadora_filiais WHERE transportadoraId = ?', [transportadoraId]);
console.log('Dados antigos removidos.');

// Inserir cidades em lotes de 100
let cidadesInseridas = 0;
const lote = 100;
for (let i = 0; i < cidades.length; i += lote) {
  const batch = cidades.slice(i, i + lote);
  for (const c of batch) {
    try {
      await conn.execute(
        'INSERT IGNORE INTO transportadora_cidades (transportadoraId, cidade, estado, telefone, endereco, createdAt) VALUES (?,?,?,?,?,?)',
        [transportadoraId, c.cidade, c.estado, c.telefone || null, c.endereco || null, now]
      );
      cidadesInseridas++;
    } catch (e) {
      // ignorar duplicatas
    }
  }
}
console.log('Cidades inseridas:', cidadesInseridas);

// Inserir filiais
let filiaisInseridas = 0;
for (const f of filiais) {
  // Limpar endereço (remover texto após cidade_base)
  let endereco = f.endereco || null;
  if (endereco) {
    // Remover lixo após o endereço real (colunas extras do PDF)
    endereco = endereco.replace(/\s{3,}.*$/, '').trim();
    if (endereco.length > 200) endereco = endereco.slice(0, 200);
  }
  
  // Contato: se não for SAC UNESUL, usar como responsável
  const responsavel = f.contato && f.contato !== 'SAC UNESUL' ? f.contato : null;
  
  try {
    await conn.execute(
      'INSERT INTO transportadora_filiais (transportadoraId, nome, cidade, estado, endereco, telefone, responsavel, createdAt) VALUES (?,?,?,?,?,?,?,?)',
      [transportadoraId, f.nome, f.cidade, f.estado, endereco, f.telefone || null, responsavel, now]
    );
    filiaisInseridas++;
  } catch (e) {
    // Tentar sem responsavel se coluna não existir
    try {
      await conn.execute(
        'INSERT INTO transportadora_filiais (transportadoraId, nome, cidade, estado, endereco, telefone, createdAt) VALUES (?,?,?,?,?,?,?)',
        [transportadoraId, f.nome, f.cidade, f.estado, endereco, f.telefone || null, now]
      );
      filiaisInseridas++;
    } catch (e2) {
      console.error('Erro filial:', f.nome, e2.message);
    }
  }
}
console.log('Filiais inseridas:', filiaisInseridas);

// Atualizar data de cidades
await conn.execute('UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = ?', [today, transportadoraId]);
console.log('Data de atualização definida para:', today);

await conn.end();
console.log('Concluído!');
