import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const sections = [
  // Página 4 — Instalação
  {
    page: 4,
    sectionOrder: 1,
    sectionTitle: "Serviços de Instalação",
    contentJson: JSON.stringify({
      type: "margin_table",
      columns: ["Valor Base", "Observação"],
      rows: [
        { label: "Instalação simples (fachada plana)", values: ["Consultar", "Por m²"] },
        { label: "Instalação com andaime", values: ["Consultar", "Inclui locação"] },
        { label: "Instalação com balancim", values: ["Consultar", "Acima de 5m"] },
        { label: "Retirada de letreiro antigo", values: ["Consultar", "Por peça"] },
        { label: "Instalação de LED externo", values: ["Consultar", "Por módulo"] },
      ],
    }),
    notes: null,
  },
  // Página 5 — Condições Comerciais
  {
    page: 5,
    sectionOrder: 1,
    sectionTitle: "Condições de Pagamento",
    contentJson: JSON.stringify({
      type: "list",
      items: [
        "À vista: sem acréscimo",
        "Boleto 7 dias: sem acréscimo",
        "Boleto 14 dias: +1,5%",
        "Boleto 21 dias: +2,5%",
        "Boleto 28 dias: +3,5%",
        "Cartão de crédito à vista: +3,5% (maquininha) ou +4,5% (link)",
        "Pix: sem acréscimo",
      ],
    }),
    notes: null,
  },
  {
    page: 5,
    sectionOrder: 2,
    sectionTitle: "Política de Descontos",
    contentJson: JSON.stringify({
      type: "list",
      items: [
        "Desconto máximo de 2% SOMENTE COM APROVAÇÃO DE DANIEL",
        "Descontos acima de 2% devem ser aprovados pela diretoria",
        "Não conceder descontos em pedidos com prazo de entrega urgente",
      ],
    }),
    notes: "Atenção: desconto máximo de 2% com aprovação de Daniel.",
  },
  {
    page: 5,
    sectionOrder: 3,
    sectionTitle: "Prazo de Entrega e Frete",
    contentJson: JSON.stringify({
      type: "list",
      items: [
        "Prazo padrão: conforme combinado em pedido",
        "Frete: a combinar conforme localização e volume",
        "Entregas urgentes podem ter acréscimo no valor",
      ],
    }),
    notes: null,
  },
];

for (const s of sections) {
  await conn.execute(
    "INSERT INTO price_table_sections (page, sectionOrder, sectionTitle, contentJson, notes) VALUES (?, ?, ?, ?, ?)",
    [s.page, s.sectionOrder, s.sectionTitle, s.contentJson, s.notes]
  );
  console.log(`✓ Inserido: Pág. ${s.page} — ${s.sectionTitle}`);
}

await conn.end();
console.log("\nPáginas 4 e 5 inseridas no banco com sucesso!");
