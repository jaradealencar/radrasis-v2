/**
 * Script para regenerar o cache da curva ABC de Fevereiro e Março 2026
 * sem os itens "Desconhecido".
 * Uso: node scripts/regenerate-abc-cache.mjs
 */
import https from "https";
import { createConnection } from "mysql2/promise";
import * as dotenv from "dotenv";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: join(__dirname, "../.env") });

const MUBISYS_PUBLIC_KEY = process.env.MUBISYS_PUBLIC_KEY ?? "";
const MUBISYS_ACCESS_TOKEN = process.env.MUBISYS_ACCESS_TOKEN ?? "";
const DATABASE_URL = process.env.DATABASE_URL ?? "";

if (!MUBISYS_PUBLIC_KEY || !MUBISYS_ACCESS_TOKEN) {
  console.error("❌ MUBISYS_PUBLIC_KEY ou MUBISYS_ACCESS_TOKEN não configurados");
  process.exit(1);
}

function fetchMubisysOsList(datainicial, datafinal, page = 1) {
  return new Promise((resolve) => {
    const path = `/ordem-servico?status=TODOS&filtrodata=CADASTRO&datainicial=${datainicial}&datafinal=${datafinal}&page=${page}&per_page=500`;
    const url = `https://api.mubisys.com/api/${MUBISYS_PUBLIC_KEY}${path}`;
    const req = https.get(
      url,
      { headers: { "Access-Token": MUBISYS_ACCESS_TOKEN, Accept: "application/json" } },
      (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => {
          try {
            resolve({ status: res.statusCode ?? 0, data: JSON.parse(body) });
          } catch {
            resolve({ status: res.statusCode ?? 0, data: {} });
          }
        });
      }
    );
    req.on("error", () => resolve({ status: 0, data: {} }));
    req.setTimeout(30000, () => {
      req.destroy();
      resolve({ status: 0, data: { error: "timeout" } });
    });
  });
}

async function fetchAllOsForMonth(ano, mes) {
  const start = `${ano}-${String(mes).padStart(2, "0")}-01`;
  const lastDay = new Date(ano, mes, 0).getDate();
  const end = `${ano}-${String(mes).padStart(2, "0")}-${lastDay}`;

  let all = [];
  let page = 1;
  console.log(`  Buscando OS de ${start} a ${end}...`);

  while (true) {
    const { status, data } = await fetchMubisysOsList(start, end, page);
    if (status !== 201) {
      console.log(`  Página ${page}: status=${status}, parando.`);
      break;
    }
    const items = data.data ?? [];
    all = all.concat(items);
    console.log(`  Página ${page}: ${items.length} OS (total: ${all.length})`);
    const pagination = data.pagination;
    if (!pagination || page >= (pagination.last_page ?? 1)) break;
    page++;
  }

  return all;
}

function buildAbcProdutos(osArray) {
  const prodMap = {};
  let totalOs = 0;

  for (const os of osArray) {
    if (os.tipo === "Retrabalho") continue;
    totalOs++;
    for (const item of os.itens ?? []) {
      const prod = (
        item.item ??
        item.descricao ??
        item.produto ??
        item.nome ??
        ""
      ).toString().trim();
      // Pular itens sem nome identificável — não exibir como 'Desconhecido'
      if (!prod) continue;
      const valor = parseFloat(String(item.valor_final ?? item.sub_total ?? 0));
      if (!prodMap[prod]) prodMap[prod] = { total: 0, count: 0 };
      prodMap[prod].total += valor;
      prodMap[prod].count += item.quantidade ?? 1;
    }
  }

  const sorted = Object.entries(prodMap)
    .map(([nome, d]) => ({ nome, total: d.total, count: d.count }))
    .sort((a, b) => b.total - a.total);

  const faturamento = sorted.reduce((s, r) => s + r.total, 0);
  let acum = 0;

  const items = sorted.slice(0, 50).map((r) => {
    acum += r.total;
    const pct = faturamento > 0 ? (r.total / faturamento) * 100 : 0;
    const pctAcum = faturamento > 0 ? (acum / faturamento) * 100 : 0;
    const classe = pctAcum <= 80 ? "A" : pctAcum <= 95 ? "B" : "C";
    return {
      nome: r.nome,
      total: r.total,
      count: r.count,
      pct: pct.toFixed(1),
      pctAcum: pctAcum.toFixed(1),
      classe,
    };
  });

  return { items, totalOs, faturamento };
}

async function main() {
  // Parse DATABASE_URL
  const dbUrl = new URL(DATABASE_URL);
  const conn = await createConnection({
    host: dbUrl.hostname,
    port: parseInt(dbUrl.port || "3306"),
    user: dbUrl.username,
    password: dbUrl.password,
    database: dbUrl.pathname.replace("/", ""),
    ssl: { rejectUnauthorized: false },
  });

  const meses = [1, 2, 3]; // Janeiro, Fevereiro e Março
  const ano = 2026;

  for (const mes of meses) {
    console.log(`\n=== Processando ${mes}/${ano} ===`);
    const osArray = await fetchAllOsForMonth(ano, mes);
    console.log(`  Total de OS carregadas: ${osArray.length}`);

    const result = buildAbcProdutos(osArray);
    console.log(`  Total de produtos únicos: ${result.items.length}`);
    console.log(`  Faturamento total: R$ ${result.faturamento.toFixed(2)}`);
    console.log(`  Top 5 produtos:`);
    result.items.slice(0, 5).forEach((it) => {
      console.log(`    - ${it.nome}: R$ ${it.total.toFixed(2)} (${it.pct}%)`);
    });

    // Verificar se ainda tem "Desconhecido"
    const desconhecido = result.items.find((it) => it.nome === "Desconhecido");
    if (desconhecido) {
      console.log(`  ⚠️  Ainda há item "Desconhecido": R$ ${desconhecido.total.toFixed(2)}`);
    } else {
      console.log(`  ✅ Nenhum item "Desconhecido" encontrado`);
    }

    // Salvar no cache
    const [existing] = await conn.execute(
      "SELECT id FROM abc_cache WHERE mes = ? AND ano = ? AND tipo = 'produtos'",
      [mes, ano]
    );

    if (existing.length > 0) {
      await conn.execute(
        "UPDATE abc_cache SET dados = ?, totalOs = ?, faturamentoTotal = ?, updatedAt = NOW() WHERE id = ?",
        [JSON.stringify(result.items), result.totalOs, result.faturamento.toFixed(2), existing[0].id]
      );
      console.log(`  ✅ Cache atualizado (id=${existing[0].id})`);
    } else {
      await conn.execute(
        "INSERT INTO abc_cache (mes, ano, tipo, dados, totalOs, faturamentoTotal) VALUES (?, ?, 'produtos', ?, ?, ?)",
        [mes, ano, JSON.stringify(result.items), result.totalOs, result.faturamento.toFixed(2)]
      );
      console.log(`  ✅ Cache criado`);
    }
  }

  await conn.end();
  console.log("\n✅ Concluído!");
}

main().catch((err) => {
  console.error("❌ Erro:", err.message);
  process.exit(1);
});
