/**
 * normalize-unesul.mjs
 * Aplica correções de acentuação nos nomes das cidades da Unesul (transportadoraId = 28)
 * cruzando com a base oficial do IBGE.
 */
import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Correções automáticas do IBGE (83 cidades)
const updatesIBGE = JSON.parse(readFileSync('/tmp/unesul_updates.json', 'utf-8'));

// Correções manuais para os 17 casos não encontrados automaticamente
const updatesManuais = [
  // MG
  { id: 90073, nome_atual: 'Uberada', nome_correto: 'Uberlândia', estado: 'MG' }, // erro de digitação no PDF
  // MS
  { id: 90155, nome_atual: 'Nova Alvorada', nome_correto: 'Nova Alvorada do Sul', estado: 'MS' }, // nome completo
  { id: 90159, nome_atual: 'Rio Brilahante', nome_correto: 'Rio Brilhante', estado: 'MS' }, // erro de digitação
  // PR
  { id: 90178, nome_atual: 'Corbeilia', nome_correto: 'Corbélia', estado: 'PR' }, // erro de digitação
  { id: 90197, nome_atual: 'Mal.can. Rondon', nome_correto: 'Marechal Cândido Rondon', estado: 'PR' }, // abreviação
  { id: 90209, nome_atual: 'Nova Sta. Rosa', nome_correto: 'Nova Santa Rosa', estado: 'PR' }, // abreviação
  { id: 90221, nome_atual: 'Santa Iza. do Oeste', nome_correto: 'Santa Izabel do Oeste', estado: 'PR' }, // abreviação
  { id: 90228, nome_atual: 'Sto.ant. Sudoeste', nome_correto: 'Santo Antônio do Sudoeste', estado: 'PR' }, // abreviação
  // RJ
  { id: 90077, nome_atual: 'Campos dos Goytacaze', nome_correto: 'Campos dos Goytacazes', estado: 'RJ' }, // falta 's' final
  { id: 90081, nome_atual: 'Nilópois', nome_correto: 'Nilópolis', estado: 'RJ' }, // erro de digitação
  { id: 90086, nome_atual: 'São João do Meriti', nome_correto: 'São João de Meriti', estado: 'RJ' }, // preposição errada
  // RS
  { id: 90389, nome_atual: 'Santana do Livramento', nome_correto: 'Sant\'Ana do Livramento', estado: 'RS' }, // nome correto IBGE
  { id: 90405, nome_atual: 'Sto. Ant. da Patrulha', nome_correto: 'Santo Antônio da Patrulha', estado: 'RS' }, // abreviação
  // SC
  { id: 90237, nome_atual: 'Bal. Camburiú', nome_correto: 'Balneário Camboriú', estado: 'SC' }, // abreviação
  { id: 90253, nome_atual: 'Forquilinha', nome_correto: 'Forquilhinha', estado: 'SC' }, // erro de digitação
  { id: 90256, nome_atual: 'Herval do Oeste', nome_correto: 'Herval d\'Oeste', estado: 'SC' }, // nome correto IBGE
  { id: 90278, nome_atual: 'São Miguel D\' Oeste', nome_correto: 'São Miguel do Oeste', estado: 'SC' }, // nome correto IBGE
];

const todosUpdates = [...updatesIBGE, ...updatesManuais];

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  console.log(`Aplicando ${updatesIBGE.length} correções automáticas (IBGE) + ${updatesManuais.length} correções manuais...`);
  
  let sucesso = 0;
  let erros = 0;
  
  for (const update of todosUpdates) {
    try {
      const [result] = await conn.execute(
        'UPDATE transportadora_cidades SET cidade = ? WHERE id = ? AND transportadoraId = 28',
        [update.nome_correto, update.id]
      );
      if (result.affectedRows > 0) {
        console.log(`  ✓ [${update.estado}] '${update.nome_atual}' → '${update.nome_correto}'`);
        sucesso++;
      } else {
        console.log(`  ⚠ [${update.estado}] id=${update.id} não encontrado`);
        erros++;
      }
    } catch (err) {
      console.error(`  ✗ [${update.estado}] id=${update.id}: ${err.message}`);
      erros++;
    }
  }
  
  console.log(`\n=== RESUMO ===`);
  console.log(`Correções aplicadas: ${sucesso}`);
  console.log(`Erros: ${erros}`);
  console.log(`Total processado: ${todosUpdates.length}`);
  
  // Atualizar data de atualização da Unesul
  await conn.execute(
    'UPDATE transportadoras SET ultAtualizCidades = NOW() WHERE id = 28'
  );
  console.log(`\nData de atualização da Unesul atualizada.`);
  
  await conn.end();
}

main().catch(console.error);
