import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Buscar ID da Valtur
const [rows] = await conn.execute("SELECT id, nome FROM transportadoras WHERE nome LIKE '%Valtur%' OR nome LIKE '%valtur%'");
console.log('Valtur encontrada:', rows);

let valturId = rows[0]?.id;
if (!valturId) {
  // Criar a Valtur se não existir
  const [result] = await conn.execute(
    "INSERT INTO transportadoras (nome, ativo, createdAt) VALUES ('Valtur', 1, NOW())"
  );
  valturId = result.insertId;
  console.log('✅ Valtur criada com ID:', valturId);
} else {
  console.log('✅ Valtur encontrada com ID:', valturId);
}

// Cidades extraídas do print 2 (imagem da Valtur)
const cidades = [
  // Rio Grande do Sul
  { cidade: 'Constantina', estado: 'RS' },
  { cidade: 'Frederico Westphalen', estado: 'RS' },
  { cidade: 'Nonoai', estado: 'RS' },
  { cidade: 'Passo Fundo', estado: 'RS' },
  // Santa Catarina
  { cidade: 'Chapecó', estado: 'SC' },
  { cidade: 'Maravilha', estado: 'SC' },
  { cidade: 'São Miguel do Oeste', estado: 'SC' },
  { cidade: 'Xanxerê', estado: 'SC' },
  // Paraná
  { cidade: 'Assis Chateaubriand', estado: 'PR' },
  { cidade: 'Barracão', estado: 'PR' },
  { cidade: 'Chopinzinho', estado: 'PR' },
  { cidade: 'Cascavel', estado: 'PR' },
  { cidade: 'Laranjeiras do Sul', estado: 'PR' },
  { cidade: 'Pato Branco', estado: 'PR' },
  { cidade: 'Realeza', estado: 'PR' },
  { cidade: 'Santo Antônio do Sudoeste', estado: 'PR' },
  { cidade: 'Toledo', estado: 'PR' },
  { cidade: 'Umuarama', estado: 'PR' },
  // Mato Grosso do Sul
  { cidade: 'Campo Grande', estado: 'MS' },
  { cidade: 'Coxim', estado: 'MS' },
  { cidade: 'Dourados', estado: 'MS' },
  { cidade: 'Eldorado', estado: 'MS' },
  { cidade: 'Itaquiraí', estado: 'MS' },
  { cidade: 'Naviraí', estado: 'MS' },
  { cidade: 'Nova Alvorada do Sul', estado: 'MS' },
  { cidade: 'Rio Brilhante', estado: 'MS' },
  { cidade: 'Rio Verde de Mato Grosso', estado: 'MS' },
  { cidade: 'São Gabriel do Oeste', estado: 'MS' },
  { cidade: 'Sonora', estado: 'MS' },
  // Mato Grosso
  { cidade: 'Brasnorte', estado: 'MT' },
  { cidade: 'Campos Novos do Parecis', estado: 'MT' },
  { cidade: 'Campo Verde', estado: 'MT' },
  { cidade: 'Cuiabá', estado: 'MT' },
  { cidade: 'Jaciara', estado: 'MT' },
  { cidade: 'Juína', estado: 'MT' },
  { cidade: 'Lucas do Rio Verde', estado: 'MT' },
  { cidade: 'Nova Mutum', estado: 'MT' },
  { cidade: 'Porto dos Gaúchos', estado: 'MT' },
  { cidade: 'Primavera do Leste', estado: 'MT' },
  { cidade: 'Rondonópolis', estado: 'MT' },
  { cidade: 'Sinop', estado: 'MT' },
  { cidade: 'Sorriso', estado: 'MT' },
  { cidade: 'Tangará da Serra', estado: 'MT' },
];

// Verificar quais já existem para evitar duplicatas
const [existing] = await conn.execute(
  'SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?',
  [valturId]
);
const existingSet = new Set(existing.map(r => `${r.cidade.toLowerCase()}|${r.estado}`));

let inserted = 0;
let skipped = 0;
for (const { cidade, estado } of cidades) {
  const key = `${cidade.toLowerCase()}|${estado}`;
  if (existingSet.has(key)) {
    skipped++;
    continue;
  }
  await conn.execute(
    'INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, createdAt) VALUES (?, ?, ?, NOW())',
    [valturId, cidade, estado]
  );
  inserted++;
}

console.log(`✅ Valtur: ${inserted} cidades inseridas, ${skipped} já existiam`);
await conn.end();
