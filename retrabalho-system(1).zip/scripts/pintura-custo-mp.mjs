import https from 'https';

const publicKey = process.env.MUBISYS_PUBLIC_KEY;
const accessToken = process.env.MUBISYS_ACCESS_TOKEN;

function fetchPage(start, end, page) {
  return new Promise((resolve) => {
    const path = `/ordem-servico?status=TODOS&filtrodata=CADASTRO&datainicial=${start}&datafinal=${end}&page=${page}&per_page=500`;
    const url = `https://api.mubisys.com/api/${publicKey}${path}`;
    const req = https.get(url, { headers: { 'Access-Token': accessToken, 'Accept': 'application/json' } }, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => { try { resolve(JSON.parse(body)); } catch { resolve({}); } });
    });
    req.on('error', () => resolve({}));
    req.setTimeout(30000, () => { req.destroy(); resolve({}); });
  });
}

async function fetchAllOsForPeriod(start, end) {
  let all = [];
  let page = 1;
  while (true) {
    const d = await fetchPage(start, end, page);
    const items = (d.data || []);
    if (items.length === 0) break;
    all = all.concat(items);
    const pagination = d.pagination;
    if (!pagination || page >= (pagination.last_page || 1)) break;
    page++;
  }
  return all;
}

function classificarPintura(modelo) {
  const m = (modelo || '').toLowerCase();
  if (m.includes('metalizada') || m.includes('poliéster') || m.includes('poliester')) return 'Metalizada';
  if (m.includes('4 cor')) return 'PU 4 cores';
  if (m.includes('3 cor')) return 'PU 3 cores';
  if (m.includes('2 cor')) return 'PU 2 cores';
  if (m.includes('1 cor') || m.includes('uma cor')) return 'PU 1 cor';
  if (m.includes('p.u') || m.includes('pu')) return 'PU 1 cor';
  return 'Outro';
}

async function main() {
  const periods = [
    ['2026-01-01', '2026-01-31'],
    ['2026-02-01', '2026-02-28'],
    ['2026-03-01', '2026-03-31'],
    ['2026-04-01', '2026-04-30'],
    ['2026-05-01', '2026-05-31'],
    ['2026-06-01', '2026-06-04'],
  ];

  // Estratégia: buscar OS que tenham SOMENTE pintura como item,
  // ou onde a pintura é o item principal, para isolar o custo de matéria-prima
  const results = [];

  for (const [start, end] of periods) {
    console.error(`Fetching ${start} to ${end}...`);
    const osList = await fetchAllOsForPeriod(start, end);
    console.error(`  Got ${osList.length} OS`);

    for (const os of osList) {
      const itens = os.itens || [];
      const pinturaItens = itens.filter(it => (it.item || '').toLowerCase().includes('pintura'));
      
      if (pinturaItens.length === 0) continue;

      const totalItens = itens.length;
      const valorMpOs = parseFloat(os.valor_materia_prima) || 0;
      const valorTotalOs = parseFloat(os.valor_total) || 0;
      
      for (const it of pinturaItens) {
        const largura = parseFloat(it.largura) || 0;
        const altura = parseFloat(it.altura) || 0;
        const m2 = largura * altura;
        const quantidade = it.quantidade || 1;
        const subTotal = parseFloat(it.sub_total) || 0;
        const categoria = classificarPintura(it.modelo);
        
        // Proporção do valor deste item no total da OS
        const proporcao = valorTotalOs > 0 ? subTotal / valorTotalOs : 0;
        // Custo de MP proporcional a este item
        const custoMpItem = valorMpOs * proporcao;
        // Custo de MP por m²
        const m2Total = m2 * quantidade;
        const custoMpPorM2 = m2Total > 0 ? custoMpItem / m2Total : 0;

        results.push({
          os: os.sequencial_ordem,
          mes: (os.data_cadastro || '').substring(0, 7),
          categoria,
          modelo: it.modelo,
          m2: m2Total,
          subTotal,
          valorMpOs,
          valorTotalOs,
          totalItensOs: totalItens,
          proporcao,
          custoMpItem,
          custoMpPorM2,
          // Flag: OS com apenas pintura (custo MP mais preciso)
          osSoPintura: pinturaItens.length === totalItens,
        });
      }
    }
  }

  // Análise por categoria
  console.log('\n=== CUSTO MATÉRIA-PRIMA POR M² — TODAS AS OS ===');
  console.log('(Custo MP proporcional ao valor do item na OS)\n');

  const categorias = {};
  for (const r of results) {
    if (r.categoria === 'Outro') continue;
    if (categorias[r.categoria] === undefined) categorias[r.categoria] = { items: [], totalMp: 0, totalM2: 0 };
    categorias[r.categoria].items.push(r);
    categorias[r.categoria].totalMp += r.custoMpItem;
    categorias[r.categoria].totalM2 += r.m2;
  }

  for (const [cat, data] of Object.entries(categorias).sort()) {
    const custoM2 = data.totalM2 > 0 ? data.totalMp / data.totalM2 : 0;
    console.log(`${cat}:`);
    console.log(`  Qtd registros: ${data.items.length}`);
    console.log(`  Total MP proporcional: R$ ${data.totalMp.toFixed(2)}`);
    console.log(`  Total m²: ${data.totalM2.toFixed(3)}`);
    console.log(`  Custo MP médio/m²: R$ ${custoM2.toFixed(2)}`);
    console.log('');
  }

  // Análise mais precisa: apenas OS que têm SOMENTE pintura
  console.log('\n=== CUSTO MP/M² — APENAS OS COM SOMENTE PINTURA (mais preciso) ===\n');

  const catSoPintura = {};
  for (const r of results) {
    if (r.categoria === 'Outro') continue;
    if (r.osSoPintura === false) continue;
    if (catSoPintura[r.categoria] === undefined) catSoPintura[r.categoria] = { items: [], totalMp: 0, totalM2: 0 };
    catSoPintura[r.categoria].items.push(r);
    catSoPintura[r.categoria].totalMp += r.custoMpItem;
    catSoPintura[r.categoria].totalM2 += r.m2;
  }

  if (Object.keys(catSoPintura).length === 0) {
    console.log('  Nenhuma OS encontrada com apenas itens de pintura.');
  } else {
    for (const [cat, data] of Object.entries(catSoPintura).sort()) {
      const custoM2 = data.totalM2 > 0 ? data.totalMp / data.totalM2 : 0;
      console.log(`${cat}:`);
      console.log(`  Qtd registros: ${data.items.length}`);
      console.log(`  Total MP: R$ ${data.totalMp.toFixed(2)}`);
      console.log(`  Total m²: ${data.totalM2.toFixed(3)}`);
      console.log(`  Custo MP/m²: R$ ${custoM2.toFixed(2)}`);
      console.log('');
    }
  }

  // Evolução mensal
  console.log('\n=== EVOLUÇÃO MENSAL — CUSTO MP/M² (todas as OS) ===\n');
  for (const [cat, data] of Object.entries(categorias).sort()) {
    console.log(`--- ${cat} ---`);
    const porMes = {};
    for (const r of data.items) {
      if (porMes[r.mes] === undefined) porMes[r.mes] = { mp: 0, m2: 0, count: 0 };
      porMes[r.mes].mp += r.custoMpItem;
      porMes[r.mes].m2 += r.m2;
      porMes[r.mes].count++;
    }
    for (const [mes, md] of Object.entries(porMes).sort()) {
      const cm2 = md.m2 > 0 ? md.mp / md.m2 : 0;
      console.log(`  ${mes}: ${md.count} itens | MP: R$ ${md.mp.toFixed(2)} | ${md.m2.toFixed(3)} m² | R$ ${cm2.toFixed(2)}/m²`);
    }
    console.log('');
  }

  // Exemplos detalhados para validação
  console.log('\n=== EXEMPLOS DETALHADOS (5 primeiros de cada categoria) ===\n');
  for (const [cat, data] of Object.entries(categorias).sort()) {
    console.log(`--- ${cat} ---`);
    data.items.slice(0, 5).forEach(r => {
      console.log(`  OS ${r.os} | ${r.modelo} | ${r.m2.toFixed(3)} m² | Venda: R$ ${r.subTotal.toFixed(2)} | MP OS: R$ ${r.valorMpOs.toFixed(2)} | Proporção: ${(r.proporcao*100).toFixed(1)}% | MP item: R$ ${r.custoMpItem.toFixed(2)} | MP/m²: R$ ${r.custoMpPorM2.toFixed(2)}`);
    });
    console.log('');
  }
}

main().catch(console.error);
