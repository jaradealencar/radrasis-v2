import mysql from "mysql2/promise";

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Dados de março 2026 extraídos do documento "Pré-estudo produção Março 2026"
const marco2026 = {
  mes: 3,
  ano: 2026,

  // 1. Visão Geral de Produtividade
  osGeradas: 204,
  osExpedicao: 181,
  percExpedicao: 88.73, // 181/204

  // 2.1 Finalização e Fluxo de OS
  metaOsDia: 9.27,
  capacidadeOsDiaMin: 3.00,
  capacidadeOsDiaMax: 5.00,
  deficitFinalizacao: 50.00, // ~50% de déficit

  // 2.2 Embalagem e Expedição
  metaEmbalagemDia: 8.23,
  producaoEmbalagemDia: 7.00, // ~7 caixas/dia

  // 2.3 Acabamento (Pintura, Instalação, Colagem)
  metaAcabamentoDia: 1.41,
  capacidadeAcabamentoDia: 0.72,

  // 3. Setor de Solda
  capacidadeNominalSolda: 2000,
  producaoInternaSolda: 2531,   // recorde com H.E. (+26,5%)
  demandaTotalSolda: 3347,
  osTerceirizadas: 22,
  metrosTerceirizados: 816,

  // Metas (não definidas ainda — deixar nulas para configuração futura)
  metaOsGeradas: null,
  metaOsExpedicao: null,
  metaProducaoSolda: null,
  metaPercTerceirizacao: null,

  observacoes: "Mês de março apresentou volume de demanda superior à capacidade instalada. Esforço excepcional da equipe com recorde de horas extras. Gargalos operacionais tornaram-se críticos.",
  destaques: "Setor de Solda superou capacidade nominal em 26,5% com horas extras. Terceirização estratégica de 22 OS (816m) para suprir excedente.",
  gargalos: "Finalização com déficit de ~50% de produtividade. Acabamento com capacidade apenas 51% da meta. Embalagem limitada por complexidade e tamanho das peças.",
};

const [existing] = await conn.execute(
  "SELECT id FROM performance_mensal WHERE mes = ? AND ano = ?",
  [marco2026.mes, marco2026.ano]
);

if (existing.length > 0) {
  console.log("Dados de março 2026 já existem no banco. Atualizando...");
  await conn.execute(
    `UPDATE performance_mensal SET
      osGeradas=?, osExpedicao=?, percExpedicao=?,
      metaOsDia=?, capacidadeOsDiaMin=?, capacidadeOsDiaMax=?, deficitFinalizacao=?,
      metaEmbalagemDia=?, producaoEmbalagemDia=?,
      metaAcabamentoDia=?, capacidadeAcabamentoDia=?,
      capacidadeNominalSolda=?, producaoInternaSolda=?, demandaTotalSolda=?,
      osTerceirizadas=?, metrosTerceirizados=?,
      observacoes=?, destaques=?, gargalos=?
    WHERE mes=? AND ano=?`,
    [
      marco2026.osGeradas, marco2026.osExpedicao, marco2026.percExpedicao,
      marco2026.metaOsDia, marco2026.capacidadeOsDiaMin, marco2026.capacidadeOsDiaMax, marco2026.deficitFinalizacao,
      marco2026.metaEmbalagemDia, marco2026.producaoEmbalagemDia,
      marco2026.metaAcabamentoDia, marco2026.capacidadeAcabamentoDia,
      marco2026.capacidadeNominalSolda, marco2026.producaoInternaSolda, marco2026.demandaTotalSolda,
      marco2026.osTerceirizadas, marco2026.metrosTerceirizados,
      marco2026.observacoes, marco2026.destaques, marco2026.gargalos,
      marco2026.mes, marco2026.ano,
    ]
  );
} else {
  await conn.execute(
    `INSERT INTO performance_mensal
      (mes, ano, osGeradas, osExpedicao, percExpedicao,
       metaOsDia, capacidadeOsDiaMin, capacidadeOsDiaMax, deficitFinalizacao,
       metaEmbalagemDia, producaoEmbalagemDia,
       metaAcabamentoDia, capacidadeAcabamentoDia,
       capacidadeNominalSolda, producaoInternaSolda, demandaTotalSolda,
       osTerceirizadas, metrosTerceirizados,
       observacoes, destaques, gargalos)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      marco2026.mes, marco2026.ano,
      marco2026.osGeradas, marco2026.osExpedicao, marco2026.percExpedicao,
      marco2026.metaOsDia, marco2026.capacidadeOsDiaMin, marco2026.capacidadeOsDiaMax, marco2026.deficitFinalizacao,
      marco2026.metaEmbalagemDia, marco2026.producaoEmbalagemDia,
      marco2026.metaAcabamentoDia, marco2026.capacidadeAcabamentoDia,
      marco2026.capacidadeNominalSolda, marco2026.producaoInternaSolda, marco2026.demandaTotalSolda,
      marco2026.osTerceirizadas, marco2026.metrosTerceirizados,
      marco2026.observacoes, marco2026.destaques, marco2026.gargalos,
    ]
  );
  console.log("Dados de março 2026 inseridos com sucesso!");
}

await conn.end();
console.log("Seed concluído.");
