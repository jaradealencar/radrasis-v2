import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ID da Vitlog no banco
const VITLOG_ID = 31;

// Verificar se a Vitlog existe
const [rows] = await conn.execute('SELECT id, nome FROM transportadoras WHERE id = ?', [VITLOG_ID]);
if (rows.length === 0) {
  console.error('❌ Vitlog não encontrada no banco (id=31)');
  process.exit(1);
}
console.log(`✅ Transportadora: ${rows[0].nome} (id=${rows[0].id})`);

// Carregar dados extraídos
const data = JSON.parse(readFileSync('/tmp/vitlog2_data.json', 'utf-8'));
console.log(`Unidades a processar: ${data.length}`);

// ─── 1. INSERIR COMO CIDADES ──────────────────────────────────────────────────
const [existingCidades] = await conn.execute(
  'SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?',
  [VITLOG_ID]
);
const cidadesSet = new Set(existingCidades.map(r => `${r.cidade.toUpperCase()}|${r.estado.toUpperCase()}`));
console.log(`\nCidades já cadastradas: ${cidadesSet.size}`);

let cidadesInseridas = 0;
let cidadesSkipped = 0;

for (const u of data) {
  const key = `${u.cidade.toUpperCase()}|${u.estado.toUpperCase()}`;
  if (cidadesSet.has(key)) {
    cidadesSkipped++;
    continue;
  }
  await conn.execute(
    `INSERT INTO transportadora_cidades 
     (transportadoraId, cidade, estado, telefone, endereco, createdAt)
     VALUES (?, ?, ?, ?, ?, NOW())`,
    [
      VITLOG_ID,
      u.cidade,
      u.estado,
      u.telefone || null,
      u.endereco || null,
    ]
  );
  cidadesInseridas++;
}

console.log(`✅ Cidades: ${cidadesInseridas} inseridas, ${cidadesSkipped} já existiam`);

// ─── 2. INSERIR COMO FILIAIS ──────────────────────────────────────────────────
// Verificar se a tabela transportadora_filiais existe e sua estrutura
const [filialCols] = await conn.execute('DESCRIBE transportadora_filiais');
console.log('\nColunas de transportadora_filiais:', filialCols.map(c => c.Field).join(', '));

const [existingFiliais] = await conn.execute(
  'SELECT nome FROM transportadora_filiais WHERE transportadoraId = ?',
  [VITLOG_ID]
);
const filiaisSet = new Set(existingFiliais.map(r => r.nome.toUpperCase()));
console.log(`Filiais já cadastradas: ${filiaisSet.size}`);

let filiaisInseridas = 0;
let filiaisSkipped = 0;

for (const u of data) {
  // Nome da filial = nome da unidade (ex: "Porto Alegre - RS (Matriz)")
  const nomeFilial = u.nome_unidade;
  
  if (filiaisSet.has(nomeFilial.toUpperCase())) {
    filiaisSkipped++;
    continue;
  }
  
  // Verificar colunas disponíveis
  const cols = filialCols.map(c => c.Field);
  const hasCidade = cols.includes('cidade');
  const hasEstado = cols.includes('estado');
  const hasTelefone = cols.includes('telefone');
  const hasEndereco = cols.includes('endereco');
  
  let sql = 'INSERT INTO transportadora_filiais (transportadoraId, nome';
  let vals = [VITLOG_ID, nomeFilial];
  
  if (hasEndereco) { sql += ', endereco'; vals.push(u.endereco || null); }
  if (hasCidade) { sql += ', cidade'; vals.push(u.cidade || null); }
  if (hasEstado) { sql += ', estado'; vals.push(u.estado || null); }
  if (hasTelefone) { sql += ', telefone'; vals.push(u.telefone || null); }
  
  sql += ') VALUES (' + vals.map(() => '?').join(', ') + ')';
  
  await conn.execute(sql, vals);
  filiaisInseridas++;
}

console.log(`✅ Filiais: ${filiaisInseridas} inseridas, ${filiaisSkipped} já existiam`);

// ─── Resumo final ─────────────────────────────────────────────────────────────
const [totalCidades] = await conn.execute(
  'SELECT COUNT(*) as total FROM transportadora_cidades WHERE transportadoraId = ?',
  [VITLOG_ID]
);
const [totalFiliais] = await conn.execute(
  'SELECT COUNT(*) as total FROM transportadora_filiais WHERE transportadoraId = ?',
  [VITLOG_ID]
);

console.log(`\n📊 Vitlog agora tem:`);
console.log(`   ${totalCidades[0].total} cidades cadastradas`);
console.log(`   ${totalFiliais[0].total} filiais cadastradas`);

await conn.end();
