import mysql from "mysql2/promise";

const CIDADES = {
  MG: ["BELO HORIZONTE","CARANGOLA","ITAJUBA","MANHUAÇU","MURIAÉ","POUSO ALEGRE","GOVERNADOR VALADARES","CARATINGA","UBERABA"],
  DF: ["BRASÍLIA"],
  ES: ["CACHOEIRO DE ITAPEMIRIM","VITÓRIA"],
  RJ: ["CAMPOS DOS GOYTACAZES","DUQUE DE CAXIAS","MESQUITA","NOVA IGUAÇU","NILÓPOLIS","NITERÓI","NOVA FRIBURGO","PETRÓPOLIS","RIO DE JANEIRO","SÃO JOÃO DO MERITI","SÃO JOÃO DA BARRA","TERESÓPOLIS","VOLTA REDONDA"],
  SP: ["BARUERI","CAMPINAS","CAMPO LIMPO PAULISTA","DIADEMA","GUARULHOS","JUNDIAÍ","MARÍLIA","OSASCO","RIO CLARO","PAULÍNIA","DIAMANTE DO NORTE","PRESIDENTE PRUDENTE","SANTO ANDRÉ","SÃO BERNARDO DO CAMPO","SÃO PAULO","SUMARÉ","SOROCABA","SUZANO","VALINHOS","VINHEDO"],
  MT: ["ACORIZAL","ALTO PARAGUAI","ARENAÓPOLIS","BARRA DO BUGRES","BARRA DO GARÇAS","CÁCERES","CAMPO NOVO DO PARECIS","CAMPOS DE JÚLIO","CHAPADA DOS GUIMARÃES","COMODORO","CONQUISTA D'OESTE","CUIABÁ","DENISE","DIAMANTINO","FIGUEIRÓPOLIS D'OESTE","JACIARA","JANGADA","JAURU","MIRASSOL D'OESTE","NOBRES","NORTELÂNDIA","NOSSA SENHORA DO LIVRAMENTO","NOVA OLÍMPIA","PARANATINGA","POCONÉ","PORTO ESPERIDIÃO","PRIMAVERA DO LESTE","QUERÊNCIA","RIBEIRÃO CASCALHEIRA","RONDONÓPOLIS","ROSÁRIO OESTE","SÃO JOSÉ DOS QUATRO MARCOS","TANGARÁ DA SERRA","VÁRZEA GRANDE"],
  MS: ["ÁGUA CLARA","ANASTÁCIO","ANGÉLICA","APARECIDA DO TABOADO","AQUIDAUANA","BATAYPORÃ","BELA VISTA","BODOQUENA","BONITO","BANDEIRANTES","CAARAPÓ","CAMAPUÃ","CAMPO GRANDE","CASSILÂNDIA","CHAPADÃO DO SUL","CORUMBÁ","COSTA RICA","COXIM","DEODÁPOLIS","DOURADOS","ELDORADO","FIGUEIRÃO","GLÓRIA DE DOURADOS","GUIA LOPES DA LAGUNA","ITAQUIRAÍ","IVINHEMA","JARDIM","LADÁRIO","MARACAJU","MIRANDA","NIOAQUE","NAVIRAÍ","NOVA ALVORADA","PARAÍSO DAS ÁGUAS","PARANÁIBA","PEDRO GOMES","PONTA PORÃ","RIBAS DO RIO PARDO","RIO BRILHANTE","RIO VERDE DE MATO GROSSO","SÃO GABRIEL DO OESTE","SIDROLÂNDIA","SONORA","TRÊS LAGOAS"],
  PR: ["AMPERE","ALMIRANTE TAMANDARÉ","APUCARANA","BARRACÃO","BITURUNA","BOM JESUS DO SUL","CAMPO MOURÃO","CANDÓI","CAPITÃO LEÔNIDAS MARQUES","CASCAVEL","CASTRO","CEU AZUL","CLEVELÂNDIA","COLOMBO","CONGONHINHAS","CORBÉLIA","CORONEL VIVIDA","CURITIBA","DOIS VIZINHOS","ENTRE RIOS D'OESTE","FOZ DO IGUAÇU","FRANCISCO BELTRÃO","GOIOERÊ","GUAÍRA","GUARANIAÇU","GUARAPUAVA","IBIPORÃ","IMBITUVA","ITAPEJARA D'OESTE","LARANJEIRAS DO SUL","LOBATO","LONDRINA","MAL. CAN. RONDON","MARIPA","MARIOPOLIS","MARINGÁ","MARMELEIRO","MATELÂNDIA","MEDIANEIRA","MERCEDES","MISSAL","NOVA AURORA","NOVA ESPERANÇA DO SUDOESTE","NOVA STA. ROSA","PALOTINA","PATO BRAGADO","PATO BRANCO","PÉROLA D'OESTE","PINHAIS","PLANALTO","PIRUCATU","PRANCHITA","QUATRO PONTES","RAMILÂNDIA","REALEZA","RENASCENÇA","SANTA IZA. DO OESTE","SANTA HELENA","SANTA TEREZINHA DE ITAIPU","SÃO JOÃO","SÃO PAULO DOS PINHAIS","SÃO MIGUEL DO IGUAÇU","SERRANÓPOLIS DO IGUAÇU","STO.ANT. SUDOESTE","SANTA TEREZA DO OESTE","TOLEDO","UMUARAMA","UNIÃO DA VITÓRIA","VITORINO"],
  SC: ["ABELARDO LUZ","ÁGUA DOCE","ARARANGUÁ","BAL. CAMBORIÚ","BAL. PIÇARRAS","BIGUAÇU","BLUMENAU","BOTUVERA","BRUSQUE","CRICIÚMA","CAÇADOR","CATANDUVAS","CHAPECÓ","CONCÓRDIA","DIONÍSIO CERQUEIRA","IÇARA","INDAIAL","FORQUILHINHA","FLORIANÓPOLIS","GASPAR","HERVAL DO OESTE","ILHOTA","IRANI","ITAPEMA","ITAJAÍ","ITAPIRANAGA","JABORÁ","JOAÇABA","LUZERNA","MARAVILHA","MORRO DA FUMAÇA","NAVEGANTES","PALHOÇA","PENHA","POMERODE","PORTO BELO","RIO DOS CEDROS","RIO DO SUL","SÃO JOSÉ","SÃO JOSÉ DO CEDRO","SÃO MIGUEL D'OESTE","SIDERÓPOLIS","TIMBÓ","TREZE TÍLIAS","VIDEIRA","XANXERÊ","XAXIM"],
  RS: ["AGUDO","ALVORADA","ALEGRETE","AMETISTA DO SUL","ARARICA","ARROIO DO MEIO","ARROIO DO SAL","ARROIO DO TIGRE","ARROIO GRANDE","BAGÉ","BARÃO DE COTEGIPE","BENTO GONÇALVES","BOM PRINCÍPIO","CACAPAVA DO SUL","CACHOEIRA DO SUL","CACHOEIRINHA","CAMAQUÃ","CANGUÇU","CAMPO BOM","CANDELÁRIA","CANOAS","CAPÃO DA CANOA","CARAZINHO","CARLOS BARBOSA","CAXIAS DO SUL","CERRO BRANCO","CHIÚ","CRISTAL","CRUZ ALTA","CRUZEIRO DO SUL","DOIS IRMÃOS","DONA FRANCISCA","ELDORADO DO SUL","ENCANTADO","ERECHIM","ESTAÇÃO","ESTÂNCIA VELHA","ESTRELA","ESTRELA VELHA","FARROUPILHA","FAXINAL DO SOTURNO","FELIZ","FLORES DA CUNHA","FREDERICO WESTPHALEN","SÃO MARCOS","GARIBALDI","GETÚLIO VARGAS","GIRUA","GRAVATAÍ","GUAÍBA","HORIZONTINA","HULHA NEGRA","IBIRUBÁ","IGREJINHA","IJÍ","IMBE","INDEPENDÊNCIA","ITAQUI","IVOTI","JAGUARÃO","JÚLIO DE CASTILHOS","LAJEADO","MARAU","MAQUINÉ","MONTENEGRO","NÃO ME TOQUE","NOVA HARTZ","NOVA ALVORADA","NOVA PETRÓPOLIS","NOVA SANTA RITA","NOVO HAMBURGO","OSÓRIO","PANAMBI","PARAÍSO DO SUL","PASSA SETE","PASSO FUNDO","PEDRO OSÓRIO","PELOTAS","PINHEIRO MACHADO","PIRATINI","PONTE PRETA","PORTÃO","PORTO ALEGRE","QUARAÍ","QUINZE DE NOVEMBRO","RESTINGA SECA","RIO GRANDE","ROSÁRIO DO SUL","SAPIRANGA","SALTO DO JACUÍ","SANANDUVA","SANTA CLARA DO SUL","SANTA MARIA","SANTA ROSA","SANTA VITÓRIA DO PALMAR","SANTANA DO LIVRAMENTO","SANTIAGO","SANTO ÂNGELO","SÃO BORJA","SÃO FRANCISCO DE PAULA","SÃO JOSÉ DO NORTE","SÃO LEOPOLDO","SÃO LOURENÇO DO SUL","SÃO PEDRO DO SUL","SÃO SEBASTIÃO DO CAÍ","SAPUCAIA DO SUL","SEBERI","SEGREDO","SOBRADINHO","SOLEDADE","STO. ANT. DA PATRULHA","TAQUARA","TERRA DE AREIA","TEUTÔNIA","TORRES","TRAMANDAÍ","TRÊS CACHOEIRAS","TRÊS COROAS","TURUÇU","URUGUAIANA","VACARIA","VALE REAL","VIAMÃO","XANGRI-LÁ"],
};

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  try {
    // Encontrar a Unesul
    const [transportadoras] = await conn.execute("SELECT id, nome FROM transportadoras WHERE nome LIKE '%UNESUL%' OR nome LIKE '%Unesul%' OR nome LIKE '%unesul%'");
    let transportadoraId;
    if (transportadoras.length === 0) {
      // Criar a Unesul se não existir
      const [result] = await conn.execute(
        "INSERT INTO transportadoras (nome, ativa, coberturaTotal) VALUES (?, 1, 0)",
        ["UNESUL"]
      );
      transportadoraId = result.insertId;
      console.log(`✅ Unesul criada com ID ${transportadoraId}`);
    } else {
      transportadoraId = transportadoras[0].id;
      console.log(`✅ Unesul encontrada: ID ${transportadoraId} — ${transportadoras[0].nome}`);
    }

    // Verificar cidades existentes para evitar duplicatas
    const [existentes] = await conn.execute(
      "SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?",
      [transportadoraId]
    );
    const existentesSet = new Set(existentes.map(r => `${r.cidade.toUpperCase()}|${r.estado}`));

    let inseridas = 0;
    let duplicatas = 0;
    const now = new Date();

    for (const [uf, cidades] of Object.entries(CIDADES)) {
      // Remover duplicatas dentro do mesmo array
      const cidadesUnicas = [...new Set(cidades)];
      for (const cidade of cidadesUnicas) {
        const key = `${cidade.toUpperCase()}|${uf}`;
        if (existentesSet.has(key)) {
          duplicatas++;
          continue;
        }
        await conn.execute(
          "INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, createdAt) VALUES (?, ?, ?, ?)",
          [transportadoraId, cidade, uf, now]
        );
        inseridas++;
      }
    }

    // Atualizar data de atualização da transportadora
    await conn.execute(
      "UPDATE transportadoras SET updatedAt = ? WHERE id = ?",
      [now, transportadoraId]
    );

    console.log(`✅ ${inseridas} cidades inseridas, ${duplicatas} duplicatas ignoradas`);
    console.log(`📊 Total por estado:`);
    for (const [uf, cidades] of Object.entries(CIDADES)) {
      console.log(`   ${uf}: ${[...new Set(cidades)].length} cidades`);
    }
  } finally {
    await conn.end();
  }
}

main().catch(console.error);
