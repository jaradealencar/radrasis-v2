import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
dotenv.config({ path: resolve(process.cwd(), ".env") });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Buscar todas as seções das páginas editáveis (1, 2 e 3)
const [rows] = await conn.execute(
  "SELECT id, page, sectionTitle, contentJson FROM price_table_sections WHERE page IN (1, 2, 3) ORDER BY page, sectionOrder"
);

console.log(`Processando ${rows.length} seções das páginas 1, 2 e 3...\n`);

// Função para aumentar um percentual em 5% (multiplicar por 1.05, arredondar para 1 casa decimal)
function aumentar5pct(valorStr) {
  // Aceita formatos: "22%", "18,5%", "9%", "40%"
  const match = valorStr.trim().match(/^([\d,\.]+)%$/);
  if (!match) return valorStr; // não é percentual, retorna sem alterar
  const numero = parseFloat(match[1].replace(",", "."));
  const novo = numero * 1.05;
  // Arredondar para 1 casa decimal
  const novoArredondado = Math.round(novo * 10) / 10;
  // Formatar: se inteiro, sem decimal; se decimal, usar vírgula
  const novoStr = novoArredondado % 1 === 0
    ? `${novoArredondado}%`
    : `${novoArredondado.toFixed(1).replace(".", ",")}%`;
  return novoStr;
}

// Função para processar um contentJson e aumentar todos os percentuais
function processarJson(contentJson, sectionTitle) {
  const json = JSON.parse(contentJson);
  const alteracoes = [];

  if (json.type === "margin_table") {
    // Iterar sobre as linhas e valores
    for (const row of json.rows || []) {
      for (let i = 0; i < (row.values || []).length; i++) {
        const original = row.values[i];
        const novo = aumentar5pct(original);
        if (novo !== original) {
          alteracoes.push(`  ${original} → ${novo}`);
          row.values[i] = novo;
        }
      }
    }
  } else if (json.type === "margin_table_multi") {
    // Tabelas com múltiplas sub-tabelas
    for (const subTable of json.tables || []) {
      for (const row of subTable.rows || []) {
        for (let i = 0; i < (row.values || []).length; i++) {
          const original = row.values[i];
          const novo = aumentar5pct(original);
          if (novo !== original) {
            alteracoes.push(`  ${original} → ${novo}`);
            row.values[i] = novo;
          }
        }
      }
    }
  } else if (json.type === "list") {
    // Listas: verificar se há percentuais nos itens
    for (const item of json.items || []) {
      if (item.value) {
        const novo = aumentar5pct(item.value);
        if (novo !== item.value) {
          alteracoes.push(`  ${item.value} → ${novo}`);
          item.value = novo;
        }
      }
      if (item.text) {
        // Substituir percentuais inline no texto
        const novoTexto = item.text.replace(/([\d,\.]+)%/g, (match, num) => {
          const numero = parseFloat(num.replace(",", "."));
          const novo = Math.round(numero * 1.05 * 10) / 10;
          const novoStr = novo % 1 === 0 ? `${novo}%` : `${novo.toFixed(1).replace(".", ",")}%`;
          if (novoStr !== match) alteracoes.push(`  ${match} → ${novoStr} (em texto)`);
          return novoStr;
        });
        item.text = novoTexto;
      }
    }
  }
  // config: não alterar (valores mínimos e descontos máximos são políticas, não preços)

  return { json: JSON.stringify(json), alteracoes };
}

let totalAlteracoes = 0;

for (const row of rows) {
  const { json: novoJson, alteracoes } = processarJson(row.contentJson, row.sectionTitle);

  if (alteracoes.length > 0) {
    await conn.execute(
      "UPDATE price_table_sections SET contentJson = ? WHERE id = ?",
      [novoJson, row.id]
    );
    console.log(`✅ ID ${row.id} | Pág ${row.page} | ${row.sectionTitle}`);
    for (const alt of alteracoes) console.log(alt);
    console.log();
    totalAlteracoes += alteracoes.length;
  } else {
    console.log(`⏭️  ID ${row.id} | Pág ${row.page} | ${row.sectionTitle} — sem percentuais para alterar`);
  }
}

console.log(`\n✅ Concluído! ${totalAlteracoes} percentuais atualizados em ${rows.length} seções.`);
await conn.end();
