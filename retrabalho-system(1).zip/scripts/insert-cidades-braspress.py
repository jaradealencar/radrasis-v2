import openpyxl
import mysql.connector
import os
import re
from datetime import date

# Carregar variáveis de ambiente do .env
env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
db_url = None
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line.startswith('DATABASE_URL='):
                db_url = line.split('=', 1)[1].strip().strip('"').strip("'")
                break

if not db_url:
    db_url = os.environ.get('DATABASE_URL', '')

# Parsear a URL do banco
match = re.match(r'mysql(?:\+[^:]+)?://([^:]+):([^@]+)@([^:/]+)(?::(\d+))?/([^?]+)', db_url)
user, password, host, port, database = match.groups()
port = int(port) if port else 3306

# Ler a planilha
wb = openpyxl.load_workbook('/home/ubuntu/upload/MUNICIPIOSPARCEIROS(2).xlsx', read_only=True, data_only=True)
ws = wb.active

# Mapear colunas para parceiros (linha 2 é o cabeçalho)
parceiros = []
cidades_por_parceiro = {}

for i, row in enumerate(ws.iter_rows(values_only=True)):
    vals = [str(v).strip() if v is not None else '' for v in row]
    
    if i == 0:
        # Linha 1: título geral (ignorar)
        continue
    elif i == 1:
        # Linha 2: nomes dos parceiros (cabeçalho)
        parceiros = [v.rstrip(':').strip() for v in vals if v.strip()]
        for p in parceiros:
            cidades_por_parceiro[p] = []
        print(f"Parceiros: {parceiros}")
        continue
    elif i == 2:
        # Linha 3: vazia
        continue
    
    # Linhas de dados: cada coluna corresponde a um parceiro
    for j, cidade in enumerate(vals):
        cidade = cidade.strip()
        if cidade and j < len(parceiros):
            cidades_por_parceiro[parceiros[j]].append(cidade)

# Montar lista final: (UF, CIDADE, TELEFONE, OBSERVACAO)
# Todas são MS; observação indica o parceiro logístico
todas_cidades = []
for parceiro, lista in cidades_por_parceiro.items():
    for cidade in lista:
        todas_cidades.append(('MS', cidade.upper(), None, f'Parceiro: {parceiro}'))

print(f"\nTotal de cidades mapeadas: {len(todas_cidades)}")
for parceiro, lista in cidades_por_parceiro.items():
    print(f"  {parceiro}: {len(lista)} cidades")

# Conectar ao banco
conn = mysql.connector.connect(
    host=host, port=port, user=user, password=password, database=database,
    ssl_disabled=False
)
cursor = conn.cursor()

# Encontrar a Braspress
cursor.execute("SELECT id, nome FROM transportadoras WHERE nome LIKE '%raspress%'")
transportadoras = cursor.fetchall()

if not transportadoras:
    # Listar todas para debug
    cursor.execute("SELECT id, nome FROM transportadoras ORDER BY nome")
    todas = cursor.fetchall()
    print("Transportadoras disponíveis:", [(t[0], t[1]) for t in todas])
    conn.close()
    exit(1)

braspress_id, braspress_nome = transportadoras[0]
print(f"\nTransportadora: {braspress_nome} (ID: {braspress_id})")

# Verificar existentes
cursor.execute(
    "SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = %s",
    (braspress_id,)
)
existentes = set(f"{r[1]}|{r[0]}" for r in cursor.fetchall())
print(f"Cidades já cadastradas: {len(existentes)}")

novas = [(uf, cidade, tel, obs) for uf, cidade, tel, obs in todas_cidades
         if f"{uf}|{cidade}" not in existentes]
print(f"Cidades novas a inserir: {len(novas)}")
print(f"Cidades já existentes (puladas): {len(todas_cidades) - len(novas)}")

if not novas:
    print("Todas as cidades já estão cadastradas!")
    conn.close()
    exit(0)

# Inserir em lotes
BATCH = 50
inseridas = 0
for i in range(0, len(novas), BATCH):
    lote = novas[i:i+BATCH]
    placeholders = ', '.join(['(%s, %s, %s, %s, %s)'] * len(lote))
    valores = []
    for uf, cidade, tel, obs in lote:
        valores.extend([braspress_id, cidade, uf, tel, obs])
    cursor.execute(
        f"INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, telefone, observacao) VALUES {placeholders}",
        valores
    )
    inseridas += len(lote)
    print(f"  Inserindo... {inseridas}/{len(novas)}", end='\r')

# Atualizar data
hoje = date.today().isoformat()
cursor.execute(
    "UPDATE transportadoras SET ultAtualizCidades = %s WHERE id = %s",
    (hoje, braspress_id)
)

conn.commit()
cursor.close()
conn.close()

print(f"\n\n✅ Concluído! {inseridas} cidades inseridas para a {braspress_nome}.")
print(f"📅 Data de atualização: {hoje}")
