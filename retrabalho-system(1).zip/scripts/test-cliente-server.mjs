// Testar via servidor local que já tem acesso ao ERP
const base = 'http://localhost:3000/api/trpc';

// Chamar o endpoint getMes para ver a estrutura de dados
const r = await fetch(`${base}/performanceComercial.getMes?input=${encodeURIComponent(JSON.stringify({json:{mes:1,ano:2026}}))}`, {
  headers: { 'Content-Type': 'application/json' }
});
const d = await r.json();
console.log('getMes response keys:', Object.keys(d?.result?.data?.json ?? {}));
console.log('porVendedor[0]:', JSON.stringify(d?.result?.data?.json?.porVendedor?.[0], null, 2));
