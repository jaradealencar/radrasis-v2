import { createConnection } from "mysql2/promise";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import dotenv from "dotenv";

// Carregar variáveis de ambiente
dotenv.config({ path: join(dirname(fileURLToPath(import.meta.url)), "../.env") });

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL não encontrada.");
  process.exit(1);
}

// Ler o JSON gerado pelo script Python
const records = JSON.parse(
  readFileSync("/home/ubuntu/abril2026_retrabalhos.json", "utf-8")
);

console.log(`Importando ${records.length} retrabalhos de Abril 2026...`);

const conn = await createConnection(DATABASE_URL);

// Verificar se já existem registros de Abril 2026
const [existing] = await conn.execute(
  "SELECT COUNT(*) as cnt FROM retrabalhos WHERE mes = 'Abril' AND YEAR(data) = 2026"
);
const existingCount = existing[0].cnt;
if (existingCount > 0) {
  console.log(`\nAVISO: Já existem ${existingCount} registros de Abril 2026 no banco.`);
  console.log("Removendo registros existentes para reimportar...");
  await conn.execute(
    "DELETE FROM retrabalhos WHERE mes = 'Abril' AND YEAR(data) = 2026"
  );
  console.log("Registros antigos removidos.");
}

let inserted = 0;
let errors = 0;

for (const rec of records) {
  try {
    await conn.execute(
      `INSERT INTO retrabalhos 
        (osRetrabalhada, osOriginal, data, setor, tipo, custo, frete, total, codigoErro, responsavel, descricao, classe, mes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        String(rec.osRetrabalho),
        String(rec.osOriginal ?? ""),
        new Date(rec.dataOcorrencia),
        rec.setor,
        rec.tipoRetrabalho,
        rec.custoRetrabalho,
        rec.custoFrete,
        rec.custoTotal,
        rec.codigoErro ?? null,
        rec.responsavel ?? null,
        rec.descricao ?? "",
        rec.classificacao,
        rec.mes,
      ]
    );
    inserted++;
  } catch (err) {
    console.error(`Erro ao inserir OS ${rec.osRetrabalho}:`, err.message);
    errors++;
  }
}

await conn.end();

console.log(`\n✅ Importação concluída!`);
console.log(`   Inseridos: ${inserted}`);
console.log(`   Erros:     ${errors}`);

// Verificar totais
const conn2 = await createConnection(DATABASE_URL);
const [totais] = await conn2.execute(
  `SELECT COUNT(*) as total, SUM(total) as custo_total, SUM(custo) as custo_sem_frete, SUM(frete) as total_frete
   FROM retrabalhos WHERE mes = 'Abril' AND YEAR(data) = 2026`
);
const [evitaveis] = await conn2.execute(
  `SELECT COUNT(*) as cnt FROM retrabalhos WHERE mes = 'Abril' AND YEAR(data) = 2026 AND classe = 'EVITÁVEL'`
);
await conn2.end();

const t = totais[0];
console.log(`\n📊 Resumo Abril 2026:`);
console.log(`   Total de retrabalhos: ${t.total}`);
console.log(`   Custo total (com frete): R$ ${Number(t.custo_total).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`);
console.log(`   Custo produção: R$ ${Number(t.custo_sem_frete).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`);
console.log(`   Custo frete: R$ ${Number(t.total_frete).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`);
console.log(`   Evitáveis: ${evitaveis[0].cnt} de ${t.total}`);
