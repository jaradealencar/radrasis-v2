import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
dotenv.config({ path: resolve(process.cwd(), ".env") });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// 1. Verificar se APT já existe
const [existentes] = await conn.execute(
  "SELECT id, nome FROM transportadoras WHERE nome LIKE '%APT%'"
);

let aptId;
if (existentes.length > 0) {
  aptId = existentes[0].id;
  console.log(`ℹ️  APT já existe: ${existentes[0].nome} (ID: ${aptId})`);
} else {
  // 2. Criar a APT Logística
  const hoje = new Date().toISOString().slice(0, 10);
  const [result] = await conn.execute(
    `INSERT INTO transportadoras 
     (nome, whatsappContato, telefoneContato, formaCotacao, ativa, realizaColeta, ultAtualizCidades, modais, observacoes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      "APT Logística",
      "(67) 4042-0833",
      "(67) 3043-8500",
      "whatsapp",
      "sim",
      "nao",
      hoje,
      JSON.stringify(["rodoviario"]),
      "Parceira da Braspress para cidades do MS. Cidades marcadas com * são atendidas em dias alternados."
    ]
  );
  aptId = result.insertId;
  console.log(`✅ APT Logística criada com ID: ${aptId}`);
}

// 3. Cidades extraídas do PDF
// Formato: [UF, CIDADE, OBSERVACAO]
const cidades = [
  // Atendimento diário
  ["MS", "ÁGUA CLARA", ""],
  ["MS", "AMAMBAI", ""],
  ["MS", "APARECIDA DO TABOADO", ""],
  ["MS", "BANDEIRANTES", ""],
  ["MS", "BONITO", ""],
  ["MS", "CAARAPÓ", ""],
  ["MS", "CAMPO GRANDE", ""],
  ["MS", "COXIM", ""],
  ["MS", "DEODÁPOLIS", ""],
  ["MS", "DOURADOS", ""],
  ["MS", "ELDORADO", ""],
  ["MS", "FÁTIMA DO SUL", ""],
  ["MS", "GLÓRIA DE DOURADOS", ""],
  ["MS", "IGUATEMI", ""],
  ["MS", "INOCÊNCIA", ""],
  ["MS", "ITAQUIRAI", ""],
  ["MS", "JARAGUARI", ""],
  ["MS", "JARDIM", ""],
  ["MS", "JATEÍ", ""],
  ["MS", "JUTI", ""],
  ["MS", "MARACAJU", ""],
  ["MS", "MUNDO NOVO", ""],
  ["MS", "NAVIRAÍ", ""],
  ["MS", "PARANAIBA", ""],
  ["MS", "RIBAS DO RIO PARDO", ""],
  ["MS", "RIO BRILHANTE", ""],
  ["MS", "RIO VERDE", ""],
  ["MS", "SIDROLÂNDIA", ""],
  ["MS", "TRÊS LAGOAS", ""],
  ["MS", "VICENTINA", ""],
  // Dias alternados (*)
  ["MS", "ALCINÓPOLIS", "Dias alternados"],
  ["MS", "ARAL MOREIRA", "Dias alternados"],
  ["MS", "CORGUINHO", "Dias alternados"],
  ["MS", "CORONEL SAPUCAIA", "Dias alternados"],
  ["MS", "DOURADINA", "Dias alternados"],
  ["MS", "FIGUEIRÃO", "Dias alternados"],
  ["MS", "GUIA LOPES DA LAGUNA", "Dias alternados"],
  ["MS", "ITAPORÃ", "Dias alternados"],
  ["MS", "LAGUNA CARAPÃ", "Dias alternados"],
  ["MS", "PARANHOS", "Dias alternados"],
  ["MS", "RIO NEGRO", "Dias alternados"],
  ["MS", "ROCHEDO", "Dias alternados"],
  ["MS", "SÃO GABRIEL DO OESTE", "Dias alternados"],
  ["MS", "SETE QUEDAS", "Dias alternados"],
  ["MS", "TACURU", "Dias alternados"],
];

// 4. Verificar existentes
const [cidadesExistentes] = await conn.execute(
  "SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?",
  [aptId]
);
const existSet = new Set(cidadesExistentes.map(c => `${c.estado}|${c.cidade}`));
console.log(`Cidades já cadastradas: ${existSet.size}`);

const novas = cidades.filter(([uf, cidade]) => !existSet.has(`${uf}|${cidade}`));
console.log(`Cidades novas a inserir: ${novas.length}`);

if (novas.length > 0) {
  const BATCH = 30;
  let inseridas = 0;
  for (let i = 0; i < novas.length; i += BATCH) {
    const lote = novas.slice(i, i + BATCH);
    const placeholders = lote.map(() => "(?, ?, ?, ?, ?)").join(", ");
    const valores = lote.flatMap(([uf, cidade, obs]) => [aptId, cidade, uf, null, obs || null]);
    await conn.execute(
      `INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, telefone, observacao) VALUES ${placeholders}`,
      valores
    );
    inseridas += lote.length;
  }
  console.log(`✅ ${inseridas} cidades inseridas!`);
}

// 5. Atualizar data
const hoje = new Date().toISOString().slice(0, 10);
await conn.execute("UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = ?", [hoje, aptId]);

console.log(`\n✅ Concluído! APT Logística (ID: ${aptId}) com ${cidades.length} cidades de MS.`);
console.log(`📅 Data de atualização: ${hoje}`);
await conn.end();
