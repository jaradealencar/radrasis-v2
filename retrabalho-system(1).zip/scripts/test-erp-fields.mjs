/**
 * Script para testar os campos retornados pela API do ERP Mubisys
 * Executa: node scripts/test-erp-fields.mjs
 */
import https from "https";

function fetchMubisys(publicKey, accessToken, path) {
  return new Promise((resolve) => {
    const url = `https://api.mubisys.com/api/${publicKey}${path}`;
    console.log("Fetching:", url);
    const req = https.get(
      url,
      { headers: { "Access-Token": accessToken, Accept: "application/json" } },
      (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => {
          try { resolve({ status: res.statusCode, data: JSON.parse(body) }); }
          catch { resolve({ status: res.statusCode, data: { raw: body.substring(0, 500) } }); }
        });
      }
    );
    req.on("error", (e) => resolve({ status: 0, data: { error: e.message } }));
    req.setTimeout(15000, () => { req.destroy(); resolve({ status: 0, data: { error: "timeout" } }); });
  });
}

const publicKey = process.env.MUBISYS_PUBLIC_KEY;
const accessToken = process.env.MUBISYS_ACCESS_TOKEN;

if (!publicKey || !accessToken) {
  console.error("MUBISYS_PUBLIC_KEY e MUBISYS_ACCESS_TOKEN são necessários");
  process.exit(1);
}

// Testar 1 OS Normal de maio/2026
console.log("\n=== TESTE: OS Normais (1 registro) ===");
const osResp = await fetchMubisys(publicKey, accessToken,
  "/ordem-servico?status=TODOS&filtrodata=APROVACAO&tipo=Normal&datainicial=2026-05-01&datafinal=2026-05-12&page=1&per_page=1"
);
console.log("Status:", osResp.status);
if (osResp.data?.data?.[0]) {
  const os = osResp.data.data[0];
  console.log("Campos disponíveis na OS:", Object.keys(os));
  console.log("Exemplo:", JSON.stringify(os, null, 2));
} else {
  console.log("Resposta:", JSON.stringify(osResp.data, null, 2).substring(0, 1000));
}

// Testar 1 Orçamento
console.log("\n=== TESTE: Orçamentos (1 registro) ===");
const orcResp = await fetchMubisys(publicKey, accessToken,
  "/orcamento?status=TODOS&filtrodata=CADASTRO&datainicial=2026-05-01&datafinal=2026-05-12&page=1&per_page=1"
);
console.log("Status:", orcResp.status);
if (orcResp.data?.data?.[0]) {
  const orc = orcResp.data.data[0];
  console.log("Campos disponíveis no Orçamento:", Object.keys(orc));
  console.log("Exemplo:", JSON.stringify(orc, null, 2));
} else {
  console.log("Resposta:", JSON.stringify(orcResp.data, null, 2).substring(0, 1000));
}
