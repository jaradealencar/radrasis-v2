import mysql from "mysql2/promise";
import dotenv from "dotenv";
import { readFileSync } from "fs";

dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const cidades = JSON.parse(readFileSync("/tmp/gol_cidades.json", "utf-8"));

const GOLLOG_ID = 11;
const hoje = new Date().toISOString().split("T")[0];

console.log(`Inserindo ${cidades.length} cidades na Gollog (ID: ${GOLLOG_ID})...`);

// Verificar cidades existentes para evitar duplicatas
const [existentes] = await conn.execute(
  `SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?`,
  [GOLLOG_ID]
);
const existentesSet = new Set(existentes.map(r => `${r.cidade}|${r.estado}`));
console.log(`Cidades já existentes: ${existentesSet.size}`);

// Filtrar novas cidades (case-insensitive)
const novas = cidades.filter(c => {
  const key = `${c.cidade}|${c.estado}`;
  return !existentesSet.has(key);
});
console.log(`Cidades novas a inserir: ${novas.length}`);

// Inserir em lotes de 200
const LOTE = 200;
let inseridas = 0;
let erros = 0;

for (let i = 0; i < novas.length; i += LOTE) {
  const lote = novas.slice(i, i + LOTE);
  for (const c of lote) {
    try {
      await conn.execute(
        `INSERT IGNORE INTO transportadora_cidades (transportadoraId, cidade, estado, observacao, createdAt) VALUES (?, ?, ?, ?, NOW())`,
        [GOLLOG_ID, c.cidade, c.estado, c.observacao || null]
      );
      inseridas++;
    } catch (e) {
      if (!e.message.includes("Duplicate")) {
        erros++;
      }
    }
  }
  process.stdout.write(`\r  Progresso: ${Math.min(i + LOTE, novas.length)}/${novas.length}`);
}

// Atualizar data de última atualização
await conn.execute(
  `UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = ?`,
  [hoje, GOLLOG_ID]
);

// Contar total final
const [[{ total }]] = await conn.execute(
  `SELECT COUNT(*) as total FROM transportadora_cidades WHERE transportadoraId = ?`,
  [GOLLOG_ID]
);

await conn.end();
console.log(`\n\n✅ Concluído!`);
console.log(`   Inseridas: ${inseridas}`);
console.log(`   Erros: ${erros}`);
console.log(`   Total na Gollog: ${total}`);
