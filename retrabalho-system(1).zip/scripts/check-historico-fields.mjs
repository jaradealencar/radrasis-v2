// Verificar campos disponíveis nas tabelas de histórico via servidor local
const base = 'http://localhost:3000/api/trpc';

// Verificar clientes novos de maio/2026
const r = await fetch(`${base}/performanceComercial.getClientesNovos?input=${encodeURIComponent(JSON.stringify({json:{mes:5,ano:2026}}))}`, {
  headers: { 'Content-Type': 'application/json' }
});
const d = await r.json();
console.log('Clientes novos Maio/2026:', JSON.stringify(d?.result?.data?.json, null, 2));
