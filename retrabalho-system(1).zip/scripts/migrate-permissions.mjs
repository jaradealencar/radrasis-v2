import { createConnection } from "mysql2/promise";
import * as dotenv from "dotenv";
import { readFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: resolve(__dirname, "../.env") });

const url = process.env.DATABASE_URL;
if (!url) { console.error("DATABASE_URL not set"); process.exit(1); }

const conn = await createConnection(url);

console.log("Creating local_users table...");
await conn.execute(`
  CREATE TABLE IF NOT EXISTS \`local_users\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`name\` varchar(128) NOT NULL,
    \`email\` varchar(320) NOT NULL,
    \`passwordHash\` varchar(256) NOT NULL,
    \`role\` enum('master','admin','vendas','logistica','producao','financeiro') NOT NULL DEFAULT 'vendas',
    \`active\` enum('sim','nao') NOT NULL DEFAULT 'sim',
    \`createdAt\` timestamp NOT NULL DEFAULT (now()),
    \`updatedAt\` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT \`local_users_id\` PRIMARY KEY(\`id\`),
    CONSTRAINT \`local_users_email_unique\` UNIQUE(\`email\`)
  )
`);

console.log("Creating role_permissions table...");
await conn.execute(`
  CREATE TABLE IF NOT EXISTS \`role_permissions\` (
    \`id\` int AUTO_INCREMENT NOT NULL,
    \`role\` enum('master','admin','vendas','logistica','producao','financeiro') NOT NULL,
    \`pageKey\` varchar(64) NOT NULL,
    \`canAccess\` enum('sim','nao') NOT NULL DEFAULT 'nao',
    CONSTRAINT \`role_permissions_id\` PRIMARY KEY(\`id\`)
  )
`);

// Seed de permissões padrão
const roles = ["master", "admin", "vendas", "logistica", "producao", "financeiro"];
const pages = [
  "painel", "retrabalhos", "inserir", "biblioteca", "reincidencia",
  "relatorio", "insights", "conhecimento", "fornecedores", "rotinas",
  "regulamentos", "pops", "admin",
];

// Permissões padrão por role
const defaults = {
  master:     pages, // acesso total
  admin:      pages, // acesso total
  vendas:     ["painel", "retrabalhos", "inserir", "biblioteca", "relatorio"],
  logistica:  ["painel", "retrabalhos", "inserir", "biblioteca", "relatorio", "fornecedores", "rotinas"],
  producao:   ["painel", "retrabalhos", "inserir", "biblioteca", "reincidencia", "relatorio", "insights", "pops", "rotinas"],
  financeiro: ["painel", "relatorio", "insights", "faturamento"],
};

console.log("Seeding default permissions...");
// Limpar permissões existentes para re-seed
await conn.execute("DELETE FROM role_permissions");

for (const role of roles) {
  const allowed = defaults[role] ?? [];
  for (const page of pages) {
    const canAccess = allowed.includes(page) ? "sim" : "nao";
    await conn.execute(
      "INSERT INTO role_permissions (role, pageKey, canAccess) VALUES (?, ?, ?)",
      [role, page, canAccess]
    );
  }
}

console.log("✅ Migration and seed complete!");
await conn.end();
