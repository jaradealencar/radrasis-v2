import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Verificar transportadoras com cidades mas sem data de atualização
const [rows] = await conn.execute(`
  SELECT t.id, t.nome, t.ultAtualizCidades, COUNT(tc.id) as total
  FROM transportadoras t
  LEFT JOIN transportadora_cidades tc ON tc.transportadoraId = t.id
  GROUP BY t.id, t.nome, t.ultAtualizCidades
  HAVING total > 0
  ORDER BY total DESC
  LIMIT 30
`);

console.log("Transportadoras com cidades:");
for (const r of rows) {
  console.log(`  ${r.nome}: ${r.total} cidades, data: ${r.ultAtualizCidades || "SEM DATA"}`);
}

// Atualizar as que têm cidades mas sem data
const hoje = new Date().toISOString().split("T")[0];
const [semData] = await conn.execute(`
  SELECT t.id, t.nome
  FROM transportadoras t
  INNER JOIN transportadora_cidades tc ON tc.transportadoraId = t.id
  WHERE t.ultAtualizCidades IS NULL OR t.ultAtualizCidades = ''
  GROUP BY t.id, t.nome
`);

if (semData.length > 0) {
  console.log(`\nAtualizando ${semData.length} transportadoras sem data...`);
  for (const t of semData) {
    await conn.execute(
      `UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = ?`,
      [hoje, t.id]
    );
    console.log(`  ✅ ${t.nome}`);
  }
} else {
  console.log("\nTodas as transportadoras com cidades já têm data de atualização.");
}

await conn.end();
console.log("\nConcluído!");
