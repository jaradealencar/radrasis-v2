import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
dotenv.config({ path: resolve(process.cwd(), ".env") });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ─── 1. BRASPRESS: marcar como cobertura nacional ───────────────────────────
// Verificar se há campo coberturaTotal ou similar
const [cols] = await conn.execute("SHOW COLUMNS FROM transportadoras");
const colNames = cols.map(c => c.Field);
console.log("Colunas disponíveis:", colNames.join(", "));

// Verificar se já existe campo coberturaTotal
if (!colNames.includes("coberturaTotal")) {
  await conn.execute("ALTER TABLE transportadoras ADD COLUMN coberturaTotal TINYINT(1) NOT NULL DEFAULT 0");
  console.log("✅ Campo coberturaTotal adicionado à tabela transportadoras");
}

await conn.execute("UPDATE transportadoras SET coberturaTotal = 1 WHERE id = 5");
console.log("✅ Braspress marcada como cobertura nacional (todos os municípios do Brasil)");

// ─── 2. MOTTA: inserir cidades do PDF ────────────────────────────────────────
// Cidades extraídas do PDF (Sigla, Unidade, Cidade, UF)
const cidadesMotta = [
  ["SP","AMERICANA"],
  ["GO","ANÁPOLIS"],
  ["SP","ARAÇATUBA"],
  ["MG","ARAGUARI"],
  ["SP","ARARAQUARA"],
  ["SP","ASSIS"],
  ["MS","BANDEIRANTES"],
  ["SP","BARRETOS"],
  ["MS","BATAGUASSU"],
  ["SP","BAURU"],
  ["MG","BELO HORIZONTE"],
  ["SP","BIRIGUI"],
  ["MS","CAMPO GRANDE"],
  ["MS","CHAPADÃO DO SUL"],
  ["MT","CUIABÁ"],
  ["MS","DEODÁPOLIS"],
  ["MS","VICENTINA"],  // FAT = Fátima do Sul MS → cidade real é Vicentina
  ["SP","FRANCA"],
  ["MS","GLÓRIA DE DOURADOS"],
  ["GO","GOIÂNIA"],
  ["MS","IVINHEMA"],
  ["MT","JACIARA"],
  ["SP","JAÚ"],
  ["PR","LONDRINA"],
  ["SP","MARÍLIA"],
  ["PR","MARINGÁ"],
  ["MS","NAVIRAÍ"],
  ["MS","NOVA ALVORADA DO SUL"],
  ["MS","NOVA ANDRADINA"],
  ["SP","OURINHOS"],
  ["SP","PIRACICABA"],
  ["MS","PONTA PORÃ"],
  ["SP","PRESIDENTE EPITÁCIO"],
  ["SP","PRESIDENTE PRUDENTE"],
  ["SP","PRESIDENTE VENCESLAU"],
  ["SP","RIBEIRÃO PRETO"],
  ["MT","RONDONÓPOLIS"],
  ["SP","SÃO JOSÉ DO RIO PRETO"],
  ["MG","SÃO SEBASTIÃO DO PARAÍSO"],
  ["SP","SÃO PAULO"],
  ["MS","SONORA"],
  ["MS","TRÊS LAGOAS"],
  ["MG","UBERABA"],
  ["MG","UBERLÂNDIA"],
  ["DF","BRASÍLIA"],
  ["SP","CAMPINAS"],
  ["GO","CATALÃO"],
  ["MS","DOURADOS"],
  ["MS","RIO BRILHANTE"],
  ["MS","RIO VERDE DE MATO GROSSO"],
  ["GO","RIO VERDE"],
];

console.log(`\nTotal de cidades da Motta no PDF: ${cidadesMotta.length}`);

// Verificar existentes na Motta (ID 19)
const [existentes] = await conn.execute(
  "SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = 19"
);
const existSet = new Set(existentes.map(c => `${c.estado}|${c.cidade}`));
console.log(`Cidades já cadastradas na Motta: ${existSet.size}`);

const novas = cidadesMotta.filter(([uf, cidade]) => !existSet.has(`${uf}|${cidade}`));
console.log(`Cidades novas a inserir: ${novas.length}`);
console.log(`Já existentes (puladas): ${cidadesMotta.length - novas.length}`);

if (novas.length > 0) {
  const BATCH = 50;
  let inseridas = 0;
  for (let i = 0; i < novas.length; i += BATCH) {
    const lote = novas.slice(i, i + BATCH);
    const placeholders = lote.map(() => "(?, ?, ?, ?, ?)").join(", ");
    const valores = lote.flatMap(([uf, cidade]) => [19, cidade, uf, null, null]);
    await conn.execute(
      `INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, telefone, observacao) VALUES ${placeholders}`,
      valores
    );
    inseridas += lote.length;
  }
  console.log(`✅ ${inseridas} cidades inseridas na Motta!`);
}

// Atualizar data
const hoje = new Date().toISOString().slice(0, 10);
await conn.execute("UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = 19", [hoje]);
console.log(`📅 Data de atualização da Motta: ${hoje}`);

// Resumo por estado
const porEstado = {};
for (const [uf] of novas) {
  porEstado[uf] = (porEstado[uf] || 0) + 1;
}
if (Object.keys(porEstado).length > 0) {
  console.log("\nNovas cidades por estado:");
  for (const [uf, qtd] of Object.entries(porEstado).sort()) {
    console.log(`  ${uf}: ${qtd}`);
  }
}

await conn.end();
console.log("\n✅ Tudo concluído!");
