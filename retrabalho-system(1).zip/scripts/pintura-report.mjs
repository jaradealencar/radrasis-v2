import fs from 'fs';

const data = JSON.parse(fs.readFileSync('/home/ubuntu/retrabalho-system/scripts/pintura-classificada.json', 'utf-8'));

// Agrupar por categoria e mês
const catMes = {};
data.items.forEach(it => {
  const key = it.categoria;
  if (catMes[key] === undefined) catMes[key] = {};
  if (catMes[key][it.mes] === undefined) catMes[key][it.mes] = { valor: 0, m2: 0, count: 0 };
  catMes[key][it.mes].valor += it.sub_total;
  catMes[key][it.mes].m2 += it.m2 * it.quantidade;
  catMes[key][it.mes].count++;
});

const categorias = ['PU 1 cor', 'PU 2 cores', 'Metalizada', 'Não classificado'];
categorias.forEach(cat => {
  if (catMes[cat] === undefined) return;
  console.log(`\n=== ${cat} ===`);
  console.log('Mês       | Qtd | Faturado      | m²      | R$/m²');
  console.log('----------|-----|---------------|---------|--------');
  Object.entries(catMes[cat]).sort().forEach(([mes, d]) => {
    const pm2 = d.m2 > 0 ? d.valor / d.m2 : 0;
    console.log(`${mes} | ${String(d.count).padStart(3)} | R$ ${d.valor.toFixed(2).padStart(10)} | ${d.m2.toFixed(3).padStart(7)} | R$ ${pm2.toFixed(2)}`);
  });
});

// Resumo geral
console.log('\n\n=== RESUMO GERAL ===');
console.log('Categoria      | Qtd | Total Faturado | Total m²  | Preço Médio/m²');
console.log('---------------|-----|----------------|-----------|---------------');
data.resumo.forEach(r => {
  console.log(`${r.categoria.padEnd(14)} | ${String(r.qtd_registros).padStart(3)} | R$ ${r.total_faturado.toFixed(2).padStart(11)} | ${r.total_m2.toFixed(3).padStart(9)} | R$ ${r.preco_medio_m2.toFixed(2)}`);
});

// Nota sobre não classificados
console.log('\n=== NOTA ===');
console.log('Os "Não classificados" são serviços de verniz (Aplicação de Verniz Brilhante, Verniz Dourado em Inox)');
console.log('que não se enquadram nas categorias de pintura PU por cores.');

// Nota sobre PU 3 e 4 cores
console.log('\n=== OBSERVAÇÃO ===');
console.log('Não foram encontradas OS com pintura de 3 ou 4 cores no período analisado (Jan-Jun 2026).');
console.log('Apenas PU 1 cor, PU 2 cores e Metalizada foram utilizados.');
