import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
dotenv.config({ path: resolve(process.cwd(), ".env") });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const [rows] = await conn.execute(
  "SELECT id, sectionTitle, contentJson FROM price_table_sections WHERE id = 19"
);

const row = rows[0];
console.log(`Processando: ${row.sectionTitle}\n`);

const json = JSON.parse(row.contentJson);

// Aumentar percentual em 3% (× 1.03), arredondar para 1 casa decimal
function aumentar3pct(valorStr) {
  const trimmed = valorStr.trim();
  // Verificar se termina com % e começa com número
  if (!trimmed.endsWith("%")) return valorStr;
  const numStr = trimmed.slice(0, -1).replace(",", ".");
  const numero = parseFloat(numStr);
  if (isNaN(numero)) return valorStr;
  const novo = numero * 1.03;
  const novoArredondado = Math.round(novo * 10) / 10;
  const novoStr = novoArredondado % 1 === 0
    ? `${novoArredondado}%`
    : `${novoArredondado.toFixed(1).replace(".", ",")}%`;
  return novoStr;
}

const alteracoes = [];

// A estrutura é margin_table_multi com rows direto (não dentro de tables)
for (const r of json.rows || []) {
  for (let i = 0; i < (r.values || []).length; i++) {
    const original = r.values[i];
    const novo = aumentar3pct(original);
    if (novo !== original) {
      alteracoes.push(`  ${original} → ${novo}`);
      r.values[i] = novo;
    }
  }
}

if (alteracoes.length > 0) {
  await conn.execute(
    "UPDATE price_table_sections SET contentJson = ? WHERE id = 19",
    [JSON.stringify(json)]
  );
  console.log(`✅ ${alteracoes.length} percentuais atualizados:`);
  for (const alt of alteracoes) console.log(alt);
} else {
  console.log("Nenhum percentual encontrado para alterar.");
}

await conn.end();
