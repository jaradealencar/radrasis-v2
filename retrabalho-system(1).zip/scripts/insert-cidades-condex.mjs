import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
dotenv.config({ path: resolve(process.cwd(), ".env") });

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Encontrar a Condex
const [transportadoras] = await conn.execute(
  "SELECT id, nome FROM transportadoras WHERE nome LIKE '%ondex%' OR nome LIKE '%ONDEX%'"
);

if (transportadoras.length === 0) {
  const [todas] = await conn.execute("SELECT id, nome FROM transportadoras ORDER BY nome");
  console.log("Transportadoras disponíveis:", todas.map(t => `${t.nome} (ID:${t.id})`).join("\n  "));
  await conn.end();
  process.exit(1);
}

const condex = transportadoras[0];
console.log(`Transportadora: ${condex.nome} (ID: ${condex.id})`);

// Cidades extraídas do PDF - todas MS
// Formato: [UF, CIDADE, DISTANCIA_KM, FAIXA]
const cidades = [
  // Interior 01 - Até 255 km
  ["MS","ÁGUA CLARA","193","Interior 01 - Até 255 km"],
  ["MS","ANASTÁCIO","134","Interior 01 - Até 255 km"],
  ["MS","AQUIDAUANA","143","Interior 01 - Até 255 km"],
  ["MS","BANDEIRANTES","68","Interior 01 - Até 255 km"],
  ["MS","CAMAPUÃ","135","Interior 01 - Até 255 km"],
  ["MS","CORGUINHO","96","Interior 01 - Até 255 km"],
  ["MS","COXIM","253","Interior 01 - Até 255 km"],
  ["MS","DOIS IRMÃOS BURITI","84","Interior 01 - Até 255 km"],
  ["MS","DOURADINA","194","Interior 01 - Até 255 km"],
  ["MS","DOURADOS","225","Interior 01 - Até 255 km"],
  ["MS","FÁTIMA DO SUL","237","Interior 01 - Até 255 km"],
  ["MS","FIGUEIRÃO","244","Interior 01 - Até 255 km"],
  ["MS","GUIA LOPES LAGUNA","234","Interior 01 - Até 255 km"],
  ["MS","ITAPORÃ","225","Interior 01 - Até 255 km"],
  ["MS","JARAGUARI","47","Interior 01 - Até 255 km"],
  ["MS","JARDIM","239","Interior 01 - Até 255 km"],
  ["MS","MARACAJÚ","162","Interior 01 - Até 255 km"],
  ["MS","MIRANDA","203","Interior 01 - Até 255 km"],
  ["MS","NIOAQUE","187","Interior 01 - Até 255 km"],
  ["MS","NOVA ALVORADA","120","Interior 01 - Até 255 km"],
  ["MS","NOVO HORIZONTE","230","Interior 01 - Até 255 km"],
  ["MS","RIBAS DO RIO PARDO","97","Interior 01 - Até 255 km"],
  ["MS","RIO BRILHANTE","158","Interior 01 - Até 255 km"],
  ["MS","RIO NEGRO","163","Interior 01 - Até 255 km"],
  ["MS","RIO VERDE","194","Interior 01 - Até 255 km"],
  ["MS","ROCHEDO","81","Interior 01 - Até 255 km"],
  ["MS","SÃO GABRIEL OESTE","133","Interior 01 - Até 255 km"],
  ["MS","SIDROLÂNDIA","70","Interior 01 - Até 255 km"],
  ["MS","TERENOS","28","Interior 01 - Até 255 km"],
  ["MS","VICENTINA","246","Interior 01 - Até 255 km"],
  // Interior 02 - 256 até 366 km
  ["MS","AMAMBAI","352","Interior 02 - 256 a 366 km"],
  ["MS","ANAURILÂNDIA","366","Interior 02 - 256 a 366 km"],
  ["MS","ANGÉLICA","323","Interior 02 - 256 a 366 km"],
  ["MS","BATAGUASSU","335","Interior 02 - 256 a 366 km"],
  ["MS","BATAYPORÃ","306","Interior 02 - 256 a 366 km"],
  ["MS","BELA VISTA","324","Interior 02 - 256 a 366 km"],
  ["MS","BODOQUENA","260","Interior 02 - 256 a 366 km"],
  ["MS","BONITO","300","Interior 02 - 256 a 366 km"],
  ["MS","CAARAPÓ","273","Interior 02 - 256 a 366 km"],
  ["MS","CHAPADÃO DO SUL","325","Interior 02 - 256 a 366 km"],
  ["MS","DEODÁPOLIS","260","Interior 02 - 256 a 366 km"],
  ["MS","GLÓRIA DE DOURADOS","275","Interior 02 - 256 a 366 km"],
  ["MS","INOCÊNCIA","321","Interior 02 - 256 a 366 km"],
  ["MS","IVINHEMA","291","Interior 02 - 256 a 366 km"],
  ["MS","JATEÍ","260","Interior 02 - 256 a 366 km"],
  ["MS","JUTI","331","Interior 02 - 256 a 366 km"],
  ["MS","LAGUNA CARAPÃ","275","Interior 02 - 256 a 366 km"],
  ["MS","NAVIRAÍ","359","Interior 02 - 256 a 366 km"],
  ["MS","NOVA ANDRADINA","294","Interior 02 - 256 a 366 km"],
  ["MS","PARAÍDO DAS ÁGUAS","277","Interior 02 - 256 a 366 km"],
  ["MS","PEDRO GOMES","296","Interior 02 - 256 a 366 km"],
  ["MS","PONTA PORÃ","346","Interior 02 - 256 a 366 km"],
  ["MS","SANTA RITA","267","Interior 02 - 256 a 366 km"],
  ["MS","SONORA","351","Interior 02 - 256 a 366 km"],
  ["MS","TAQUARUSSU","325","Interior 02 - 256 a 366 km"],
  ["MS","TRÊS LAGOAS","338","Interior 02 - 256 a 366 km"],
  // Interior 03 - 367 até 500 km
  ["MS","ALCINÓPOLIS","387","Interior 03 - 367 a 500 km"],
  ["MS","ANTÔNIO JOÃO","402","Interior 03 - 367 a 500 km"],
  ["MS","APAR DO TABOADO","457","Interior 03 - 367 a 500 km"],
  ["MS","ARAL MOREIRA","402","Interior 03 - 367 a 500 km"],
  ["MS","BRASILÂNDIA","399","Interior 03 - 367 a 500 km"],
  ["MS","CARACOL","384","Interior 03 - 367 a 500 km"],
  ["MS","CASSILÂNDIA","430","Interior 03 - 367 a 500 km"],
  ["MS","CORONEL SAPUCAIA","380","Interior 03 - 367 a 500 km"],
  ["MS","CORUMBÁ","429","Interior 03 - 367 a 500 km"],
  ["MS","COSTA RICA","384","Interior 03 - 367 a 500 km"],
  ["MS","ELDORADO","440","Interior 03 - 367 a 500 km"],
  ["MS","IGUATEMI","466","Interior 03 - 367 a 500 km"],
  ["MS","ITAQUIRAÍ","402","Interior 03 - 367 a 500 km"],
  ["MS","JAPORÃ","477","Interior 03 - 367 a 500 km"],
  ["MS","LADÁRIO","426","Interior 03 - 367 a 500 km"],
  ["MS","MUNDO NOVO","462","Interior 03 - 367 a 500 km"],
  ["MS","PARANAÍBA","407","Interior 03 - 367 a 500 km"],
  ["MS","PARANHOS","477","Interior 03 - 367 a 500 km"],
  ["MS","PORTO MURTINHO","454","Interior 03 - 367 a 500 km"],
  ["MS","SELVÍRIA","459","Interior 03 - 367 a 500 km"],
  ["MS","SETE QUEDAS","459","Interior 03 - 367 a 500 km"],
  ["MS","TACURÚ","416","Interior 03 - 367 a 500 km"],
];

console.log(`Total de cidades no PDF: ${cidades.length}`);

// Verificar existentes
const [existentes] = await conn.execute(
  "SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?",
  [condex.id]
);
const existSet = new Set(existentes.map(c => `${c.estado}|${c.cidade}`));
console.log(`Cidades já cadastradas: ${existSet.size}`);

// Atualizar observações das existentes e inserir novas
let atualizadas = 0;
let inseridas = 0;

for (const [uf, cidade, dist, faixa] of cidades) {
  const key = `${uf}|${cidade}`;
  const obs = `${faixa} (${dist} km de Campo Grande)`;
  if (existSet.has(key)) {
    // Atualizar observação
    await conn.execute(
      "UPDATE transportadora_cidades SET observacao = ? WHERE transportadoraId = ? AND cidade = ? AND estado = ?",
      [obs, condex.id, cidade, uf]
    );
    atualizadas++;
  } else {
    // Inserir nova
    await conn.execute(
      "INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, telefone, observacao) VALUES (?, ?, ?, ?, ?)",
      [condex.id, cidade, uf, null, obs]
    );
    inseridas++;
  }
}

// Atualizar data
const hoje = new Date().toISOString().slice(0, 10);
await conn.execute("UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = ?", [hoje, condex.id]);

console.log(`\n✅ Concluído!`);
console.log(`  Novas inseridas: ${inseridas}`);
console.log(`  Existentes atualizadas: ${atualizadas}`);
console.log(`  Total na Condex: ${existSet.size + inseridas} cidades`);
console.log(`📅 Data de atualização: ${hoje}`);
console.log(`\nContato filial Campo Grande: (67) 3321-0556 — Paulo Cesar`);
console.log(`Contato matriz SP: (11) 2635-2034`);

await conn.end();
