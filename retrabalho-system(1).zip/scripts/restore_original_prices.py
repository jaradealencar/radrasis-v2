#!/usr/bin/env python3
"""
Script para restaurar todos os preços aos valores originais
usando os backups criados antes dos aumentos de 8%
"""

import mysql.connector
import subprocess
import sys
from datetime import datetime

# Configurações do banco de dados
DB_CONFIG = {
    'host': 'gateway05.us-east-1.prod.aws.tidbcloud.com',
    'port': 4000,
    'user': 'w9E6B1CFVfikCKB.cee5432df873',
    'password': 'WR6W2CnU8s1KSjQ2hWm0',
    'database': 'PzdanzaCSk4JPsdTBVnd3F',
    'ssl_disabled': False,
    'ssl_verify_cert': False,
    'ssl_verify_identity': False,
}

def connect_db():
    """Conecta ao banco de dados"""
    return mysql.connector.connect(**DB_CONFIG)

def restore_from_backup(backup_file, table_name):
    """Restaura uma tabela a partir do arquivo de backup"""
    print(f"\nRestaurando {table_name} a partir do backup...")
    
    try:
        # Lê o arquivo de backup
        with open(backup_file, 'r') as f:
            backup_sql = f.read()
        
        # Conecta e executa o restore
        conn = connect_db()
        cursor = conn.cursor()
        
        # Primeiro, deleta todos os registros da tabela
        cursor.execute(f"DELETE FROM {table_name}")
        print(f"  ✓ Registros antigos deletados")
        
        # Executa o SQL do backup
        # Divide em múltiplas statements
        statements = backup_sql.split(';')
        for statement in statements:
            statement = statement.strip()
            if statement and not statement.startswith('--') and not statement.startswith('/*'):
                try:
                    cursor.execute(statement)
                except Exception as e:
                    # Ignora erros de DROP TABLE ou CREATE TABLE que já existem
                    if 'already exists' not in str(e) and 'no such table' not in str(e):
                        print(f"  ⚠ Aviso: {e}")
        
        conn.commit()
        cursor.close()
        conn.close()
        
        print(f"  ✓ {table_name} restaurada com sucesso")
        return True
        
    except Exception as e:
        print(f"  ❌ Erro ao restaurar {table_name}: {e}")
        return False

def main():
    """Função principal"""
    print("=" * 70)
    print("RESTAURAR TODOS OS PREÇOS AOS VALORES ORIGINAIS")
    print("=" * 70)
    print(f"Timestamp: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    # Arquivos de backup
    backup_sections = '/tmp/price_table_sections_backup_20260616_163102.sql'
    backup_meta = '/tmp/price_table_meta_backup_20260616_163102.sql'
    
    print(f"Backup sections: {backup_sections}")
    print(f"Backup meta: {backup_meta}")
    print()
    
    # Restaura as tabelas
    success_1 = restore_from_backup(backup_sections, 'price_table_sections')
    success_2 = restore_from_backup(backup_meta, 'price_table_meta')
    
    print()
    print("=" * 70)
    print("RESUMO")
    print("=" * 70)
    
    if success_1 and success_2:
        print("✓ Todos os preços foram restaurados aos valores originais")
        print("✓ price_table_sections (Clientes Tradicionais) — restaurada")
        print("✓ price_table_meta (Clientes Novos) — restaurada")
        print()
        print("Restauração concluída com sucesso!")
        print("=" * 70)
        return 0
    else:
        print("❌ Erro ao restaurar os preços")
        print("=" * 70)
        return 1

if __name__ == '__main__':
    sys.exit(main())
