import https from 'https';
import fs from 'fs';

const publicKey = process.env.MUBISYS_PUBLIC_KEY;
const accessToken = process.env.MUBISYS_ACCESS_TOKEN;

function fetchPage(start, end, page) {
  return new Promise((resolve) => {
    const path = `/ordem-servico?status=TODOS&filtrodata=CADASTRO&datainicial=${start}&datafinal=${end}&page=${page}&per_page=500`;
    const url = `https://api.mubisys.com/api/${publicKey}${path}`;
    const req = https.get(url, { headers: { 'Access-Token': accessToken, 'Accept': 'application/json' } }, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => { try { resolve(JSON.parse(body)); } catch { resolve({}); } });
    });
    req.on('error', () => resolve({}));
    req.setTimeout(30000, () => { req.destroy(); resolve({}); });
  });
}

async function fetchAllOsForPeriod(start, end) {
  let all = [];
  let page = 1;
  while (true) {
    const d = await fetchPage(start, end, page);
    const items = (d.data || []);
    if (items.length === 0) break;
    all = all.concat(items);
    const pagination = d.pagination;
    if (!pagination || page >= (pagination.last_page || 1)) break;
    page++;
  }
  return all;
}

// Classificar o modelo de pintura por número de cores
function classificarPintura(modelo) {
  const m = (modelo || '').toLowerCase();
  
  // Metalizada (separar primeiro)
  if (m.includes('metalizada') || m.includes('poliéster') || m.includes('poliester')) {
    return 'Metalizada';
  }
  
  // PU por número de cores
  if (m.includes('4 cor')) return 'PU 4 cores';
  if (m.includes('3 cor')) return 'PU 3 cores';
  if (m.includes('2 cor')) return 'PU 2 cores';
  if (m.includes('1 cor') || m.includes('uma cor')) return 'PU 1 cor';
  
  // Fallback - tentar identificar pelo texto
  if (m.includes('p.u') || m.includes('pu')) {
    // Se menciona PU mas não especifica cores, classificar como 1 cor (padrão)
    return 'PU 1 cor';
  }
  
  return 'Não classificado';
}

async function main() {
  const periods = [
    ['2026-01-01', '2026-01-31'],
    ['2026-02-01', '2026-02-28'],
    ['2026-03-01', '2026-03-31'],
    ['2026-04-01', '2026-04-30'],
    ['2026-05-01', '2026-05-31'],
    ['2026-06-01', '2026-06-04'],
  ];

  const allPinturaItems = [];
  const modelosDistintos = new Set();

  for (const [start, end] of periods) {
    console.error(`Fetching ${start} to ${end}...`);
    const osList = await fetchAllOsForPeriod(start, end);
    console.error(`  Got ${osList.length} OS`);
    
    for (const os of osList) {
      for (const it of (os.itens || [])) {
        const item = (it.item || '').toLowerCase();
        if (item.includes('pintura')) {
          const largura = parseFloat(it.largura) || 0;
          const altura = parseFloat(it.altura) || 0;
          const m2 = largura * altura;
          const modelo = it.modelo || '';
          const categoria = classificarPintura(modelo);
          
          modelosDistintos.add(modelo);
          
          allPinturaItems.push({
            os: os.sequencial_ordem,
            data: os.data_cadastro,
            mes: os.data_cadastro ? os.data_cadastro.substring(0, 7) : '',
            item: it.item,
            modelo,
            variacao: it.variacao || '',
            categoria,
            largura,
            altura,
            m2,
            quantidade: it.quantidade || 1,
            valor_unitario: parseFloat(it.valor_unitario) || 0,
            sub_total: parseFloat(it.sub_total) || 0,
            valor_final: parseFloat(it.valor_final) || 0,
          });
        }
      }
    }
  }

  // Mostrar modelos distintos para validação
  console.log('=== MODELOS DISTINTOS DE PINTURA ===');
  [...modelosDistintos].sort().forEach(m => {
    const cat = classificarPintura(m);
    console.log(`  [${cat}] ${m || '(vazio)'}`);
  });
  
  console.log(`\nTotal itens de pintura: ${allPinturaItems.length}`);
  
  // Agrupar por categoria e calcular preço por m²
  const categorias = {};
  for (const item of allPinturaItems) {
    if (!categorias[item.categoria]) {
      categorias[item.categoria] = { items: [], totalValor: 0, totalM2: 0, count: 0 };
    }
    categorias[item.categoria].items.push(item);
    categorias[item.categoria].totalValor += item.sub_total;
    categorias[item.categoria].totalM2 += item.m2 * item.quantidade;
    categorias[item.categoria].count++;
  }
  
  console.log('\n=== PREÇO POR M² POR CATEGORIA ===');
  console.log('');
  
  const resultado = [];
  for (const [cat, data] of Object.entries(categorias).sort()) {
    const precoM2 = data.totalM2 > 0 ? data.totalValor / data.totalM2 : 0;
    console.log(`${cat}:`);
    console.log(`  Qtd registros: ${data.count}`);
    console.log(`  Total faturado: R$ ${data.totalValor.toFixed(2)}`);
    console.log(`  Total m²: ${data.totalM2.toFixed(3)}`);
    console.log(`  Preço médio/m²: R$ ${precoM2.toFixed(2)}`);
    console.log('');
    
    resultado.push({
      categoria: cat,
      qtd_registros: data.count,
      total_faturado: data.totalValor,
      total_m2: data.totalM2,
      preco_medio_m2: precoM2,
    });
    
    // Evolução mensal
    const porMes = {};
    for (const it of data.items) {
      if (!porMes[it.mes]) porMes[it.mes] = { valor: 0, m2: 0, count: 0 };
      porMes[it.mes].valor += it.sub_total;
      porMes[it.mes].m2 += it.m2 * it.quantidade;
      porMes[it.mes].count++;
    }
    console.log(`  Evolução mensal:`);
    for (const [mes, md] of Object.entries(porMes).sort()) {
      const pm2 = md.m2 > 0 ? md.valor / md.m2 : 0;
      console.log(`    ${mes}: ${md.count} itens | R$ ${md.valor.toFixed(2)} | ${md.m2.toFixed(3)} m² | R$ ${pm2.toFixed(2)}/m²`);
    }
    console.log('');
  }
  
  // Salvar dados completos
  fs.writeFileSync('/home/ubuntu/retrabalho-system/scripts/pintura-classificada.json', JSON.stringify({
    resumo: resultado,
    items: allPinturaItems,
  }, null, 2));
  
  console.log('Dados salvos em scripts/pintura-classificada.json');
}

main().catch(console.error);
