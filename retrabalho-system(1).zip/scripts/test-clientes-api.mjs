import https from "https";

const publicKey = process.env.MUBISYS_PUBLIC_KEY;
const accessToken = process.env.MUBISYS_ACCESS_TOKEN;

function fetchMubisys(path) {
  return new Promise((resolve) => {
    const url = `https://api.mubisys.com/api/${publicKey}${path}`;
    const req = https.get(url, { headers: { "Access-Token": accessToken, Accept: "application/json" } }, (res) => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(body) }); }
        catch { resolve({ status: res.statusCode, data: {} }); }
      });
    });
    req.on("error", () => resolve({ status: 0, data: {} }));
    req.setTimeout(15000, () => { req.destroy(); resolve({ status: 0, data: { error: "timeout" } }); });
  });
}

// Buscar lista de clientes/empresas
console.log("Buscando endpoint de clientes...");
const r1 = await fetchMubisys("/cliente?limit=3");
console.log("Status:", r1.status);
console.log("Campos disponíveis:", Object.keys(r1.data).join(", "));
if (Array.isArray(r1.data)) {
  console.log("Primeiro cliente:", JSON.stringify(r1.data[0], null, 2));
} else if (r1.data.data && Array.isArray(r1.data.data)) {
  console.log("Primeiro cliente:", JSON.stringify(r1.data.data[0], null, 2));
} else {
  console.log("Resposta:", JSON.stringify(r1.data, null, 2).slice(0, 500));
}

// Testar busca por nome
const r2 = await fetchMubisys("/cliente?search=grafica&limit=2");
console.log("\nBusca por 'grafica':", JSON.stringify(r2.data, null, 2).slice(0, 800));
