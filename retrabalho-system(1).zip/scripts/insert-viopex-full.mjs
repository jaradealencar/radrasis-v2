import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';
import { createRequire } from 'module';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// 1. Adicionar colunas endereco e responsavel se não existirem
const [cols] = await conn.execute('DESCRIBE transportadora_cidades');
const colNames = cols.map(c => c.Field);

if (!colNames.includes('endereco')) {
  await conn.execute('ALTER TABLE transportadora_cidades ADD COLUMN endereco VARCHAR(512) DEFAULT NULL AFTER telefone');
  console.log('✅ Coluna endereco adicionada');
} else {
  console.log('ℹ️ Coluna endereco já existe');
}

if (!colNames.includes('responsavel')) {
  await conn.execute('ALTER TABLE transportadora_cidades ADD COLUMN responsavel VARCHAR(128) DEFAULT NULL AFTER endereco');
  console.log('✅ Coluna responsavel adicionada');
} else {
  console.log('ℹ️ Coluna responsavel já existe');
}

if (!colNames.includes('sede')) {
  await conn.execute('ALTER TABLE transportadora_cidades ADD COLUMN sede VARCHAR(128) DEFAULT NULL AFTER responsavel');
  console.log('✅ Coluna sede adicionada');
} else {
  console.log('ℹ️ Coluna sede já existe');
}

// 2. Buscar ID da VIOPEX
const [viopexRows] = await conn.execute("SELECT id, nome FROM transportadoras WHERE nome LIKE '%Viopex%' OR nome LIKE '%VIOPEX%'");
console.log('VIOPEX encontrada:', viopexRows);
const viopexId = viopexRows[0]?.id;
if (!viopexId) {
  console.error('❌ VIOPEX não encontrada no banco!');
  await conn.end();
  process.exit(1);
}

// 3. Ler a planilha VIOPEX via HTML parsing
// Usar Python para extrair e salvar como JSON
import { execSync } from 'child_process';

const pythonScript = `
import json
from bs4 import BeautifulSoup

with open('/home/ubuntu/upload/VIOPEX_Cidades_atendidas(3).xls', 'rb') as f:
    content = f.read()

for enc in ['latin-1', 'cp1252', 'utf-8']:
    try:
        text = content.decode(enc)
        break
    except:
        continue

soup = BeautifulSoup(text, 'html.parser')
tables = soup.find_all('table')
table = tables[2]
rows = table.find_all('tr')

data = []
for row in rows[1:]:  # skip header
    cells = [td.get_text(strip=True) for td in row.find_all(['td','th'])]
    if len(cells) >= 7 and cells[1]:
        data.append({
            'cidade': cells[1].strip(),
            'estado': cells[2].strip() if len(cells) > 2 else '',
            'sede': cells[3].strip() if len(cells) > 3 else '',
            'endereco': cells[4].strip() if len(cells) > 4 else '',
            'responsavel': cells[5].strip() if len(cells) > 5 else '',
            'telefone': cells[6].strip() if len(cells) > 6 else '',
            'observacao': cells[8].strip() if len(cells) > 8 else '',
        })

print(json.dumps(data, ensure_ascii=False))
`;

const jsonOutput = execSync(`python3 -c "${pythonScript.replace(/"/g, '\\"').replace(/\n/g, '\\n')}"`, {
  encoding: 'utf-8',
  maxBuffer: 10 * 1024 * 1024
});

// Alternatively use a temp file approach
execSync(`python3 /tmp/extract_viopex.py`);
const jsonData = readFileSync('/tmp/viopex_data.json', 'utf-8');
const cidades = JSON.parse(jsonData);
console.log(`Total de cidades a inserir: ${cidades.length}`);

// 4. Verificar existentes
const [existing] = await conn.execute(
  'SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?',
  [viopexId]
);
const existingSet = new Set(existing.map(r => `${r.cidade.toLowerCase()}|${r.estado.toLowerCase()}`));

let inserted = 0;
let skipped = 0;
for (const c of cidades) {
  const key = `${c.cidade.toLowerCase()}|${c.estado.toLowerCase()}`;
  if (existingSet.has(key)) {
    skipped++;
    continue;
  }
  // Normalizar estado (pode ter sufixo como "ARAGUAÍNA - TO")
  let estado = c.estado.trim();
  if (estado.length > 2) {
    // Extrair UF do final
    const match = estado.match(/\b([A-Z]{2})$/);
    if (match) estado = match[1];
    else estado = estado.slice(0, 2);
  }
  await conn.execute(
    `INSERT INTO transportadora_cidades 
     (transportadoraId, cidade, estado, telefone, endereco, responsavel, sede, observacao, createdAt) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
    [viopexId, c.cidade, estado, c.telefone || null, c.endereco || null, c.responsavel || null, c.sede || null, c.observacao || null]
  );
  inserted++;
}

console.log(`✅ VIOPEX: ${inserted} cidades inseridas, ${skipped} já existiam`);
await conn.end();
