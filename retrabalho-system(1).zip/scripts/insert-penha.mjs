import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';
import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

dotenv.config();

const localidades = JSON.parse(readFileSync('/tmp/penha_localidades.json', 'utf-8'));
const TRANSPORTADORA_ID = 30002; // Penha

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  console.log(`Total de localidades a inserir: ${localidades.length}`);
  
  let cidadesInseridas = 0;
  let cidadesExistentes = 0;
  let filiaisInseridas = 0;
  let erros = 0;
  
  const agora = Date.now();
  
  for (const loc of localidades) {
    const { cidade, endereco, estado } = loc;
    
    // Normalizar cidade para Title Case
    const cidadeNorm = cidade
      .split(' ')
      .map(w => {
        const lower = w.toLowerCase();
        // Preposições e artigos em minúsculo
        if (['de','da','do','das','dos','e','a','o','as','os','em','no','na','nos','nas'].includes(lower) && w !== cidade.split(' ')[0]) {
          return lower;
        }
        return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
      })
      .join(' ');
    
    try {
      // Inserir cidade (ignorar duplicata por constraint UNIQUE)
      const [result] = await conn.execute(
        `INSERT IGNORE INTO transportadora_cidades (transportadoraId, cidade, estado, createdAt)
         VALUES (?, ?, ?, ?)`,
        [TRANSPORTADORA_ID, cidadeNorm, estado, agora]
      );
      
      if (result.affectedRows > 0) {
        cidadesInseridas++;
      } else {
        cidadesExistentes++;
      }
      
      // Inserir filial com endereço
      const nomeFilial = `${cidadeNorm} - ${estado}`;
      const [fResult] = await conn.execute(
        `INSERT INTO transportadora_filiais (transportadoraId, nome, cidade, estado, endereco, createdAt)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [TRANSPORTADORA_ID, nomeFilial, cidadeNorm, estado, endereco || null, agora]
      );
      
      if (fResult.affectedRows > 0) {
        filiaisInseridas++;
      }
      
    } catch (err) {
      // Se filial já existe com mesmo nome, tentar com sufixo
      if (err.code === 'ER_DUP_ENTRY' && err.message.includes('filial')) {
        try {
          const nomeFilialAlt = `${cidade} - ${estado} (${endereco?.substring(0, 20) || '2'})`;
          await conn.execute(
            `INSERT INTO transportadora_filiais (transportadoraId, nome, cidade, estado, endereco, createdAt)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [TRANSPORTADORA_ID, nomeFilialAlt, cidade, estado, endereco || null, agora]
          );
          filiaisInseridas++;
        } catch (e2) {
          // Filial já existe, ignorar
        }
      } else if (err.code !== 'ER_DUP_ENTRY') {
        console.error(`Erro em ${cidade} - ${estado}:`, err.message);
        erros++;
      }
    }
  }
  
  // Atualizar data de atualização de cidades
  await conn.execute(
    `UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = ?`,
    [agora, TRANSPORTADORA_ID]
  );
  
  console.log(`\n=== Resultado ===`);
  console.log(`Cidades inseridas: ${cidadesInseridas}`);
  console.log(`Cidades já existentes: ${cidadesExistentes}`);
  console.log(`Filiais inseridas: ${filiaisInseridas}`);
  console.log(`Erros: ${erros}`);
  
  // Verificar total
  const [[{ total: totalCidades }]] = await conn.execute(
    `SELECT COUNT(*) as total FROM transportadora_cidades WHERE transportadoraId = ?`,
    [TRANSPORTADORA_ID]
  );
  const [[{ total: totalFiliais }]] = await conn.execute(
    `SELECT COUNT(*) as total FROM transportadora_filiais WHERE transportadoraId = ?`,
    [TRANSPORTADORA_ID]
  );
  
  console.log(`\nTotal cidades Penha no banco: ${totalCidades}`);
  console.log(`Total filiais Penha no banco: ${totalFiliais}`);
  
  await conn.end();
}

main().catch(console.error);
