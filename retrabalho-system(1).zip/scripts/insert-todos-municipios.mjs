import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// IDs das transportadoras
const TRANSPORTADORAS = [
  { id: 5, nome: 'Braspress' },
  { id: 6, nome: 'Carvalima' },
];

// Carregar municípios do IBGE
const raw = JSON.parse(readFileSync('/tmp/municipios_ibge.json', 'utf-8'));

// Extrair nome e UF de cada município (tratar microrregiao nula)
const municipios = raw.map(m => {
  let estado = null;
  if (m.microrregiao?.mesorregiao?.UF?.sigla) {
    estado = m.microrregiao.mesorregiao.UF.sigla;
  } else if (m['regiao-imediata']?.['regiao-intermediaria']?.UF?.sigla) {
    estado = m['regiao-imediata']['regiao-intermediaria'].UF.sigla;
  }
  return { cidade: m.nome, estado };
}).filter(m => m.estado !== null);

console.log(`Total de municípios IBGE: ${municipios.length}`);

for (const transp of TRANSPORTADORAS) {
  console.log(`\n=== ${transp.nome} (id=${transp.id}) ===`);

  // Cidades já existentes
  const [existing] = await conn.execute(
    'SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?',
    [transp.id]
  );
  const existingSet = new Set(existing.map(r => `${r.cidade.toUpperCase()}|${r.estado.toUpperCase()}`));
  console.log(`Cidades já cadastradas: ${existingSet.size}`);

  // Filtrar apenas os que ainda não existem
  const toInsert = municipios.filter(m => {
    const key = `${m.cidade.toUpperCase()}|${m.estado.toUpperCase()}`;
    return !existingSet.has(key);
  });

  console.log(`A inserir: ${toInsert.length}`);

  if (toInsert.length === 0) {
    console.log('Nada a inserir.');
    continue;
  }

  // Inserir em lotes de 500
  const BATCH = 500;
  let inserted = 0;

  for (let i = 0; i < toInsert.length; i += BATCH) {
    const batch = toInsert.slice(i, i + BATCH);
    const placeholders = batch.map(() => '(?, ?, ?, NOW())').join(', ');
    const values = batch.flatMap(m => [transp.id, m.cidade, m.estado]);
    await conn.execute(
      `INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, createdAt) VALUES ${placeholders}`,
      values
    );
    inserted += batch.length;
    process.stdout.write(`\r  Inseridas: ${inserted}/${toInsert.length}`);
  }

  const [total] = await conn.execute(
    'SELECT COUNT(*) as total FROM transportadora_cidades WHERE transportadoraId = ?',
    [transp.id]
  );
  console.log(`\n✅ ${transp.nome}: ${inserted} inseridas | Total agora: ${total[0].total}`);
}

await conn.end();
console.log('\nConcluído!');
