#!/usr/bin/env python3
"""
Script para aumentar 5% nas Faixas 3, 4 e 5 de PINTURA
Estrutura correta: 8 linhas (faixas por m²) x 4 colunas (tipos de cor)
"""

import mysql.connector
import json
from datetime import datetime

# Configurações do banco de dados
DB_CONFIG = {
    'host': 'gateway05.us-east-1.prod.aws.tidbcloud.com',
    'port': 4000,
    'user': 'w9E6B1CFVfikCKB.cee5432df873',
    'password': 'WR6W2CnU8s1KSjQ2hWm0',
    'database': 'PzdanzaCSk4JPsdTBVnd3F',
    'ssl_disabled': False,
    'ssl_verify_cert': False,
    'ssl_verify_identity': False,
}

def connect_db():
    """Conecta ao banco de dados"""
    return mysql.connector.connect(**DB_CONFIG)

def increase_value(value_str):
    """Aumenta um valor em 5%"""
    if not value_str or value_str == 'NÃO DISPONÍVEL' or value_str == 'Consultar':
        return value_str
    
    if '%' in str(value_str):
        # Extrai o número
        num = float(value_str.replace('%', '').replace(',', '.'))
        # Aumenta 5%
        new_num = num * 1.05
        # Formata de volta
        return f"{new_num:.1f}%".replace('.', ',')
    
    return value_str

def process_pintura():
    """Processa apenas os registros de pintura"""
    print("\nProcessando Pintura...")
    
    # IDs de pintura a PROCESSAR
    pintura_ids = [18, 19, 20, 21]
    
    conn = connect_db()
    cursor = conn.cursor()
    
    # Busca apenas registros de pintura
    cursor.execute(f"SELECT id, contentJson FROM price_table_sections WHERE id IN ({','.join(map(str, pintura_ids))})")
    records = cursor.fetchall()
    
    updated_count = 0
    
    for record_id, json_str in records:
        try:
            data = json.loads(json_str)
            
            # Verifica se tem estrutura de rows
            if 'rows' not in data or len(data['rows']) == 0:
                continue
            
            modified = False
            
            # Processa cada linha (Faixa)
            for row_idx, row in enumerate(data['rows']):
                if 'values' not in row:
                    continue
                
                values = row['values']
                
                # Faixas 3, 4 e 5 estão nos índices 2, 3, 4 (linhas)
                # Todas as colunas (0, 1, 2, 3) devem ser aumentadas
                faixas_para_aumentar = [2, 3, 4]
                
                if row_idx in faixas_para_aumentar:
                    # Aumenta TODAS as colunas desta faixa
                    new_values = []
                    for col_idx, value in enumerate(values):
                        new_value = increase_value(value)
                        new_values.append(new_value)
                        if new_value != value:
                            modified = True
                    
                    row['values'] = new_values
            
            # Se houve modificação, atualiza o banco
            if modified:
                new_json = json.dumps(data, ensure_ascii=False)
                cursor.execute(
                    "UPDATE price_table_sections SET contentJson = %s, updatedAt = NOW() WHERE id = %s",
                    (new_json, record_id)
                )
                updated_count += 1
                print(f"  ✓ ID {record_id} atualizado (+5%)")
        
        except Exception as e:
            print(f"  ⚠ Erro ao processar ID {record_id}: {e}")
    
    conn.commit()
    cursor.close()
    conn.close()
    
    return updated_count

def main():
    """Função principal"""
    print("=" * 70)
    print("AUMENTO DE 5% NAS FAIXAS 3, 4 E 5")
    print("(Apenas Pintura - Todas as cores)")
    print("=" * 70)
    print(f"Timestamp: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    try:
        # Processa pintura
        count = process_pintura()
        
        print()
        print("=" * 70)
        print("RESUMO DAS ALTERAÇÕES")
        print("=" * 70)
        print(f"✓ Pintura: {count} registros atualizados")
        print(f"✓ Total: {count} registros atualizados")
        print()
        print("Faixas aumentadas: 3, 4 e 5 (+5%)")
        print("Faixas mantidas: 1, 2, 6, 7 e 8 (sem alteração)")
        print("Colunas: TODAS (1 cor, 2 cores, 3/4 cores, Cores Metalizadas)")
        print("IDs processados: 18, 19, 20, 21 (Pintura)")
        print("=" * 70)
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main())
