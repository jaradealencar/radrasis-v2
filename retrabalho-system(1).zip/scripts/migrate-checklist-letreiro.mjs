import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// 1. Criar tabela de checklist por modelo de letreiro
await conn.execute(`
  CREATE TABLE IF NOT EXISTS empacotamento_checklist_letreiro_itens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    modeloLetreitoId INT NOT NULL,
    ordem INT NOT NULL DEFAULT 0,
    descricao VARCHAR(512) NOT NULL,
    obrigatorio INT NOT NULL DEFAULT 1,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
`);

// 2. Criar tabela de respostas do checklist de letreiro por pedido
await conn.execute(`
  CREATE TABLE IF NOT EXISTS empacotamento_pedido_checklist_letreiro (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedidoId INT NOT NULL,
    itemId INT NOT NULL,
    marcado INT NOT NULL DEFAULT 0,
    marcadoPor VARCHAR(128),
    marcadoEm TIMESTAMP NULL
  )
`);

console.log("Tabelas criadas com sucesso.");

// 3. Buscar modelos de letreiro cadastrados
const [modelos] = await conn.execute("SELECT id, nome FROM empacotamento_modelos");
console.log("Modelos de letreiro:", modelos.map(m => `${m.id}: ${m.nome}`).join(", "));

// 4. Mapeamento de checklists por tipo (baseado no PDF)
const CHECKLISTS = {
  // PVC Expandido Cru
  "pvc.*cru|pvc expandido cru": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas do corte",
    "Verificar peças com problemas (arranhões, amassados, deformidades) — acionar supervisão se necessário",
    "Limpar sujeiras/manchas com pano úmido limpo",
    "Aplicar duas camadas de plástico-bolha no fundo da caixa",
    "Posicionar as letras conforme o projeto, aplicando camadas e colando as letras",
    "Verificar se as letras estão bem travadas (não devem se sobrepor no transporte)",
    "Fazer ticagem de cada letra colocada na caixa",
    "Verificar se todos os componentes estão dentro (gabarito, LEDs, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Galvanizado Comum pintado / Galvanizado Frontlight pintado / PVC Expandido pintados
  "galvanizado.*pintado|galvanizado.*frontlight|pvc.*pintado": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas de poeira",
    "Verificar peças com problemas (arranhões, amassados, deformidades no corte e na pintura) — acionar supervisão",
    "Limpar sujeiras/manchas com pano descartável úmido extremamente limpo",
    "Colocar acessório de proteção de polietileno nos fixadores pontiagudos",
    "Envolver cada letra com papel manteiga e fechar com fita crepe branca",
    "Dar 4 voltas de plástico-bolha em cada peça",
    "Fazer ticagem de cada letra embalada",
    "Posicionar as letras conforme o projeto",
    "Realizar travamento interno com papel picotado e papel amassado a cada camada",
    "Colocar letras face a face (não face vs fixador) se houver fixadores externos",
    "Verificar se todos os componentes estão dentro (gabarito, LEDs, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Estofamento de conclusão se necessário (papel picado para firmar peças)",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Frontlight semiacabado sem pintura
  "frontlight.*sem.*pintura|frontlight.*semiacabado": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas de poeira",
    "Verificar peças com problemas (arranhões, amassados, deformidades no corte/dobra, acrílico com ranhuras) — acionar supervisão",
    "Limpar sujeiras/manchas com pano descartável úmido limpo (acrílico e PVC)",
    "Aplicar uma camada de bolha no fundo da caixa (somente em caixas com reforços de madeira)",
    "Colocar na ordem: PVC → Acrílico",
    "Colocar a primeira camada de letras conforme o nesting, prender letras com fita kraft",
    "Fazer ticagem de cada letra embalada",
    "Colocar papéis amassados dentro de cada letra para evitar que PVC e acrílico saiam da estrutura",
    "Realizar travamento interno com papel picotado e papel amassado a cada camada",
    "Verificar se todos os componentes estão dentro (gabarito, LEDs, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Estofamento de conclusão se necessário",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Galvanizado Cru sem pintura
  "galvanizado.*cru|galvanizado cru": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas das peças",
    "Verificar peças com problemas — acionar supervisão se necessário",
    "Posicionar as letras conforme o projeto; aplicar plástico canela entre camadas se necessário",
    "Prender letras com fita kraft para evitar choque no transporte",
    "Fazer ticagem de cada letra colocada na caixa",
    "Verificar se todos os componentes estão dentro (gabarito, LEDs, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Latão e Inox Dourado
  "latão|inox dourado|laton": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas de poeira",
    "Verificar peças com problemas (arranhões, amassados, deformidades no verniz) — acionar supervisão",
    "Limpar sujeiras/manchas com pano descartável úmido extremamente limpo",
    "Envolver cada letra com papel manteiga e fechar com fita crepe branca",
    "Colocar acessório de proteção de polietileno nos fixadores pontiagudos",
    "Dar 4 voltas de plástico-bolha em cada peça",
    "Fazer ticagem de cada letra embalada",
    "Posicionar as letras conforme o projeto",
    "Realizar travamento interno com papel picotado e papel amassado a cada camada",
    "Colocar letras face a face (não face vs fixador) se houver fixadores externos",
    "Verificar se todos os componentes estão dentro (gabarito, LEDs, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Estofamento de conclusão se necessário",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // PVC Expandido Colorido
  "pvc.*colorido": [
    "ATENÇÃO: Não carregar ou colocar uma peça sobre a outra sem que já esteja com o filme stretch aplicado",
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas do corte",
    "Verificar peças com problemas (arranhões, amassados, deformidades no corte) — acionar supervisão",
    "Limpar sujeiras/manchas com pano úmido extremamente limpo",
    "Aplicar duas camadas de filme stretch para envolver cada letra",
    "Envolver cada letra com 3 camadas de plástico-bolha",
    "Colocar duas camadas de plástico bolha no fundo da caixa",
    "Posicionar as letras conforme o projeto",
    "Fazer ticagem de cada letra colocada na caixa",
    "Verificar se todos os componentes estão dentro (gabarito, LEDs, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Frontflat
  "frontflat|front flat": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas de poeira",
    "Verificar peças com problemas (arranhões, amassados, manchas) — acionar supervisão",
    "Limpar sujeiras/manchas com pano descartável úmido com a solução",
    "Remover line/filme do acrílico somente se houver indícios de arranhões ou danos",
    "Dar 4 voltas de plástico-bolha em cada peça",
    "Fazer ticagem de cada letra embalada",
    "Posicionar as letras conforme o projeto",
    "Realizar travamento interno com papel picotado e papel amassado a cada camada",
    "Verificar se todos os componentes estão dentro (gabarito, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Estofamento de conclusão se necessário",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Letra montada de acrílico
  "acrílico montado|acrilico montado|letra.*acrílico|letra.*acrilico": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas de poeira; remover filmes stretch se houver",
    "Verificar peças com problemas (arranhões, amassados, manchas) — acionar supervisão",
    "Limpar sujeiras/manchas com pano descartável úmido com solução ou vinagre de álcool",
    "Remover line/filme do acrílico somente se houver arranhões, danos ou escorrimento de cola",
    "Dar 4 voltas de plástico-bolha em cada peça",
    "Fazer ticagem de cada letra embalada",
    "Posicionar as letras conforme o projeto",
    "Realizar travamento interno com papel picotado e papel amassado a cada camada",
    "Verificar se todos os componentes estão dentro (gabarito, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Estofamento de conclusão se necessário",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Frontlight de inox/PVC com face em inox
  "frontlight.*inox|inox.*frontlight": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar; inspecionar superficialmente inconsistências (já vêm com pré-embalagem do setor de solda)",
    "Verificar peças com problemas (amassados, fixadores soltos, solda se desprendendo) — acionar supervisão",
    "Aplicar duas camadas de plástico bolha entre as camadas das letras",
    "Fazer ticagem de cada letra embalada",
    "Posicionar as letras conforme o projeto",
    "Realizar travamento interno com papel picotado e papel amassado a cada camada",
    "Verificar se todos os componentes estão dentro (gabarito, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Estofamento de conclusão se necessário",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Letra em inox tradicional
  "inox tradicional|inox.*tradicional|letra.*inox": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar; inspecionar superficialmente inconsistências (já vêm com pré-embalagem do setor de solda)",
    "Verificar peças com problemas (amassados, fixadores soltos, solda se desprendendo) — acionar supervisão",
    "Aplicar duas camadas de plástico bolha entre as camadas das letras",
    "Fazer ticagem de cada letra embalada",
    "Posicionar as letras conforme o projeto",
    "Realizar travamento interno com papel picotado e papel amassado a cada camada",
    "Verificar se todos os componentes estão dentro (gabarito, fonte)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Estofamento de conclusão se necessário",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
  // Letras em acrílico cortado e ACM cortado
  "acrílico cortado|acrilico cortado|acm cortado": [
    "Posicionar todas as peças e tirar foto para registro",
    "Passar pistola de ar para retirar impurezas do corte",
    "Verificar peças com problemas (arranhões, amassados, deformidades no corte) — acionar supervisão",
    "Limpar sujeiras/manchas com pano úmido com solução extremamente limpa",
    "Envolver cada letra com 3 camadas de plástico-bolha",
    "Colocar duas camadas de plástico bolha no fundo da caixa",
    "Posicionar as letras conforme o projeto",
    "Fazer ticagem de cada letra colocada na caixa",
    "Verificar se todos os componentes estão dentro (gabarito)",
    "Bater foto dos acessórios dentro da caixa antes de fechar",
    "Sinalizar a caixa com o número da OS",
    "Aplicar cantoneiras conforme especificação do projeto",
    "Pesagem e medição — enviar para setor responsável",
    "Colar etiqueta após emissão de NF",
  ],
};

// 5. Popular checklist para cada modelo cadastrado
let totalInseridos = 0;
for (const modelo of modelos) {
  const nomeNorm = modelo.nome.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  
  for (const [pattern, itens] of Object.entries(CHECKLISTS)) {
    const regex = new RegExp(pattern.replace(/\|/g, "|"), "i");
    const nomeTest = modelo.nome.toLowerCase();
    
    if (regex.test(nomeTest)) {
      console.log(`Populando checklist para: ${modelo.nome} (padrão: ${pattern})`);
      
      // Verificar se já tem itens
      const [existing] = await conn.execute(
        "SELECT COUNT(*) as cnt FROM empacotamento_checklist_letreiro_itens WHERE modeloLetreitoId = ?",
        [modelo.id]
      );
      
      if (existing[0].cnt > 0) {
        console.log(`  -> Já tem ${existing[0].cnt} itens, pulando.`);
        continue;
      }
      
      for (let i = 0; i < itens.length; i++) {
        await conn.execute(
          "INSERT INTO empacotamento_checklist_letreiro_itens (modeloLetreitoId, ordem, descricao, obrigatorio) VALUES (?, ?, ?, 1)",
          [modelo.id, i + 1, itens[i]]
        );
        totalInseridos++;
      }
      console.log(`  -> ${itens.length} itens inseridos.`);
      break;
    }
  }
}

console.log(`\nTotal de itens inseridos: ${totalInseridos}`);
await conn.end();
