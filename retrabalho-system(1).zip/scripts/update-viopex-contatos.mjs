import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const viopexId = 30;

// Ler dados extraídos pelo Python
const jsonData = readFileSync('/tmp/viopex_data.json', 'utf-8');
const cidades = JSON.parse(jsonData);
console.log(`Total de cidades na planilha: ${cidades.length}`);

// Buscar todas as cidades existentes da VIOPEX
const [existing] = await conn.execute(
  'SELECT id, cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?',
  [viopexId]
);
console.log(`Cidades existentes no banco: ${existing.length}`);

// Criar mapa de cidade+estado → id
const existingMap = new Map();
for (const row of existing) {
  const key = `${row.cidade.toLowerCase().trim()}|${row.estado.toLowerCase().trim()}`;
  existingMap.set(key, row.id);
}

let updated = 0;
let notFound = 0;

for (const c of cidades) {
  const key = `${c.cidade.toLowerCase().trim()}|${c.estado.toLowerCase().trim()}`;
  const existingId = existingMap.get(key);
  
  if (!existingId) {
    notFound++;
    continue;
  }
  
  // Atualizar com dados de contato
  await conn.execute(
    `UPDATE transportadora_cidades 
     SET telefone = ?, observacao = ?, endereco = ?, responsavel = ?, sede = ?
     WHERE id = ?`,
    [
      c.telefone || null,
      c.observacao || null,
      c.endereco || null,
      c.responsavel || null,
      c.sede || null,
      existingId
    ]
  );
  updated++;
}

console.log(`✅ VIOPEX: ${updated} cidades atualizadas com dados de contato, ${notFound} não encontradas`);

// Verificar resultado
const [sample] = await conn.execute(
  'SELECT cidade, estado, sede, endereco, responsavel, telefone FROM transportadora_cidades WHERE transportadoraId = ? AND endereco IS NOT NULL LIMIT 3',
  [viopexId]
);
console.log('Amostra com dados:', JSON.stringify(sample, null, 2));

await conn.end();
