#!/usr/bin/env python3
"""
Script para aumentar 8% APENAS nas Faixas 3, 4 e 5
em TODAS as tabelas de preço EXCETO Pintura

Estrutura correta:
- Cada tabela tem 1 linha "Margem" com 7 valores (faixas)
- Faixas 3, 4, 5 estão nos índices 2, 3, 4 dos valores
"""

import mysql.connector
import json
from datetime import datetime

# Configurações do banco de dados
DB_CONFIG = {
    'host': 'gateway05.us-east-1.prod.aws.tidbcloud.com',
    'port': 4000,
    'user': 'w9E6B1CFVfikCKB.cee5432df873',
    'password': 'WR6W2CnU8s1KSjQ2hWm0',
    'database': 'PzdanzaCSk4JPsdTBVnd3F',
    'ssl_disabled': False,
    'ssl_verify_cert': False,
    'ssl_verify_identity': False,
}

def connect_db():
    """Conecta ao banco de dados"""
    return mysql.connector.connect(**DB_CONFIG)

def increase_value(value_str):
    """Aumenta um valor em 8%"""
    if not value_str or value_str == 'NÃO DISPONÍVEL' or value_str == 'Consultar':
        return value_str
    
    if '%' in str(value_str):
        # Extrai o número
        num = float(value_str.replace('%', '').replace(',', '.'))
        # Aumenta 8%
        new_num = num * 1.08
        # Formata de volta
        return f"{new_num:.1f}%".replace('.', ',')
    
    elif 'R$' in str(value_str):
        # Extrai o número
        num = float(value_str.replace('R$', '').replace(',', '.').strip())
        # Aumenta 8%
        new_num = num * 1.08
        # Formata de volta
        return f"R${new_num:.2f}".replace('.', ',')
    
    return value_str

def process_price_table():
    """Processa a tabela de preços"""
    print("\nProcessando price_table_sections...")
    
    # IDs de pintura a EXCLUIR
    pintura_ids = [18, 19, 20, 21]
    
    conn = connect_db()
    cursor = conn.cursor()
    
    # Busca todos os registros
    cursor.execute("SELECT id, contentJson FROM price_table_sections")
    records = cursor.fetchall()
    
    updated_count = 0
    
    for record_id, json_str in records:
        # Pula registros de pintura
        if record_id in pintura_ids:
            continue
        
        try:
            data = json.loads(json_str)
            
            # Verifica se tem estrutura de rows (margin_table ou margin_table_multi)
            if 'rows' not in data or len(data['rows']) == 0:
                continue
            
            modified = False
            
            # Processa cada linha (geralmente há 1 linha "Margem")
            for row_idx, row in enumerate(data['rows']):
                if 'values' not in row:
                    continue
                
                values = row['values']
                
                # Faixas 3, 4 e 5 estão nos índices 2, 3, 4
                faixas_para_aumentar = [2, 3, 4]
                
                new_values = []
                for col_idx, value in enumerate(values):
                    if col_idx in faixas_para_aumentar:
                        new_value = increase_value(value)
                        new_values.append(new_value)
                        if new_value != value:
                            modified = True
                    else:
                        new_values.append(value)
                
                row['values'] = new_values
            
            # Se houve modificação, atualiza o banco
            if modified:
                new_json = json.dumps(data, ensure_ascii=False)
                cursor.execute(
                    "UPDATE price_table_sections SET contentJson = %s, updatedAt = NOW() WHERE id = %s",
                    (new_json, record_id)
                )
                updated_count += 1
                print(f"  ✓ ID {record_id} atualizado")
        
        except Exception as e:
            print(f"  ⚠ Erro ao processar ID {record_id}: {e}")
    
    conn.commit()
    cursor.close()
    conn.close()
    
    return updated_count

def main():
    """Função principal"""
    print("=" * 70)
    print("AUMENTO DE 8% NAS FAIXAS 3, 4 E 5")
    print("(Excluindo Pintura)")
    print("=" * 70)
    print(f"Timestamp: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    try:
        # Processa price_table_sections
        count = process_price_table()
        
        print()
        print("=" * 70)
        print("RESUMO DAS ALTERAÇÕES")
        print("=" * 70)
        print(f"✓ price_table_sections: {count} registros atualizados")
        print(f"✓ Total: {count} registros atualizados")
        print()
        print("Faixas aumentadas: 3, 4 e 5 (+8%)")
        print("Faixas mantidas: 1, 2, 6 e 7 (sem alteração)")
        print("Pintura: EXCLUÍDA (sem alteração)")
        print("=" * 70)
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main())
