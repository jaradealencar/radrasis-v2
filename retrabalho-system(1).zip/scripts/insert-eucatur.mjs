import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// ID da Eucatur no banco
const EUCATUR_ID = 9;

// Verificar se a Eucatur existe
const [rows] = await conn.execute('SELECT id, nome FROM transportadoras WHERE id = ?', [EUCATUR_ID]);
if (rows.length === 0) {
  console.error('❌ Eucatur não encontrada no banco (id=9)');
  process.exit(1);
}
console.log(`✅ Transportadora: ${rows[0].nome} (id=${rows[0].id})`);

// Verificar cidades existentes da Eucatur
const [existing] = await conn.execute(
  'SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?',
  [EUCATUR_ID]
);
const existingSet = new Set(existing.map(r => `${r.cidade.toUpperCase()}|${r.estado.toUpperCase()}`));
console.log(`Cidades já cadastradas: ${existingSet.size}`);

// Carregar dados extraídos
const data = JSON.parse(readFileSync('/tmp/eucatur_data.json', 'utf-8'));
console.log(`Cidades a inserir: ${data.length}`);

// Inserir cidades novas
let inserted = 0;
let skipped = 0;

for (const city of data) {
  const key = `${city.cidade.toUpperCase()}|${city.estado.toUpperCase()}`;
  if (existingSet.has(key)) {
    skipped++;
    continue;
  }
  
  await conn.execute(
    `INSERT INTO transportadora_cidades 
     (transportadoraId, cidade, estado, observacao, createdAt)
     VALUES (?, ?, ?, ?, NOW())`,
    [
      EUCATUR_ID,
      city.cidade,
      city.estado,
      city.observacao || null,
    ]
  );
  inserted++;
}

console.log(`\n✅ Eucatur: ${inserted} cidades inseridas, ${skipped} já existiam`);

// Distribuição por estado
const [dist] = await conn.execute(
  `SELECT estado, COUNT(*) as total 
   FROM transportadora_cidades 
   WHERE transportadoraId = ? 
   GROUP BY estado 
   ORDER BY estado`,
  [EUCATUR_ID]
);
console.log('\nDistribuição por estado:');
dist.forEach(r => console.log(`  ${r.estado}: ${r.total}`));

const [total] = await conn.execute(
  'SELECT COUNT(*) as total FROM transportadora_cidades WHERE transportadoraId = ?',
  [EUCATUR_ID]
);
console.log(`\nTotal de cidades da Eucatur no banco: ${total[0].total}`);

await conn.end();
