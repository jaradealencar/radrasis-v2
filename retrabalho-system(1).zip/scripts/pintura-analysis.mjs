import https from 'https';

const publicKey = process.env.MUBISYS_PUBLIC_KEY;
const accessToken = process.env.MUBISYS_ACCESS_TOKEN;

function fetchPage(start, end, page) {
  return new Promise((resolve) => {
    const path = `/ordem-servico?status=TODOS&filtrodata=CADASTRO&datainicial=${start}&datafinal=${end}&page=${page}&per_page=500`;
    const url = `https://api.mubisys.com/api/${publicKey}${path}`;
    const req = https.get(url, { headers: { 'Access-Token': accessToken, 'Accept': 'application/json' } }, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => { try { resolve(JSON.parse(body)); } catch { resolve({}); } });
    });
    req.on('error', () => resolve({}));
    req.setTimeout(30000, () => { req.destroy(); resolve({}); });
  });
}

async function fetchAllOsForPeriod(start, end) {
  let all = [];
  let page = 1;
  while (true) {
    const d = await fetchPage(start, end, page);
    const items = (d.data || []);
    if (items.length === 0) break;
    all = all.concat(items);
    const pagination = d.pagination;
    if (!pagination || page >= (pagination.last_page || 1)) break;
    page++;
  }
  return all;
}

async function main() {
  // Step 1: Discover all pintura item names and variations
  const periods = [
    ['2026-01-01', '2026-01-31'],
    ['2026-02-01', '2026-02-28'],
    ['2026-03-01', '2026-03-31'],
    ['2026-04-01', '2026-04-30'],
    ['2026-05-01', '2026-05-31'],
    ['2026-06-01', '2026-06-04'],
  ];

  const pinturaVariations = new Set();
  const pinturaItems = [];

  for (const [start, end] of periods) {
    console.error(`Fetching ${start} to ${end}...`);
    const osList = await fetchAllOsForPeriod(start, end);
    console.error(`  Got ${osList.length} OS`);
    
    for (const os of osList) {
      for (const it of (os.itens || [])) {
        const name = (it.item || '').toLowerCase();
        if (name.includes('pintura')) {
          const key = `${it.item} | ${it.variacao || '(sem variação)'}`;
          pinturaVariations.add(key);
          
          const largura = parseFloat(it.largura) || 0;
          const altura = parseFloat(it.altura) || 0;
          const m2 = largura * altura;
          
          pinturaItems.push({
            os: os.sequencial_ordem,
            data: os.data_cadastro,
            item: it.item,
            variacao: it.variacao || '',
            largura,
            altura,
            m2,
            quantidade: it.quantidade || 1,
            valor_unitario: parseFloat(it.valor_unitario) || 0,
            sub_total: parseFloat(it.sub_total) || 0,
            valor_final: parseFloat(it.valor_final) || 0,
          });
        }
      }
    }
  }

  console.log('=== VARIAÇÕES DISTINTAS DE PINTURA ===');
  [...pinturaVariations].sort().forEach(v => console.log(v));
  console.log(`\nTotal variações distintas: ${pinturaVariations.size}`);
  console.log(`Total itens de pintura: ${pinturaItems.length}`);
  
  // Save raw data for analysis
  const fs = await import('fs');
  fs.writeFileSync('/home/ubuntu/retrabalho-system/scripts/pintura-raw.json', JSON.stringify(pinturaItems, null, 2));
  console.log('\nDados salvos em scripts/pintura-raw.json');
}

main().catch(console.error);
