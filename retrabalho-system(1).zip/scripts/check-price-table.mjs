import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
dotenv.config({ path: resolve(process.cwd(), ".env") });

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const [rows] = await conn.execute(
  "SELECT id, page, sectionTitle, LEFT(contentJson, 500) as contentPreview FROM price_table_sections ORDER BY page, sectionOrder LIMIT 10"
);
console.log("Seções encontradas:", rows.length);
for (const r of rows) {
  console.log(`\n--- ID: ${r.id} | Página: ${r.page} | Título: ${r.sectionTitle} ---`);
  console.log("Preview JSON:", r.contentPreview);
}
await conn.end();
