// Seed: popula dre_mensal com dados da planilha Fechamento-2026.03
import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Dados extraídos da planilha — meses: Dez/25=12, Jan/26=1, Fev/26=2, Mar/26=3
// Formato: [ano, mes, campos...]
const dados = [
  // Dez/2025
  {
    ano: 2025, mes: 12,
    receitaOperacionalBruta: 307965.42,
    receitaFinanceira: 2.27,
    receitaNaoOperacional: 165037.96,
    totalEntradas: 472082.21,
    impostosVendas: 0,
    despesaVariavel: 0,
    despesaOperacional: 0,
    materiaPrima: 68500.00,
    gastosGeraisFabricacao: 42715.08,
    despesasPessoal: 108189.83,
    despesasFixas: 190708.63,
    despesasFinanceiras: 923.44,
    despesasNaoOperacionais: 246408.69,
    totalSaidas: 545307.15,
    receitaBrutaOperacional: 307965.42,
    lucroBruto: 307965.42,
    lucroOperacional: 8145.79,
    lucroLiquido: -73224.94,
    valorPedidos: 299968.95,
    resultadoEfetivo: 62097.63,
    margemResultadoEfetivo: 0.2070,
    percMateriaPrima: 0.3509,
    percFixoRateado: 0.3152,
    percTributos: 0.0926,
    percComissaoInterna: 0.0262,
    percDescontos: 0.0077,
  },
  // Jan/2026
  {
    ano: 2026, mes: 1,
    receitaOperacionalBruta: 213315.44,
    receitaFinanceira: 13.56,
    receitaNaoOperacional: 21279.76,
    totalEntradas: 234575.70,
    impostosVendas: 389.54,
    despesaVariavel: 0,
    despesaOperacional: 0,
    materiaPrima: 47479.90,
    gastosGeraisFabricacao: 1150.00,
    despesasPessoal: 93876.78,
    despesasFixas: 100844.87,
    despesasFinanceiras: 33.07,
    despesasNaoOperacionais: 103205.48,
    totalSaidas: 298316.68,
    receitaBrutaOperacional: 212925.90,
    lucroBruto: 212925.90,
    lucroOperacional: 18184.74,
    lucroLiquido: -63740.98,
    valorPedidos: 202986.75,
    resultadoEfetivo: 47535.60,
    margemResultadoEfetivo: 0.2342,
    percMateriaPrima: 0.3381,
    percFixoRateado: 0.2971,
    percTributos: 0.0924,
    percComissaoInterna: 0.0269,
    percDescontos: 0.0099,
  },
  // Fev/2026
  {
    ano: 2026, mes: 2,
    receitaOperacionalBruta: 257808.64,
    receitaFinanceira: 9.83,
    receitaNaoOperacional: 19757.95,
    totalEntradas: 276297.90,
    impostosVendas: 7750.42,
    despesaVariavel: 0,
    despesaOperacional: 0,
    materiaPrima: 73679.78,
    gastosGeraisFabricacao: 5229.55,
    despesasPessoal: 100213.85,
    despesasFixas: 43822.58,
    despesasFinanceiras: 1278.52,
    despesasNaoOperacionais: 166475.78,
    totalSaidas: 318262.63,
    receitaBrutaOperacional: 250058.22,
    lucroBruto: 250058.22,
    lucroOperacional: 104753.10,
    lucroLiquido: -41964.73,
    valorPedidos: 363304.23,
    resultadoEfetivo: 100885.21,
    margemResultadoEfetivo: 0.2777,
    percMateriaPrima: 0.3086,
    percFixoRateado: 0.2862,
    percTributos: 0.0927,
    percComissaoInterna: 0.0270,
    percDescontos: 0.0060,
  },
  // Mar/2026
  {
    ano: 2026, mes: 3,
    receitaOperacionalBruta: 370430.39,
    receitaFinanceira: 401.93,
    receitaNaoOperacional: 88626.43,
    totalEntradas: 458393.19,
    impostosVendas: 24647.74,
    despesaVariavel: 29119.66,
    despesaOperacional: 917.54,
    materiaPrima: 93087.48,
    gastosGeraisFabricacao: 25455.76,
    despesasPessoal: 31872.11,
    despesasFixas: 120685.38,
    despesasFinanceiras: 1054.56,
    despesasNaoOperacionais: 191064.92,
    totalSaidas: 398296.35,
    receitaBrutaOperacional: 345782.65,
    lucroBruto: 315745.45,
    lucroOperacional: 162535.33,
    lucroLiquido: 60096.84,
    valorPedidos: 459335.87,
    resultadoEfetivo: 97989.99,
    margemResultadoEfetivo: 0.2133,
    percMateriaPrima: 0.3286,
    percFixoRateado: 0.3353,
    percTributos: 0.0928,
    percComissaoInterna: 0.0263,
    percDescontos: 0.0036,
  },
];

// Limpar dados existentes para esses meses
await conn.execute("DELETE FROM dre_mensal WHERE (ano = 2025 AND mes = 12) OR (ano = 2026 AND mes IN (1,2,3))");

for (const d of dados) {
  await conn.execute(
    `INSERT INTO dre_mensal (
      ano, mes,
      receita_operacional_bruta, receita_financeira, receita_nao_operacional, total_entradas,
      impostos_vendas, despesa_variavel, despesa_operacional,
      materia_prima, gastos_gerais_fabricacao, despesas_pessoal, despesas_fixas, despesas_financeiras, despesas_nao_operacionais, total_saidas,
      receita_bruta_operacional, lucro_bruto, lucro_operacional, lucro_liquido,
      valor_pedidos, resultado_efetivo, margem_resultado_efetivo,
      perc_materia_prima, perc_fixo_rateado, perc_tributos, perc_comissao_interna, perc_descontos
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      d.ano, d.mes,
      d.receitaOperacionalBruta, d.receitaFinanceira, d.receitaNaoOperacional, d.totalEntradas,
      d.impostosVendas, d.despesaVariavel, d.despesaOperacional,
      d.materiaPrima, d.gastosGeraisFabricacao, d.despesasPessoal, d.despesasFixas, d.despesasFinanceiras, d.despesasNaoOperacionais, d.totalSaidas,
      d.receitaBrutaOperacional, d.lucroBruto, d.lucroOperacional, d.lucroLiquido,
      d.valorPedidos, d.resultadoEfetivo, d.margemResultadoEfetivo,
      d.percMateriaPrima, d.percFixoRateado, d.percTributos, d.percComissaoInterna, d.percDescontos,
    ]
  );
  console.log(`✓ Inserido: ${d.ano}/${String(d.mes).padStart(2,"0")}`);
}

await conn.end();
console.log("✅ Seed DRE Mensal concluído!");
