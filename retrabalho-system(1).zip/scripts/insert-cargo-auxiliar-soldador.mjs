import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";

dotenv.config({ path: resolve(process.cwd(), ".env") });

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL não encontrado");
  process.exit(1);
}

const connection = await mysql.createConnection(DATABASE_URL);

const now = new Date();

const [result] = await connection.execute(
  `INSERT INTO cargos_funcoes 
   (titulo, missao, responsabilidades, kpis, ferramentas, integracao, riscos, requisitos, condicoes, createdBy, updatedBy, createdAt, updatedAt)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  [
    "Auxiliar de Soldador",
    "Garantir o suporte operacional contínuo ao setor de soldagem, cuidando da preparação física das peças, logística de materiais pesados e finalização estética (polimento), assegurando que o fluxo de produção não sofra interrupções por falta de insumos ou desorganização do ambiente.",
    `• Preparação de Superfícies: Realizar o lixamento técnico das superfícies das letras para garantir a aderência e qualidade da solda.
• Higienização de Peças: Lavar as peças conforme a requisição dos soldadores para remover impurezas.
• Suporte Logístico em Máquina: Responsável pela movimentação e entrega de perfis metálicos para a dobradeira sempre que a operadora do equipamento for feminina, garantindo a segurança e ergonomia no setor.
• Acabamento de Luxo: Realizar o polimento fino em letreiros de aço inox para entrega conforme o padrão visual da empresa.
• Organização e Zeladoria: Manter o setor de solda rigorosamente limpo e organizado.
• Preparação de Insumos: Organizar e preparar os fixadores que serão utilizados na montagem das estruturas.
• Auxílio na Elétrica/Montagem: Atuar como suporte na colagem de módulos de LED nos letreiros.`,
    null,
    null,
    null,
    `• Uso obrigatório de EPIs para todas as atividades manuais e de lixamento.
• Reportar ao Gerente de Produção qualquer falta de insumos ou problemas operacionais imediatamente.`,
    `Limites de Atuação:
• Não possui responsabilidade sobre a leitura ou validação técnica de desenhos e projetos.
• Não é responsável por atestar se as letras estão dentro dos padrões finais de qualidade exigidos.
• Não realiza o transporte de letreiros para o setor de expedição.`,
    `• Subordinação: Reporta-se diretamente ao Gerente de Produção.
• Setor: Produção / Soldagem
• Regime de Trabalho: Presencial e estritamente interno na unidade de Campo Grande, MS.
• Jornada: Horário de trabalho idêntico aos demais cargos operacionais da empresa, respeitando os intervalos regulamentares.
• Demandas extraordinárias devem ser formalizadas via memorandos ou ordens de serviço.`,
    "sistema",
    "sistema",
    now,
    now,
  ]
);

console.log("✅ Cargo 'Auxiliar de Soldador' inserido com sucesso! ID:", result.insertId);
await connection.end();
