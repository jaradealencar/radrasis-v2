import * as dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync } from 'fs';

// Carregar .env manualmente
const envPath = join(dirname(fileURLToPath(import.meta.url)), '..', '.env');
try {
  const envContent = readFileSync(envPath, 'utf-8');
  for (const line of envContent.split('\n')) {
    const [k, ...v] = line.split('=');
    if (k && v.length) process.env[k.trim()] = v.join('=').trim().replace(/^["']|["']$/g, '');
  }
} catch {}

const pub = process.env.MUBISYS_PUBLIC_KEY;
const tok = process.env.MUBISYS_ACCESS_TOKEN;
const base = 'https://api.mubisys.com.br';

// Buscar OS normais e ver campos de cliente
const r = await fetch(`${base}/ordem-servico?tipo=Normal&limit=3&data_inicio=2026-01-01&data_fim=2026-01-31`, {
  headers: { 'x-public-key': pub, 'Authorization': `Bearer ${tok}` }
});
const d = await r.json();
const items = d.data ?? d;
if (items.length > 0) {
  console.log('Campos disponíveis:', Object.keys(items[0]).join(', '));
  console.log('\nAmostra item[0]:');
  for (const [k, v] of Object.entries(items[0])) {
    if (String(v).length < 100) console.log(`  ${k}: ${v}`);
  }
}

// Testar endpoint de clientes
console.log('\n--- Testando endpoint /cliente ---');
const r2 = await fetch(`${base}/cliente?limit=2`, {
  headers: { 'x-public-key': pub, 'Authorization': `Bearer ${tok}` }
});
const d2 = await r2.json();
const clientes = d2.data ?? d2;
if (Array.isArray(clientes) && clientes.length > 0) {
  console.log('Campos cliente:', Object.keys(clientes[0]).join(', '));
  console.log('Amostra:', JSON.stringify(clientes[0], null, 2).substring(0, 500));
}
