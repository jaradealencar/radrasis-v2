import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const ATUAL_ID = 3;

// Verificar transportadora
const [rows] = await conn.execute('SELECT id, nome FROM transportadoras WHERE id = ?', [ATUAL_ID]);
console.log(`✅ Transportadora: ${rows[0].nome} (id=${rows[0].id})`);

// Cidades existentes
const [existing] = await conn.execute(
  'SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?',
  [ATUAL_ID]
);
const existingSet = new Set(existing.map(r => `${r.cidade.toUpperCase()}|${r.estado.toUpperCase()}`));
console.log(`Cidades já cadastradas: ${existingSet.size}`);

// Carregar dados
const data = JSON.parse(readFileSync('/tmp/atual_data.json', 'utf-8'));
console.log(`Cidades no arquivo: ${data.length}`);

// Inserir em lotes de 200
let inserted = 0;
let skipped = 0;
const BATCH = 200;

const toInsert = data.filter(c => {
  const key = `${c.cidade.toUpperCase()}|${c.estado.toUpperCase()}`;
  if (existingSet.has(key)) { skipped++; return false; }
  return true;
});

console.log(`A inserir: ${toInsert.length} | Já existem: ${skipped}`);

for (let i = 0; i < toInsert.length; i += BATCH) {
  const batch = toInsert.slice(i, i + BATCH);
  const placeholders = batch.map(() => '(?, ?, ?, ?, NOW())').join(', ');
  const values = batch.flatMap(c => [ATUAL_ID, c.cidade, c.estado, c.observacao || null]);
  await conn.execute(
    `INSERT INTO transportadora_cidades (transportadoraId, cidade, estado, observacao, createdAt) VALUES ${placeholders}`,
    values
  );
  inserted += batch.length;
  process.stdout.write(`\r  Inseridas: ${inserted}/${toInsert.length}`);
}

console.log(`\n✅ Atual Cargas: ${inserted} cidades inseridas`);

// Distribuição por estado
const [dist] = await conn.execute(
  `SELECT estado, COUNT(*) as total FROM transportadora_cidades WHERE transportadoraId = ? GROUP BY estado ORDER BY total DESC LIMIT 10`,
  [ATUAL_ID]
);
console.log('\nTop 10 estados:');
dist.forEach(r => console.log(`  ${r.estado}: ${r.total}`));

const [total] = await conn.execute(
  'SELECT COUNT(*) as total FROM transportadora_cidades WHERE transportadoraId = ?',
  [ATUAL_ID]
);
console.log(`\nTotal geral: ${total[0].total} cidades`);

await conn.end();
