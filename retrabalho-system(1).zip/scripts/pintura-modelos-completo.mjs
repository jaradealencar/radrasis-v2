import https from 'https';
import fs from 'fs';

const publicKey = process.env.MUBISYS_PUBLIC_KEY;
const accessToken = process.env.MUBISYS_ACCESS_TOKEN;

function fetchPage(start, end, page) {
  return new Promise((resolve) => {
    const path = `/ordem-servico?status=TODOS&filtrodata=CADASTRO&datainicial=${start}&datafinal=${end}&page=${page}&per_page=500`;
    const url = `https://api.mubisys.com/api/${publicKey}${path}`;
    const req = https.get(url, { headers: { 'Access-Token': accessToken, 'Accept': 'application/json' } }, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => { try { resolve(JSON.parse(body)); } catch { resolve({}); } });
    });
    req.on('error', () => resolve({}));
    req.setTimeout(30000, () => { req.destroy(); resolve({}); });
  });
}

async function fetchAllOsForPeriod(start, end) {
  let all = [];
  let page = 1;
  while (true) {
    const d = await fetchPage(start, end, page);
    const items = (d.data || []);
    if (items.length === 0) break;
    all = all.concat(items);
    const pagination = d.pagination;
    if (!pagination || page >= (pagination.last_page || 1)) break;
    page++;
  }
  return all;
}

async function main() {
  const periods = [
    ['2026-01-01', '2026-01-31'],
    ['2026-02-01', '2026-02-28'],
    ['2026-03-01', '2026-03-31'],
    ['2026-04-01', '2026-04-30'],
    ['2026-05-01', '2026-05-31'],
    ['2026-06-01', '2026-06-04'],
  ];

  // Coletar TODOS os modelos de itens que contenham 'pintura' no item OU no modelo
  const modelosPintura = {};
  // Também buscar qualquer item com 'cor' ou 'cores' no modelo
  const modelosComCor = {};

  for (const [start, end] of periods) {
    console.error(`Fetching ${start} to ${end}...`);
    const osList = await fetchAllOsForPeriod(start, end);
    console.error(`  Got ${osList.length} OS`);
    
    for (const os of osList) {
      for (const it of (os.itens || [])) {
        const item = (it.item || '').toLowerCase();
        const modelo = (it.modelo || '');
        const modeloLower = modelo.toLowerCase();
        
        // Itens de pintura - coletar todos os modelos
        if (item.includes('pintura')) {
          const key = modelo || '(vazio)';
          if (modelosPintura[key] === undefined) {
            modelosPintura[key] = { count: 0, items: [] };
          }
          modelosPintura[key].count++;
          if (modelosPintura[key].items.length < 3) {
            modelosPintura[key].items.push({
              os: os.sequencial_ordem,
              item: it.item,
              largura: it.largura,
              altura: it.altura,
              valor_unitario: it.valor_unitario,
            });
          }
        }
        
        // Qualquer item com 'cor' ou 'cores' no modelo (pode revelar 3/4 cores em outros produtos)
        if (modeloLower.includes('cor') && (modeloLower.includes('3') || modeloLower.includes('4') || modeloLower.includes('três') || modeloLower.includes('quatro'))) {
          const key = `[${it.item}] ${modelo}`;
          if (modelosComCor[key] === undefined) {
            modelosComCor[key] = { count: 0, items: [] };
          }
          modelosComCor[key].count++;
          if (modelosComCor[key].items.length < 2) {
            modelosComCor[key].items.push({
              os: os.sequencial_ordem,
              item: it.item,
              largura: it.largura,
              altura: it.altura,
              valor_unitario: it.valor_unitario,
            });
          }
        }
      }
    }
  }

  console.log('=== TODOS OS MODELOS DE ITENS DE PINTURA ===');
  console.log('(Ordenados por frequência)\n');
  Object.entries(modelosPintura)
    .sort((a, b) => b[1].count - a[1].count)
    .forEach(([modelo, data]) => {
      console.log(`  [${data.count}x] "${modelo}"`);
      data.items.forEach(it => {
        console.log(`       OS ${it.os} | ${it.item} | ${it.largura}x${it.altura} | R$ ${it.valor_unitario}`);
      });
    });

  console.log('\n\n=== ITENS COM "3 COR" OU "4 COR" NO MODELO (QUALQUER PRODUTO) ===\n');
  if (Object.keys(modelosComCor).length === 0) {
    console.log('  NENHUM ENCONTRADO em todo o período Jan-Jun/2026');
  } else {
    Object.entries(modelosComCor)
      .sort((a, b) => b[1].count - a[1].count)
      .forEach(([key, data]) => {
        console.log(`  [${data.count}x] ${key}`);
        data.items.forEach(it => {
          console.log(`       OS ${it.os} | ${it.largura}x${it.altura} | R$ ${it.valor_unitario}`);
        });
      });
  }

  // Buscar também no catálogo de produtos da API
  console.log('\n\n=== BUSCANDO PRODUTOS DE PINTURA NO CATÁLOGO ===\n');
  const prodUrl = `https://api.mubisys.com/api/${publicKey}/produto?per_page=500&page=1`;
  const prodData = await new Promise((resolve) => {
    const req = https.get(prodUrl, { headers: { 'Access-Token': accessToken, 'Accept': 'application/json' } }, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => { try { resolve(JSON.parse(body)); } catch { resolve({}); } });
    });
    req.on('error', () => resolve({}));
    req.setTimeout(30000, () => { req.destroy(); resolve({}); });
  });

  if (prodData.data) {
    const pinturaProds = prodData.data.filter(p => {
      const nome = (p.nome || p.item || p.descricao || '').toLowerCase();
      return nome.includes('pintura');
    });
    
    if (pinturaProds.length > 0) {
      pinturaProds.forEach(p => {
        console.log(`  Produto: ${p.nome || p.item || 'N/A'}`);
        console.log(`    ID: ${p.id}`);
        if (p.modelos) console.log(`    Modelos: ${JSON.stringify(p.modelos).substring(0, 200)}`);
        if (p.variacoes) console.log(`    Variações: ${JSON.stringify(p.variacoes).substring(0, 200)}`);
        console.log('');
      });
    } else {
      console.log('  Endpoint de produto não retornou itens de pintura ou formato diferente.');
      console.log('  Keys disponíveis:', Object.keys(prodData).join(', '));
      if (prodData.data && prodData.data[0]) {
        console.log('  Exemplo de produto:', JSON.stringify(prodData.data[0]).substring(0, 200));
      }
    }
  } else {
    console.log('  Não foi possível acessar o catálogo de produtos.');
    console.log('  Response keys:', Object.keys(prodData).join(', '));
  }
}

main().catch(console.error);
