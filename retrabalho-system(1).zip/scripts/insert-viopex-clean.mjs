import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// 1. Adicionar colunas endereco, responsavel, sede se não existirem
const [cols] = await conn.execute('DESCRIBE transportadora_cidades');
const colNames = cols.map(c => c.Field);

if (!colNames.includes('endereco')) {
  await conn.execute('ALTER TABLE transportadora_cidades ADD COLUMN endereco VARCHAR(512) DEFAULT NULL AFTER observacao');
  console.log('✅ Coluna endereco adicionada');
} else {
  console.log('ℹ️ Coluna endereco já existe');
}

if (!colNames.includes('responsavel')) {
  await conn.execute('ALTER TABLE transportadora_cidades ADD COLUMN responsavel VARCHAR(128) DEFAULT NULL AFTER endereco');
  console.log('✅ Coluna responsavel adicionada');
} else {
  console.log('ℹ️ Coluna responsavel já existe');
}

if (!colNames.includes('sede')) {
  await conn.execute('ALTER TABLE transportadora_cidades ADD COLUMN sede VARCHAR(128) DEFAULT NULL AFTER responsavel');
  console.log('✅ Coluna sede adicionada');
} else {
  console.log('ℹ️ Coluna sede já existe');
}

// 2. Buscar ID da VIOPEX
const [viopexRows] = await conn.execute("SELECT id, nome FROM transportadoras WHERE nome LIKE '%iopex%'");
console.log('VIOPEX encontrada:', viopexRows);
const viopexId = viopexRows[0]?.id;
if (!viopexId) {
  console.error('❌ VIOPEX não encontrada no banco!');
  await conn.end();
  process.exit(1);
}
console.log(`✅ VIOPEX encontrada com ID: ${viopexId}`);

// 3. Ler dados extraídos pelo Python
const jsonData = readFileSync('/tmp/viopex_data.json', 'utf-8');
const cidades = JSON.parse(jsonData);
console.log(`Total de cidades a inserir: ${cidades.length}`);

// 4. Verificar existentes
const [existing] = await conn.execute(
  'SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?',
  [viopexId]
);
const existingSet = new Set(existing.map(r => `${r.cidade.toLowerCase()}|${r.estado.toLowerCase()}`));
console.log(`Cidades já existentes: ${existingSet.size}`);

let inserted = 0;
let skipped = 0;
for (const c of cidades) {
  const key = `${c.cidade.toLowerCase()}|${c.estado.toLowerCase()}`;
  if (existingSet.has(key)) {
    skipped++;
    continue;
  }
  
  await conn.execute(
    `INSERT INTO transportadora_cidades 
     (transportadoraId, cidade, estado, telefone, observacao, endereco, responsavel, sede, createdAt) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
    [
      viopexId,
      c.cidade || null,
      c.estado || null,
      c.telefone || null,
      c.observacao || null,
      c.endereco || null,
      c.responsavel || null,
      c.sede || null
    ]
  );
  inserted++;
}

console.log(`✅ VIOPEX: ${inserted} cidades inseridas, ${skipped} já existiam`);
await conn.end();
