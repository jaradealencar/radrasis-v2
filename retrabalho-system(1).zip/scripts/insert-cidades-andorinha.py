import openpyxl
import mysql.connector
import os
import re

# Carregar variáveis de ambiente do .env
env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
db_url = None
if os.path.exists(env_path):
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line.startswith('DATABASE_URL='):
                db_url = line.split('=', 1)[1].strip().strip('"').strip("'")
                break

if not db_url:
    # Tentar pegar do ambiente
    db_url = os.environ.get('DATABASE_URL', '')

if not db_url:
    print("DATABASE_URL não encontrado!")
    exit(1)

# Parsear a URL do banco: mysql://user:pass@host:port/dbname
match = re.match(r'mysql(?:\+[^:]+)?://([^:]+):([^@]+)@([^:/]+)(?::(\d+))?/([^?]+)', db_url)
if not match:
    print(f"Formato de DATABASE_URL não reconhecido: {db_url[:50]}...")
    exit(1)

user, password, host, port, database = match.groups()
port = int(port) if port else 3306

print(f"Conectando ao banco: {host}:{port}/{database}")

# Ler cidades da planilha
wb = openpyxl.load_workbook('/home/ubuntu/upload/Grade_2026_Mar_o_Direta_Clientes.xlsx', read_only=True, data_only=True)
ws = wb['Março']
cidades_planilha = []
for i, row in enumerate(ws.iter_rows(values_only=True)):
    if i < 3:
        continue
    if row[0] and row[1] and str(row[0]).strip() not in ('UF', 'None', ''):
        uf = str(row[0]).strip()
        cidade = str(row[1]).strip()
        if uf and cidade:
            cidades_planilha.append((uf, cidade))

print(f"Total de cidades na planilha: {len(cidades_planilha)}")

# Conectar ao banco
conn = mysql.connector.connect(
    host=host, port=port, user=user, password=password, database=database,
    ssl_disabled=False
)
cursor = conn.cursor()

# Encontrar a Andorinha
cursor.execute("SELECT id, nome FROM transportadoras WHERE nome LIKE '%ndorinha%'")
transportadoras = cursor.fetchall()

if not transportadoras:
    print("Transportadora Andorinha não encontrada!")
    conn.close()
    exit(1)

andorinha_id, andorinha_nome = transportadoras[0]
print(f"\nTransportadora encontrada: {andorinha_nome} (ID: {andorinha_id})")

# Verificar cidades já existentes
cursor.execute(
    "SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = %s",
    (andorinha_id,)
)
existentes = set(f"{r[1]}|{r[0]}" for r in cursor.fetchall())
print(f"Cidades já cadastradas: {len(existentes)}")

# Filtrar novas
novas = [(uf, cidade) for uf, cidade in cidades_planilha if f"{uf}|{cidade}" not in existentes]
print(f"Cidades novas a inserir: {len(novas)}")
print(f"Cidades já existentes (puladas): {len(cidades_planilha) - len(novas)}\n")

if not novas:
    print("Todas as cidades já estão cadastradas!")
    conn.close()
    exit(0)

# Inserir em lotes
BATCH = 50
inseridas = 0
for i in range(0, len(novas), BATCH):
    lote = novas[i:i+BATCH]
    placeholders = ', '.join(['(%s, %s, %s)'] * len(lote))
    valores = []
    for uf, cidade in lote:
        valores.extend([andorinha_id, cidade, uf])
    cursor.execute(
        f"INSERT INTO transportadora_cidades (transportadoraId, cidade, estado) VALUES {placeholders}",
        valores
    )
    inseridas += len(lote)
    print(f"  Inserindo... {inseridas}/{len(novas)}", end='\r')

# Atualizar data de última atualização
from datetime import date
hoje = date.today().isoformat()
cursor.execute(
    "UPDATE transportadoras SET ultAtualizCidades = %s WHERE id = %s",
    (hoje, andorinha_id)
)

conn.commit()
cursor.close()
conn.close()

print(f"\n\n✅ Concluído! {inseridas} cidades inseridas para a {andorinha_nome}.")
print(f"📅 Data de atualização registrada: {hoje}")
