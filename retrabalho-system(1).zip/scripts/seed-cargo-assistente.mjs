import mysql from "mysql2/promise";

const cargo = {
  titulo: "Assistente Administrativo Logístico",
  missao: `Otimizar o fluxo de saída de mercadorias, garantindo o equilíbrio entre a agilidade de entrega e a eficiência financeira (custo de frete), servindo de suporte técnico para o Comercial e a Supervisão.`,
  responsabilidades: `**Cotações:** Realizar orçamentos de frete com transportadoras parceiras para atender as demandas do setor Comercial.

**Gestão de Dados:** Alimentar os sistemas Mubisys e Radrasis, além de sites das transportadoras, com precisão absoluta.

**Manutenção de Cadastro:** Sob demanda da supervisão, realizar contato negocial para negociação de tabelas, atualização de cidades atendidas e dados cadastrais no sistema.

**Faturamento:** Emissão de Notas Fiscais (NF-e) de saída.

**Rastreio e Apoio em Crises:** Realizar o rastreio de mercadorias quando solicitado e atuar junto à supervisão na resolução de problemas (cargas paradas, avarias ou atrasos) quando acionado.`,
  kpis: `**Prazo de Resposta:** Cotações respondidas ao Comercial em até 15 minutos após a solicitação.

**Acurácia de Dados:** Zero erros de digitação em campos críticos: cidades, valores, prazos e fornecedores nos sistemas.

**Eficiência de Custo:** A média do valor do frete deve ser inferior a 15% em relação ao valor total do pedido.`,
  ferramentas: `**Sistemas Operacionais:** Mubisys e Radrasis.

**Pesquisa:** Portais oficiais das transportadoras para coleta de preços.

**Comunicação:** WhatsApp Corporativo da empresa.`,
  integracao: `**Recebe de:** Comercial (pedidos de cotação), Produção (avisos de pedidos prontos para envio) e Supervisão (demandas diversas).

**Entrega para:** Comercial (cotações e rastreios) e Transportadoras (documentação e solicitações de coleta).`,
  riscos: `**Expectativa do Cliente:** Digitação errada de prazos ou fornecedoras que estragam a experiência do cliente.

**Confiabilidade:** Informações de rastreio equivocadas ou demora nas respostas acima do prazo estipulado.

**Financeiro:** Digitação errada de valores de frete ou medidas.`,
  requisitos: `**Domínio de Medidas:** Saber operar com metro e centímetro, compreendendo com clareza a diferença entre eles para evitar erros de cubagem e preço.

**Perfil Comportamental:** Exige-se alta agilidade e concentração, perfil voltado para trabalho interno e capacidade de negociação sob orientação.`,
  condicoes: `**Subordinação:** Supervisor Logístico.

**Carga Horária:** Comercial (Segunda a Sexta).

**Ambiente:** 100% Interno, sem atendimento presencial a clientes ou viagens.`,
  createdBy: "sistema",
  updatedBy: "sistema",
};

async function run() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  // Verifica se já existe
  const [rows] = await conn.execute(
    "SELECT id FROM cargos_funcoes WHERE titulo = ?",
    [cargo.titulo]
  );
  if (rows.length > 0) {
    console.log("Cargo já existe, pulando seed.");
    await conn.end();
    return;
  }
  await conn.execute(
    `INSERT INTO cargos_funcoes
      (titulo, missao, responsabilidades, kpis, ferramentas, integracao, riscos, requisitos, condicoes, createdBy, updatedBy)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      cargo.titulo, cargo.missao, cargo.responsabilidades, cargo.kpis,
      cargo.ferramentas, cargo.integracao, cargo.riscos, cargo.requisitos,
      cargo.condicoes, cargo.createdBy, cargo.updatedBy,
    ]
  );
  console.log("Cargo inserido com sucesso!");
  await conn.end();
}

run().catch(e => { console.error(e.message); process.exit(1); });
