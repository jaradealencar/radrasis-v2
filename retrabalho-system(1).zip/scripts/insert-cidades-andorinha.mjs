import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
import { readFileSync } from "fs";
dotenv.config({ path: resolve(process.cwd(), ".env") });

// Dados extraídos da planilha Grade_2026_Março_Direta_Clientes.xlsx
// Colunas: UF, CIDADE
const cidadesDaPlanilha = [
  ["SP","ADAMANTINA"],["PR","ADRIANOPOLIS"],["SP","AGUDOS"],["PR","AGUDOS DO SUL"],
  ["SP","ALFREDO MARCONDES"],["PR","ALMIRANTE TAMANDARE"],["PR","ALTAMIRA DO PARANA"],
  ["PR","ALTO PARANA"],["PR","ALTO PIQUIRI"],["PR","ALTONIA"],["PR","ALVORADA DO SUL"],
  ["PR","AMAPORÃ"],["PR","AMPERE"],["SP","ANDRADINA"],["SP","ANGATUBA"],
  ["PR","ANTONINA"],["SP","APARECIDA"],["SP","APARECIDA D OESTE"],["PR","APUCARANA"],
  ["SP","ARACATUBA"],["SP","ARACOIABA DA SERRA"],["SP","ARAMINA"],["SP","ARARAQUARA"],
  ["SP","ARARAS"],["SP","ARCO IRIS"],["SP","AREALVA"],["SP","AREIOPOLIS"],
  ["SP","ARIRANHA"],["SP","ARUJA"],["SP","ASSIS"],["PR","ASSAI"],
  ["PR","ASTORGA"],["SP","ATIBAIA"],["PR","ATALAIA"],["SP","AVARE"],
  ["PR","BANDEIRANTES"],["SP","BARBOSA"],["SP","BARRA BONITA"],["SP","BARRETOS"],
  ["SP","BARUERI"],["SP","BASTOS"],["SP","BATATAIS"],["SP","BAURU"],
  ["SP","BEBEDOURO"],["PR","BELA VISTA DO PARAISO"],["SP","BIRIGUI"],["SP","BOCAINA"],
  ["PR","BOM SUCESSO"],["PR","BORRAZOPOLIS"],["SP","BOTUCATU"],["SP","BRAGANCA PAULISTA"],
  ["PR","BRAGANEY"],["SP","BRODOSQUI"],["PR","CAFEZAL DO SUL"],["SP","CAJAMAR"],
  ["SP","CAJATI"],["SP","CAJURU"],["PR","CAMBARA"],["PR","CAMBE"],
  ["PR","CAMBIRA"],["SP","CAMPINAS"],["SP","CAMPO LIMPO PAULISTA"],["PR","CAMPO MOURAO"],
  ["SP","CAMPOS DO JORDAO"],["SP","CANANEIA"],["SP","CAPAO BONITO"],["PR","CAPITAO LEONIDAS MARQUES"],
  ["SP","CAPIVARI"],["PR","CARAMBEI"],["SP","CARAGUATATUBA"],["SP","CARDOSO"],
  ["SP","CASA BRANCA"],["SP","CATANDUVA"],["SP","CERQUEIRA CESAR"],["SP","CERQUILHO"],
  ["SP","CESARIO LANGE"],["PR","CHOPINZINHO"],["PR","CIANORTE"],["PR","CIDADE GAUCHA"],
  ["SP","CLEMENTINA"],["PR","CLEVELANDIA"],["SP","COLINA"],["SP","COLOMBIA"],
  ["PR","COLORADO"],["PR","CONGONHINHAS"],["PR","CONSELHEIRO MAIRINCK"],["PR","CONTENDA"],
  ["SP","CORDEIROPOLIS"],["SP","COSMORAMA"],["PR","CORNELIO PROCOPIO"],["SP","COTIA"],
  ["PR","CRUZEIRO DO OESTE"],["PR","CRUZEIRO DO SUL"],["SP","CRUZEIRO"],["SP","CUBATAO"],
  ["PR","CURIUVA"],["SP","DESCALVADO"],["SP","DIADEMA"],["SP","DRACENA"],
  ["PR","DOIS VIZINHOS"],["SP","DOURADO"],["SP","DRACENA"],["PR","ENGENHEIRO BELTRAO"],
  ["SP","ELIAS FAUSTO"],["SP","EMBU"],["SP","EMBU GUACU"],["PR","ENTRE RIOS DO OESTE"],
  ["SP","ESPIRITO SANTO DO PINHAL"],["SP","ESPIRITO SANTO DO TURVO"],["SP","FERNANDOPOLIS"],
  ["SP","FERRAZ DE VASCONCELOS"],["PR","FIGUEIRA"],["SP","FLORA RICA"],["PR","FLORAI"],
  ["PR","FLORESTA"],["PR","FLORESTOPOLIS"],["PR","FLORIDA"],["SP","FRANCA"],
  ["PR","FRANCISCO BELTRAO"],["SP","GALIA"],["SP","GARÇA"],["PR","GOIOERE"],
  ["SP","GENERAL SALGADO"],["SP","GUAIRA"],["PR","GUAIRA"],["SP","GUAPIACU"],
  ["SP","GUAPIARA"],["SP","GUARACI"],["SP","GUARATINGUETA"],["PR","GUARATUBA"],
  ["SP","GUARIBA"],["SP","GUARUJA"],["SP","GUARULHOS"],["SP","GUZOLANDIA"],
  ["SP","HERCULANDIA"],["PR","IBAITI"],["SP","IBATE"],["SP","IBIRA"],
  ["SP","IBITINGA"],["SP","IBIUNA"],["SP","ICEM"],["PR","IGUARACU"],
  ["PR","IGUATU"],["SP","ILHA SOLTEIRA"],["SP","ILHABELA"],["SP","INDAIATUBA"],
  ["SP","IPEUNA"],["SP","IRACEMAPOLIS"],["SP","IRAPUA"],["SP","IRAPURU"],
  ["PR","IRETAMA"],["SP","ITAI"],["SP","ITANHAEM"],["SP","ITAPETININGA"],
  ["SP","ITAPEVA"],["SP","ITAPIRA"],["SP","ITAPOLIS"],["SP","ITAQUAQUECETUBA"],
  ["SP","ITARARE"],["SP","ITARIRI"],["SP","ITATIBA"],["SP","ITATINGA"],
  ["SP","ITIRAPINA"],["SP","ITIRAPUA"],["SP","ITOBI"],["SP","ITU"],
  ["SP","ITUVERAVA"],["SP","JABORANDI"],["SP","JABOTICABAL"],["SP","JACAREI"],
  ["SP","JALES"],["SP","JANDIRA"],["PR","JANDAIA DO SUL"],["PR","JAPIRA"],
  ["PR","JAPORA"],["PR","JARDIM ALEGRE"],["PR","JARDIM OLINDA"],["SP","JAU"],
  ["PR","JATAIZINHO"],["SP","JOSE BONIFACIO"],["PR","JOAQUIM TAVORA"],["PR","JUNDIAI DO SUL"],
  ["SP","JUNDIAI"],["PR","JURANDA"],["PR","KALORE"],["SP","LARANJAL PAULISTA"],
  ["PR","LARANJEIRAS DO SUL"],["SP","LEME"],["SP","LIMEIRA"],["SP","LINS"],
  ["SP","LORENA"],["SP","LOUVEIRA"],["PR","LOANDA"],["PR","LOBATO"],
  ["PR","LONDRINA"],["SP","LUCELIA"],["SP","LUZIANIA"],["SP","MACATUBA"],
  ["SP","MAIRINQUE"],["SP","MAIRIPORA"],["PR","MAMBORE"],["PR","MANDAGUACU"],
  ["PR","MANDAGUARI"],["PR","MANFRINOPOLIS"],["PR","MANGUEIRINHA"],["PR","MARECHAL CANDIDO RONDON"],
  ["PR","MARIALVA"],["SP","MARILIA"],["PR","MARINGA"],["SP","MARTINOPOLIS"],
  ["PR","MARUMBI"],["PR","MATELANDIA"],["PR","MATO RICO"],["PR","MAUA DA SERRA"],
  ["SP","MIRANDOPOLIS"],["SP","MIRASSOLANDIA"],["SP","MIRASSOL"],["SP","MOCOCA"],
  ["SP","MOGI DAS CRUZES"],["SP","MOGI GUACU"],["SP","MOGI MIRIM"],["SP","MOMBUCA"],
  ["PR","MOREIRA SALES"],["PR","MUNHOZ DE MELO"],["PR","NOVA ALIANCA DO IVAI"],
  ["SP","MONTE ALEGRE DO SUL"],["SP","MONTE ALTO"],["SP","MONTE AZUL PAULISTA"],
  ["SP","MONTE MOR"],["PR","NOVA AURORA"],["PR","NOVA CANTU"],["PR","NOVA ESPERANCA"],
  ["PR","NOVA FATIMA"],["PR","NOVA LONDRINA"],["PR","NOVA OLIMPIA"],["PR","NOVA SANTA BARBARA"],
  ["PR","NOVA SANTA ROSA"],["PR","NOVA TEBAS"],["PR","NOVO ITACOLOMI"],["SP","NOVA GRANADA"],
  ["SP","NOVO HORIZONTE"],["PR","ORTIGUEIRA"],["SP","OLIMPIA"],["SP","ORLANDIA"],
  ["SP","OSVALDO CRUZ"],["SP","OURINHOS"],["PR","OURIZONA"],["PR","OURO VERDE DO OESTE"],
  ["SP","PACAEMBU"],["PR","PAIÇANDU"],["PR","PALMAS"],["PR","PALMEIRA"],
  ["PR","PALMITAL"],["PR","PALOTINA"],["PR","PARAISO DO NORTE"],["PR","PARANACITY"],
  ["PR","PARANAGUA"],["PR","PARANAPOEMA"],["PR","PARANAVAR"],["SP","PARAGUACU PAULISTA"],
  ["SP","PARANAPANEMA"],["SP","PARANAPUA"],["SP","PARAPUA"],["SP","PARIQUERA ACU"],
  ["SP","PATROCINIO PAULISTA"],["SP","PAULICEIA"],["SP","PAULINIA"],["SP","PAULISTANIA"],
  ["SP","PAULO DE FARIA"],["SP","PEDERNEIRAS"],["SP","PEDREGULHO"],["SP","PEDREIRA"],
  ["SP","PENAPOLIS"],["PR","PEABIRU"],["PR","PEROBAL"],["PR","PEROLA"],
  ["SP","PEREIRA BARRETO"],["SP","PINDAMONHANGABA"],["SP","PINDORAMA"],["SP","PIRACAIA"],
  ["SP","PIRACICABA"],["SP","PIRAJUI"],["SP","PIRAJU"],["SP","PIRANGI"],
  ["SP","PIRASSUNUNGA"],["SP","PIRATININGA"],["SP","PITANGUEIRAS"],["PR","PIRAI DO SUL"],
  ["PR","PINHAO"],["PR","PIRAPO"],["PR","PITANGA"],["PR","PLANALTINA DO PARANA"],
  ["PR","PLANALTO"],["PR","PONTA GROSSA"],["SP","POMPEIA"],["SP","PONGAI"],
  ["SP","PONTAL"],["SP","PONTES GESTAL"],["SP","POPULINA"],["SP","PORTO FELIZ"],
  ["SP","PORTO FERREIRA"],["PR","PORTO RICO"],["PR","PORTO VITORIA"],["PR","PRADO FERREIRA"],
  ["PR","PRANCHITA"],["SP","PRADOPOLIS"],["SP","PRESIDENTE ALVES"],["SP","PRESIDENTE BERNARDES"],
  ["SP","PRESIDENTE EPITACIO"],["SP","PRESIDENTE PRUDENTE"],["SP","PRESIDENTE VENCESLAU"],
  ["PR","PRIMEIRO DE MAIO"],["PR","QUARTO CENTENARIO"],["PR","QUEDAS DO IGUACU"],
  ["PR","QUERENCIA DO NORTE"],["SP","QUATÁ"],["SP","QUEIROZ"],["SP","QUINTANA"],
  ["PR","RABATAO"],["SP","RANCHARIA"],["SP","REGENTE FEIJO"],["SP","REGINOPOLIS"],
  ["SP","REGISTRO"],["SP","RESTINGA"],["PR","RESERVA"],["PR","RIBEIRAO DO PINHAL"],
  ["SP","RIBEIRAO BONITO"],["SP","RIBEIRAO PRETO"],["SP","RIO CLARO"],["SP","RIO DAS PEDRAS"],
  ["PR","RIO BOM"],["PR","RIO BRILHANTE"],["PR","RIO NEGRO"],["PR","ROLANDIA"],
  ["PR","RONDON"],["PR","ROSARIO DO IVAI"],["SP","RUBIACEA"],["SP","RUBINEIA"],
  ["PR","SABAUDIA"],["PR","SALGADO FILHO"],["PR","SALTO DO ITARARE"],["PR","SALTO DO LONTRA"],
  ["SP","SALTO"],["SP","SALTO DE PIRAPORA"],["SP","SALTO GRANDE"],["PR","SANTA CECILIA DO PAVAO"],
  ["PR","SANTA CRUZ DE MONTE CASTELO"],["PR","SANTA FE"],["PR","SANTA HELENA"],
  ["PR","SANTA INES"],["PR","SANTA ISABEL DO IVAI"],["PR","SANTA IZABEL DO OESTE"],
  ["PR","SANTA LUCIA"],["PR","SANTA MARIANA"],["PR","SANTA MONICA"],["PR","SANTA TEREZA DO OESTE"],
  ["PR","SANTA TEREZINHA DE ITAIPU"],["SP","SANTA ADELIA"],["SP","SANTA BARBARA D OESTE"],
  ["SP","SANTA BRANCA"],["SP","SANTA CRUZ DAS PALMEIRAS"],["SP","SANTA CRUZ DO RIO PARDO"],
  ["SP","SANTA FE DO SUL"],["SP","SANTA GERTRUDES"],["SP","SANTA ISABEL"],
  ["SP","SANTA RITA DO PASSA QUATRO"],["SP","SANTA ROSA DE VITERBO"],["SP","SANTOPOLIS DO AGUAPEI"],
  ["SP","SANTOS"],["SP","SAO BERNARDO DO CAMPO"],["SP","SAO CAETANO DO SUL"],
  ["SP","SAO CARLOS"],["SP","SAO JOAO DA BOA VISTA"],["SP","SAO JOAO DO PAU D ALHO"],
  ["SP","SAO JOSE DO RIO PARDO"],["SP","SAO JOSE DO RIO PRETO"],["SP","SAO JOSE DOS CAMPOS"],
  ["SP","SAO MANUEL"],["SP","SAO MIGUEL ARCANJO"],["SP","SAO PAULO"],
  ["SP","SAO PEDRO"],["SP","SAO ROQUE"],["SP","SAO SEBASTIAO"],["SP","SAO SIMAO"],
  ["SP","SAO VICENTE"],["PR","SANTO ANTONIO DA PLATINA"],["PR","SANTO ANTONIO DO CAIUA"],
  ["PR","SANTO ANTONIO DO PARAISO"],["PR","SANTO ANTONIO DO SUDOESTE"],["PR","SANTO INACIO"],
  ["PR","SAO CARLOS DO IVAI"],["PR","SAO JOAO"],["PR","SAO JOAO DO CAIUA"],
  ["PR","SAO JORGE DO IVAI"],["PR","SAO JORGE DO PATROCINIO"],["PR","SAO JOSE DA BOA VISTA"],
  ["PR","SAO JOSE DAS PALMEIRAS"],["PR","SAO JOSE DOS PINHAIS"],["PR","SAO MANOEL DO PARANA"],
  ["PR","SAO MIGUEL DO IGUACU"],["PR","SAO PEDRO DO IGUACU"],["PR","SAO PEDRO DO IVAI"],
  ["PR","SAO PEDRO DO PARANA"],["PR","SAO SEBASTIAO DA AMOREIRA"],["PR","SAO TOME"],
  ["PR","SAPOPEMA"],["PR","SARANDI"],["PR","SAUDADE DO IGUACU"],["SP","SERRANA"],
  ["SP","SERTAOZINHO"],["PR","SERTANEJA"],["PR","SERTANOPOLIS"],["PR","SIQUEIRA CAMPOS"],
  ["SP","SOROCABA"],["SP","SUMARE"],["PR","SULINA"],["PR","TAMBOARA"],
  ["SP","TABATINGA"],["SP","TABOAO DA SERRA"],["SP","TAGUAI"],["SP","TAIACU"],
  ["SP","TAIUVA"],["SP","TAMBAU"],["SP","TANABI"],["SP","TAQUARITINGA"],
  ["SP","TAQUARITUBA"],["SP","TAQUARIVAI"],["SP","TATUÍ"],["SP","TAUBATE"],
  ["SP","TEODORO SAMPAIO"],["SP","TIETE"],["SP","TUPA"],["SP","TUPI PAULISTA"],
  ["PR","TERRA BOA"],["PR","TERRA RICA"],["PR","TERRA ROXA"],["PR","TIBAGI"],
  ["PR","TIJUCAS DO SUL"],["PR","TOLEDO"],["PR","TOMAZINA"],["PR","TRES BARRAS DO PARANA"],
  ["PR","TUNEIRAS DO OESTE"],["PR","UBIRATA"],["PR","UMUARAMA"],["PR","UNIFLOR"],
  ["PR","URAI"],["SP","UBATUBA"],["SP","UCHOA"],["SP","UNIAO PAULISTA"],
  ["SP","URANIA"],["SP","VARGEM GRANDE DO SUL"],["SP","VARGEM GRANDE PAULISTA"],
  ["SP","VERA CRUZ"],["SP","VIRADOURO"],["SP","VISTA ALEGRE DO ALTO"],
  ["SP","VINHEDO"],["SP","VOTORANTIM"],["SP","VOTUPORANGA"]
];

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Encontrar o ID da Andorinha
const [transportadoras] = await conn.execute(
  "SELECT id, nome FROM transportadoras WHERE nome LIKE '%ndorinha%'"
);

if (transportadoras.length === 0) {
  console.error("Transportadora Andorinha não encontrada no banco!");
  await conn.end();
  process.exit(1);
}

const andorinha = transportadoras[0];
console.log(`Transportadora encontrada: ${andorinha.nome} (ID: ${andorinha.id})\n`);

// Verificar cidades já existentes para evitar duplicatas
const [cidadesExistentes] = await conn.execute(
  "SELECT cidade, estado FROM transportadora_cidades WHERE transportadoraId = ?",
  [andorinha.id]
);

const existentes = new Set(cidadesExistentes.map(c => `${c.estado}|${c.cidade}`));
console.log(`Cidades já cadastradas: ${existentes.size}`);

// Filtrar apenas cidades novas
const novas = cidadesDaPlanilha.filter(([uf, cidade]) => !existentes.has(`${uf}|${cidade}`));
console.log(`Cidades novas a inserir: ${novas.length}`);
console.log(`Cidades já existentes (puladas): ${cidadesDaPlanilha.length - novas.length}\n`);

if (novas.length === 0) {
  console.log("Todas as cidades já estão cadastradas!");
  await conn.end();
  process.exit(0);
}

// Inserir em lotes de 50
const BATCH = 50;
let inseridas = 0;
for (let i = 0; i < novas.length; i += BATCH) {
  const lote = novas.slice(i, i + BATCH);
  const placeholders = lote.map(() => "(?, ?, ?)").join(", ");
  const valores = lote.flatMap(([uf, cidade]) => [andorinha.id, cidade, uf]);
  await conn.execute(
    `INSERT INTO transportadora_cidades (transportadoraId, cidade, estado) VALUES ${placeholders}`,
    valores
  );
  inseridas += lote.length;
  process.stdout.write(`\r  Inserindo... ${inseridas}/${novas.length}`);
}

// Atualizar data de última atualização de cidades
const hoje = new Date().toISOString().slice(0, 10);
await conn.execute(
  "UPDATE transportadoras SET ultAtualizCidades = ? WHERE id = ?",
  [hoje, andorinha.id]
);

console.log(`\n\n✅ Concluído! ${inseridas} cidades inseridas para a ${andorinha.nome}.`);
console.log(`📅 Data de atualização registrada: ${hoje}`);
await conn.end();
