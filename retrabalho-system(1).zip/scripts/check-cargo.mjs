import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { resolve } from "path";
dotenv.config({ path: resolve(process.cwd(), ".env") });

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const [rows] = await conn.execute("SELECT id, titulo FROM cargos_funcoes WHERE titulo = 'Auxiliar de Soldador' ORDER BY id");
console.log("Registros encontrados:", JSON.stringify(rows));

// Manter apenas o primeiro, deletar os demais
if (rows.length > 1) {
  const idsToDelete = rows.slice(1).map(r => r.id);
  await conn.execute(`DELETE FROM cargos_funcoes WHERE id IN (${idsToDelete.join(",")})`);
  console.log("Duplicatas removidas, IDs:", idsToDelete);
} else {
  console.log("Sem duplicatas. Cargo ID:", rows[0]?.id);
}
await conn.end();
