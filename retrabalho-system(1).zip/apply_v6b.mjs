import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const statements = [
  `ALTER TABLE \`empacotamento_modelos_caixa\` ADD COLUMN \`custoAquisicao\` DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'Custo de compra da caixa em R$'`,
  `CREATE TABLE IF NOT EXISTS \`empacotamento_insumos_letreiro\` (
    \`id\` INT NOT NULL AUTO_INCREMENT,
    \`modeloLetreiId\` INT NOT NULL,
    \`insumoId\` INT NOT NULL,
    \`quantidade\` DECIMAL(10,4) NOT NULL DEFAULT 1,
    \`observacao\` VARCHAR(255),
    \`createdAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    \`updatedAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (\`id\`),
    KEY \`idx_insumos_letreiro_modelo\` (\`modeloLetreiId\`),
    KEY \`idx_insumos_letreiro_insumo\` (\`insumoId\`)
  )`,
];

for (const stmt of statements) {
  try {
    await conn.execute(stmt);
    console.log('OK:', stmt.slice(0, 70));
  } catch (e) {
    console.log('SKIP:', e.message.slice(0, 100));
  }
}

await conn.end();
console.log('Migration v6b concluída.');
