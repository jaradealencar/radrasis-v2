import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const sql = readFileSync('./drizzle/0020_empacotamento_v6.sql', 'utf8');

const stmts = sql
  .split(';')
  .map(s => s.trim())
  .filter(s => s.length > 0 && !s.startsWith('--'));

for (const stmt of stmts) {
  try {
    await conn.execute(stmt);
    console.log('OK:', stmt.slice(0, 70));
  } catch (e) {
    console.log('SKIP:', e.message.slice(0, 100));
  }
}

await conn.end();
console.log('Migration v6 concluída.');
