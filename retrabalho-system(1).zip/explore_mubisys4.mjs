import https from "https";

const PUBLIC_KEY = process.env.MUBISYS_PUBLIC_KEY;
const ACCESS_TOKEN = process.env.MUBISYS_ACCESS_TOKEN;
const BASE = `https://api.mubisys.com/api/${PUBLIC_KEY}`;

function get(path) {
  return new Promise((resolve) => {
    const url = `${BASE}${path}`;
    const req = https.get(url, {
      headers: { "Access-Token": ACCESS_TOKEN, "Accept": "application/json" }
    }, (res) => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => resolve({ status: res.statusCode, body }));
    });
    req.on("error", e => resolve({ status: 0, body: e.message }));
    req.setTimeout(10000, () => { req.destroy(); resolve({ status: 0, body: "timeout" }); });
  });
}

// Try OS numbers that exist (from logistica.ts we know OS 1000 exists)
// Let's try a few recent ones
const testNumbers = [6400, 6420, 6440, 6450, 6460];
for (const num of testNumbers) {
  const { status, body } = await get(`/ordem-servico/numero/${num}`);
  if (status === 201) {
    const os = JSON.parse(body);
    console.log(`\n=== OS ${num} ===`);
    console.log("Keys:", Object.keys(os).join(", "));
    console.log("Cliente:", os.cliente);
    console.log("Status:", os.status);
    console.log("Data:", os.data_criacao ?? os.created_at ?? os.data);
    console.log("Valor:", os.valor_total ?? os.valor ?? os.total ?? "N/A");
    // Look for product info
    const prodKeys = Object.keys(os).filter(k => k.includes("produto") || k.includes("item") || k.includes("servico") || k.includes("modelo"));
    console.log("Product-related keys:", prodKeys);
    if (prodKeys.length > 0) {
      console.log("Product data:", JSON.stringify(os[prodKeys[0]], null, 2).substring(0, 300));
    }
    break;
  }
}

// Also try to understand what params OS endpoint accepts
const { status: s2, body: b2 } = await get("/ordem-servico/numero/6412");
if (s2 === 201) {
  const os = JSON.parse(b2);
  console.log("\n=== OS 6412 FULL STRUCTURE ===");
  console.log(JSON.stringify(os, null, 2).substring(0, 3000));
}
