import https from "https";

const PUBLIC_KEY = process.env.MUBISYS_PUBLIC_KEY;
const ACCESS_TOKEN = process.env.MUBISYS_ACCESS_TOKEN;

console.log("PUBLIC_KEY:", PUBLIC_KEY ? PUBLIC_KEY.substring(0, 12) + "..." : "NOT SET");
console.log("ACCESS_TOKEN:", ACCESS_TOKEN ? ACCESS_TOKEN.substring(0, 12) + "..." : "NOT SET");

const BASE = `https://api.mubisys.com/api/${PUBLIC_KEY}`;

function get(path) {
  return new Promise((resolve) => {
    const url = `${BASE}${path}`;
    const req = https.get(url, {
      headers: { "Access-Token": ACCESS_TOKEN, "Accept": "application/json" }
    }, (res) => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => resolve({ status: res.statusCode, body }));
    });
    req.on("error", e => resolve({ status: 0, body: e.message }));
    req.setTimeout(8000, () => { req.destroy(); resolve({ status: 0, body: "timeout" }); });
  });
}

async function tryEndpoint(path, label) {
  const { status, body } = await get(path);
  const preview = body.substring(0, 400);
  console.log(`\n[${status}] ${label} (${path})`);
  console.log(preview);
}

// Test known working endpoint first
await tryEndpoint("/ordem-servico/numero/1000", "OS por número (teste)");

// Try list endpoints
await tryEndpoint("/ordem-servico?page=1&per_page=3", "OS paginadas");
await tryEndpoint("/ordem-servico?status=finalizado&page=1&per_page=3", "OS finalizadas");
await tryEndpoint("/produto?page=1&per_page=5", "Produtos");
await tryEndpoint("/cliente?page=1&per_page=5", "Clientes");
await tryEndpoint("/vendas?page=1&per_page=5", "Vendas");
await tryEndpoint("/relatorio/abc-produtos", "ABC Produtos");
await tryEndpoint("/relatorio/abc-clientes", "ABC Clientes");
await tryEndpoint("/ordem-servico?data_inicio=2026-03-01&data_fim=2026-03-31&page=1&per_page=5", "OS por período");
await tryEndpoint("/ordem-servico?mes=3&ano=2026&page=1&per_page=3", "OS por mês/ano");
