import fetch from 'node-fetch';

const API_URL = 'http://localhost:3000/api/trpc/pcp.criarOrdemPorOS';

const payload = {
  osNumero: '6610',
  clienteNome: 'Cliente Teste',
  descricaoPedido: 'Pedido de teste para PCP',
};

console.log('Enviando requisição para criar ordem de produção...');
console.log('Payload:', JSON.stringify(payload, null, 2));

try {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json();
  console.log('Resposta:', JSON.stringify(data, null, 2));
  
  if (response.ok) {
    console.log('✅ Ordem criada com sucesso!');
  } else {
    console.log('❌ Erro ao criar ordem');
  }
} catch (error) {
  console.error('Erro:', error.message);
}
